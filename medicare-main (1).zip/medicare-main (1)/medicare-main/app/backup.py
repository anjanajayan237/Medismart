"""Database + uploads backup/restore — powers both the CLI installer
scripts (scripts/backup_data.py, scripts/restore_data.py) and the in-app
Admin -> Settings -> "Backup & Restore" buttons.

A backup is a single .zip containing:
  db/medismart.db   - the SQLite database file
  uploads/...       - every prescription/medicine image under static/uploads

This is all a fresh install on another PC needs to carry over — code comes
from copying/cloning the project folder itself (see install.bat), so only
the *data* needs an explicit export/import step.
"""
import os
import shutil
import zipfile
from datetime import datetime


def _sqlite_path(app):
    """Return the absolute filesystem path of the app's SQLite DB file, or
    None if a non-SQLite DATABASE_URL is configured (e.g. Postgres in
    production — nothing to zip in that case)."""
    uri = app.config.get("SQLALCHEMY_DATABASE_URI", "")
    prefix = "sqlite:///"
    if uri.startswith(prefix):
        return uri[len(prefix):]
    return None


def _backups_dir(app):
    d = os.path.join(os.path.dirname(app.root_path), "backups")
    os.makedirs(d, exist_ok=True)
    return d


def create_backup_zip(app, dest_path=None):
    """Build a backup zip and return its path. If dest_path is omitted, an
    auto-named, timestamped file is created under <project_root>/backups/."""
    db_path = _sqlite_path(app)
    uploads_dir = app.config.get("UPLOAD_FOLDER")

    if dest_path is None:
        stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        dest_path = os.path.join(_backups_dir(app), f"medicare_backup_{stamp}.zip")
    else:
        parent = os.path.dirname(os.path.abspath(dest_path))
        if parent:
            os.makedirs(parent, exist_ok=True)

    with zipfile.ZipFile(dest_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(
            "MANIFEST.txt",
            f"MediSmart data backup\ncreated_utc: {datetime.utcnow().isoformat()}Z\n",
        )
        if db_path and os.path.exists(db_path):
            zf.write(db_path, arcname="db/medismart.db")
        if uploads_dir and os.path.isdir(uploads_dir):
            for root, _dirs, files in os.walk(uploads_dir):
                for fname in files:
                    full = os.path.join(root, fname)
                    rel = os.path.relpath(full, uploads_dir)
                    zf.write(full, arcname=os.path.join("uploads", rel))
    return dest_path


def restore_backup_zip(app, zip_path, dispose_engine=None):
    """Restore a backup created by create_backup_zip, overwriting the
    current DB file and merging the uploads folder back in.

    Always takes a safety copy of the current DB (if any) into
    backups/pre_restore_<timestamp>.db first, so a bad/wrong backup can be
    undone. `dispose_engine`, if given, is called first to release any open
    SQLAlchemy connections/file handles on the DB file before it's replaced
    (important on Windows, where an open file can't be overwritten).
    """
    db_path = _sqlite_path(app)
    uploads_dir = app.config.get("UPLOAD_FOLDER")

    if dispose_engine:
        dispose_engine()

    if db_path and os.path.exists(db_path):
        stamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        safety_path = os.path.join(_backups_dir(app), f"pre_restore_{stamp}.db")
        shutil.copy2(db_path, safety_path)

    restored_db = False
    restored_files = 0
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = zf.namelist()
        if db_path and "db/medismart.db" in names:
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            with zf.open("db/medismart.db") as src, open(db_path, "wb") as dst:
                shutil.copyfileobj(src, dst)
            restored_db = True
        if uploads_dir:
            for name in names:
                if name.startswith("uploads/") and not name.endswith("/"):
                    rel = name[len("uploads/"):]
                    target = os.path.join(uploads_dir, rel)
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with zf.open(name) as src, open(target, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    restored_files += 1

    return {"restored_db": restored_db, "restored_files": restored_files}
