// MediSmart — main.js
(function () {
  "use strict";

  // ---------- Dark / light theme toggle ----------
  var THEME_KEY = "medismart-theme";
  var themeBtn = document.getElementById("themeToggle");
  if (themeBtn) {
    themeBtn.addEventListener("click", function () {
      var isDark = document.body.classList.toggle("theme-dark");
      try {
        localStorage.setItem(THEME_KEY, isDark ? "dark" : "light");
      } catch (e) {}
    });
  }

  // ---------- Dynamic header height (topbar + header + mobile nav) ----------
  var headerGroup = document.getElementById("siteHeaderGroup");
  function syncHeaderHeight() {
    if (!headerGroup) return;
    var h = headerGroup.getBoundingClientRect().height;
    if (h > 0) {
      document.documentElement.style.setProperty("--header-h", h + "px");
    }
  }
  syncHeaderHeight();
  window.addEventListener("resize", function () {
    clearTimeout(window.__hdrResizeT);
    window.__hdrResizeT = setTimeout(syncHeaderHeight, 150);
  });
  window.addEventListener("load", syncHeaderHeight);

  // Sidebar toggle (mobile)
  var toggle = document.getElementById("sidebarToggle");
  var sidebar = document.getElementById("appSidebar");
  var backdrop = document.getElementById("sidebarBackdrop");

  function openSidebar() {
    if (!sidebar) return;
    sidebar.classList.add("show");
    if (backdrop) backdrop.classList.add("show");
  }
  function closeSidebar() {
    if (!sidebar) return;
    sidebar.classList.remove("show");
    if (backdrop) backdrop.classList.remove("show");
  }

  if (toggle) toggle.addEventListener("click", openSidebar);
  if (backdrop) backdrop.addEventListener("click", closeSidebar);

  // Auto-dismiss flash alerts after 5s
  document.querySelectorAll(".alert-dismissible").forEach(function (el) {
    setTimeout(function () {
      var bs = bootstrap.Alert.getOrCreateInstance(el);
      bs.close();
    }, 5000);
  });

  // Quantity steppers (data-qty-target input)
  document.querySelectorAll("[data-qty-step]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var targetId = btn.getAttribute("data-qty-target");
      var input = document.getElementById(targetId);
      if (!input) return;
      var step = parseInt(btn.getAttribute("data-qty-step"), 10) || 1;
      var val = parseInt(input.value, 10) || 1;
      val = Math.max(1, val + step);
      input.value = val;
    });
  });

  // Confirm before delete
  document.querySelectorAll("[data-confirm]").forEach(function (el) {
    el.addEventListener("submit", function (e) {
      var msg = el.getAttribute("data-confirm") || "Are you sure?";
      if (!window.confirm(msg)) e.preventDefault();
    });
  });

  // Toast helper exposed globally
  window.medismartToast = function (message, variant) {
    variant = variant || "success";
    var container = document.getElementById("appToasts");
    if (!container) return;
    var id = "t" + Date.now();
    var html =
      '<div id="' + id + '" class="toast align-items-center text-bg-' + variant + ' border-0" role="alert">' +
      '<div class="d-flex"><div class="toast-body">' + message + '</div>' +
      '<button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div></div>';
    container.insertAdjacentHTML("beforeend", html);
    var node = document.getElementById(id);
    var t = new bootstrap.Toast(node, { delay: 3500 });
    t.show();
    node.addEventListener("hidden.bs.toast", function () { node.remove(); });
  };
})();
