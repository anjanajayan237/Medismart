// MediSmart — dashboard interactions
(function () {
  "use strict";

  // Animate stat counters
  document.querySelectorAll("[data-count]").forEach(function (el) {
    var target = parseInt(el.getAttribute("data-count"), 10) || 0;
    var current = 0;
    var step = Math.max(1, Math.ceil(target / 40));
    var timer = setInterval(function () {
      current += step;
      if (current >= target) { current = target; clearInterval(timer); }
      el.textContent = current.toLocaleString();
    }, 25);
  });

  // Simple bar chart renderer (data-bar="value" elements inside .bar-chart)
  var charts = document.querySelectorAll(".bar-chart");
  charts.forEach(function (chart) {
    var bars = chart.querySelectorAll(".bar");
    var max = 0;
    bars.forEach(function (b) {
      var v = parseInt(b.getAttribute("data-bar"), 10) || 0;
      if (v > max) max = v;
    });
    bars.forEach(function (b) {
      var v = parseInt(b.getAttribute("data-bar"), 10) || 0;
      var pct = max ? Math.round((v / max) * 100) : 0;
      b.style.height = "0%";
      setTimeout(function () { b.style.height = pct + "%"; }, 50);
    });
  });
})();
