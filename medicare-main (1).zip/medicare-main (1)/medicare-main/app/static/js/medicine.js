// MediSmart — medicine listing interactions
(function () {
  "use strict";

  // Sort/filter form auto-submit on change
  document.querySelectorAll("[data-auto-submit]").forEach(function (el) {
    el.addEventListener("change", function () {
      var form = el.closest("form");
      if (form) form.submit();
    });
  });

  // Add to cart quick feedback
  document.querySelectorAll("[data-add-cart]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      if (window.medismartToast) medismartToast("Added to cart", "success");
    });
  });

  // Live search debounce (optional enhancement)
  var search = document.querySelector("[data-live-search]");
  if (search) {
    var timer = null;
    search.addEventListener("input", function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        search.closest("form").submit();
      }, 600);
    });
  }
})();
