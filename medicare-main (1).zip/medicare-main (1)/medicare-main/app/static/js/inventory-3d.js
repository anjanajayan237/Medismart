/* Smart Medicare — 3D Inventory scene.
   Renders every medicine as a 3D "stock bar": height = stock level,
   color = status (healthy / low / out-of-stock / expired). Grouped by
   category along the Z axis. Uses self-hosted three.js + OrbitControls
   (see app/templates/admin/inventory_3d.html) so it also works offline. */
(function () {
  var container = document.getElementById('inv3dScene');
  if (!container || !window.THREE) return;

  var tooltip = document.getElementById('inv3dTooltip');
  var detailPanel = document.getElementById('inv3dDetail');
  var loadingEl = document.getElementById('inv3dLoading');
  var statTotal = document.getElementById('inv3dStatTotal');
  var statLow = document.getElementById('inv3dStatLow');
  var statOut = document.getElementById('inv3dStatOut');
  var statExpired = document.getElementById('inv3dStatExpired');

  var STATUS_COLORS = { healthy: 0x22c55e, low: 0xf59e0b, out: 0x94a3b8, expired: 0xef4444 };
  var STATUS_LABELS = {
    healthy: 'Healthy stock', low: 'Low stock', out: 'Out of stock', expired: 'Expired batch',
  };

  function hex(n) { return '#' + n.toString(16).padStart(6, '0'); }
  function fmtInr(n) {
    n = Number(n || 0);
    return '\u20b9' + n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  var scene, camera, renderer, controls, raycaster, mouse;
  var boxes = [];

  function init() {
    scene = new THREE.Scene();

    var width = container.clientWidth, height = container.clientHeight;
    camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 500);
    camera.position.set(20, 18, 26);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);

    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 1.5, 0);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxDistance = 70;
    controls.minDistance = 8;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.update();

    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    var dir = new THREE.DirectionalLight(0xffffff, 0.9);
    dir.position.set(25, 35, 15);
    scene.add(dir);
    var dir2 = new THREE.DirectionalLight(0x7aa7ff, 0.35);
    dir2.position.set(-20, 12, -15);
    scene.add(dir2);

    var floor = new THREE.Mesh(
      new THREE.PlaneGeometry(80, 80),
      new THREE.MeshStandardMaterial({ color: 0x101a2e, roughness: 0.95, metalness: 0.05 })
    );
    floor.rotation.x = -Math.PI / 2;
    scene.add(floor);
    scene.add(new THREE.GridHelper(80, 40, 0x2d4568, 0x18233a));

    raycaster = new THREE.Raycaster();
    mouse = new THREE.Vector2();

    renderer.domElement.addEventListener('mousemove', onMouseMove);
    renderer.domElement.addEventListener('click', onClick);
    window.addEventListener('resize', onResize);

    animate();
    loadData();
  }

  function onResize() {
    var width = container.clientWidth, height = container.clientHeight;
    if (!width || !height) return;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
  }

  function loadData() {
    loadingEl.style.display = 'flex';
    fetch(container.dataset.url)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        buildScene(data.items || []);
        loadingEl.style.display = 'none';
      })
      .catch(function () {
        loadingEl.innerHTML = '<div class="text-danger small">Could not load live inventory data.</div>';
      });
  }

  function buildScene(items) {
    boxes.forEach(function (b) { scene.remove(b.mesh); });
    boxes = [];

    var byCategory = {};
    items.forEach(function (it) {
      (byCategory[it.category] = byCategory[it.category] || []).push(it);
    });
    var categories = Object.keys(byCategory).sort();
    var maxStock = 1;
    items.forEach(function (it) { if (it.stock > maxStock) maxStock = it.stock; });

    var spacingX = 2.6, spacingZ = 4.6;
    var counts = { low: 0, out: 0, expired: 0 };

    categories.forEach(function (cat, ci) {
      var rowItems = byCategory[cat];
      rowItems.forEach(function (it, idx) {
        var h = Math.max(0.5, (it.stock / maxStock) * 9);
        var geo = new THREE.BoxGeometry(1.5, h, 1.5);
        var color = STATUS_COLORS[it.status] || 0x64748b;
        var mat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.4, metalness: 0.1 });
        var mesh = new THREE.Mesh(geo, mat);
        var x = (idx - (rowItems.length - 1) / 2) * spacingX;
        var z = (ci - (categories.length - 1) / 2) * spacingZ;
        mesh.position.set(x, h / 2, z);
        mesh.userData.item = it;
        scene.add(mesh);
        boxes.push({ mesh: mesh, item: it });
        if (counts[it.status] !== undefined) counts[it.status]++;
      });
    });

    if (statTotal) statTotal.textContent = items.length;
    if (statLow) statLow.textContent = counts.low;
    if (statOut) statOut.textContent = counts.out;
    if (statExpired) statExpired.textContent = counts.expired;
  }

  function pickAt(e) {
    var rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    var hits = raycaster.intersectObjects(boxes.map(function (b) { return b.mesh; }));
    return hits.length ? hits[0].object.userData.item : null;
  }

  function onMouseMove(e) {
    var item = pickAt(e);
    if (item) {
      tooltip.style.display = 'block';
      tooltip.style.left = (e.clientX + 14) + 'px';
      tooltip.style.top = (e.clientY + 14) + 'px';
      tooltip.innerHTML = '<strong>' + item.name + '</strong><br>' + STATUS_LABELS[item.status];
      renderer.domElement.style.cursor = 'pointer';
    } else {
      tooltip.style.display = 'none';
      renderer.domElement.style.cursor = 'default';
    }
  }

  function onClick(e) {
    var item = pickAt(e);
    if (item) showDetail(item);
  }

  function showDetail(item) {
    detailPanel.classList.remove('threed-detail-panel');
    var storesHtml = '';
    if (item.stores && item.stores.length) {
      storesHtml = '<hr class="my-2">' +
        '<div class="small text-muted mb-1"><i class="bi bi-shop me-1"></i>Branch rack locations</div>' +
        '<div class="small vstack gap-1">' +
        item.stores.map(function (s) {
          return '<div class="d-flex justify-content-between">' +
            '<span>' + s.store + (s.rack ? ' &middot; Rack ' + s.rack : '') + '</span>' +
            '<strong>' + s.stock + '</strong>' +
            '</div>';
        }).join('') +
        '</div>';
    }
    detailPanel.innerHTML =
      '<div class="w-100">' +
        '<div class="d-flex justify-content-between align-items-start mb-2">' +
          '<div><div class="fw-bold">' + item.name + '</div>' +
          '<div class="text-muted small">' + item.brand + ' &middot; ' + item.category + '</div></div>' +
          '<span class="badge" style="background:' + hex(STATUS_COLORS[item.status] || 0x64748b) + '">' +
            (STATUS_LABELS[item.status] || item.status) + '</span>' +
        '</div>' +
        '<div class="row g-2 small">' +
          '<div class="col-4"><span class="text-muted">Stock</span><br><strong>' + item.stock + ' ' + item.unit + '</strong></div>' +
          '<div class="col-4"><span class="text-muted">Price</span><br><strong>' + fmtInr(item.price) + '</strong></div>' +
          '<div class="col-4"><span class="text-muted">Expiry</span><br><strong>' + (item.expiry_date || '\u2014') + '</strong></div>' +
        '</div>' +
        storesHtml +
      '</div>';
  }

  function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
  }

  init();
})();
