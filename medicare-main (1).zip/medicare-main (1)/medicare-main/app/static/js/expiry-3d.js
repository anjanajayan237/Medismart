/* Smart Medicare — 3D Expiry Timeline scene.
   Every batch is placed as a sphere along a 3D timeline: position along
   the X axis encodes days-until-expiry (a glowing "TODAY" marker sits at
   x = 0), colored red/amber/green for expired/expiring-soon/healthy.
   Uses self-hosted three.js + OrbitControls so it also works offline. */
(function () {
  var container = document.getElementById('exp3dScene');
  if (!container || !window.THREE) return;

  var tooltip = document.getElementById('exp3dTooltip');
  var detailPanel = document.getElementById('exp3dDetail');
  var loadingEl = document.getElementById('exp3dLoading');
  var statTotal = document.getElementById('exp3dStatTotal');
  var statExpired = document.getElementById('exp3dStatExpired');
  var statSoon = document.getElementById('exp3dStatSoon');
  var statHealthy = document.getElementById('exp3dStatHealthy');

  var STATUS_COLORS = { expired: 0xef4444, expiring_soon: 0xf59e0b, healthy: 0x22c55e };
  var STATUS_LABELS = { expired: 'Expired', expiring_soon: 'Expiring within 30 days', healthy: 'Healthy' };

  var scene, camera, renderer, controls, raycaster, mouse;
  var markers = [];

  function init() {
    scene = new THREE.Scene();

    var width = container.clientWidth, height = container.clientHeight;
    camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 500);
    camera.position.set(0, 16, 34);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.appendChild(renderer.domElement);

    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 1, 0);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.maxDistance = 90;
    controls.minDistance = 10;
    controls.maxPolarAngle = Math.PI / 2.05;
    controls.update();

    scene.add(new THREE.AmbientLight(0xffffff, 0.65));
    var dir = new THREE.DirectionalLight(0xffffff, 0.85);
    dir.position.set(20, 30, 20);
    scene.add(dir);

    var floor = new THREE.Mesh(
      new THREE.PlaneGeometry(140, 40),
      new THREE.MeshStandardMaterial({ color: 0x101a2e, roughness: 0.95 })
    );
    floor.rotation.x = -Math.PI / 2;
    scene.add(floor);
    scene.add(new THREE.GridHelper(140, 56, 0x2d4568, 0x18233a));

    // Past (expired) zone tint — red, behind x = 0
    var pastZone = new THREE.Mesh(
      new THREE.PlaneGeometry(70, 40),
      new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.06 })
    );
    pastZone.rotation.x = -Math.PI / 2;
    pastZone.position.set(-35, 0.02, 0);
    scene.add(pastZone);

    // Future (upcoming) zone tint — green, ahead of x = 0
    var futureZone = new THREE.Mesh(
      new THREE.PlaneGeometry(70, 40),
      new THREE.MeshBasicMaterial({ color: 0x22c55e, transparent: true, opacity: 0.05 })
    );
    futureZone.rotation.x = -Math.PI / 2;
    futureZone.position.set(35, 0.02, 0);
    scene.add(futureZone);

    // "TODAY" marker — a tall glowing vertical plane at x = 0
    var todayMarker = new THREE.Mesh(
      new THREE.PlaneGeometry(0.25, 14),
      new THREE.MeshBasicMaterial({ color: 0x60a5fa, transparent: true, opacity: 0.75, side: THREE.DoubleSide })
    );
    todayMarker.position.set(0, 7, 0);
    scene.add(todayMarker);

    raycaster = new THREE.Raycaster();
    mouse = new THREE.Vector2();

    renderer.domElement.addEventListener('mousemove', onMouseMove);
    renderer.domElement.addEventListener('click', onClick);
    window.addEventListener('resize', onResize);

    animate();
    loadData();
  }

  function onResize() {
    var width = container.clientWidth, height = container.clientHeight;
    if (!width || !height) return;
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height);
  }

  function loadData() {
    loadingEl.style.display = 'flex';
    fetch(container.dataset.url)
      .then(function (r) { return r.json(); })
      .then(function (data) {
        buildScene(data.items || []);
        loadingEl.style.display = 'none';
      })
      .catch(function () {
        loadingEl.innerHTML = '<div class="text-danger small">Could not load live expiry data.</div>';
      });
  }

  function buildScene(items) {
    markers.forEach(function (m) { scene.remove(m.mesh); });
    markers = [];

    var maxAbsDays = 30;
    items.forEach(function (it) { maxAbsDays = Math.max(maxAbsDays, Math.abs(it.days_left)); });
    var xScale = Math.min(0.22, 55 / maxAbsDays);

    var sorted = items.slice().sort(function (a, b) { return a.days_left - b.days_left; });
    var lanesLastX = [];
    var spacingThreshold = 1.6;
    var placed = [];

    sorted.forEach(function (it) {
      var x = it.days_left * xScale;
      var lane = 0;
      while (lanesLastX[lane] !== undefined && Math.abs(lanesLastX[lane] - x) < spacingThreshold) {
        lane++;
      }
      lanesLastX[lane] = x;
      placed.push({ item: it, x: x, lane: lane });
    });

    var maxLane = lanesLastX.length - 1;
    var counts = { expired: 0, expiring_soon: 0, healthy: 0 };

    placed.forEach(function (p) {
      var z = (p.lane - maxLane / 2) * 2.4;
      var color = STATUS_COLORS[p.item.status] || 0x94a3b8;
      var size = p.item.status === 'expired' ? 0.6 : 0.75;
      var geo = new THREE.SphereGeometry(size, 20, 20);
      var mat = new THREE.MeshStandardMaterial({
        color: color, roughness: 0.3, metalness: 0.2,
        emissive: color, emissiveIntensity: 0.25,
      });
      var mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(p.x, size + 0.05, z);
      mesh.userData.item = p.item;
      scene.add(mesh);
      markers.push({ mesh: mesh, item: p.item });
      if (counts[p.item.status] !== undefined) counts[p.item.status]++;
    });

    if (statTotal) statTotal.textContent = items.length;
    if (statExpired) statExpired.textContent = counts.expired;
    if (statSoon) statSoon.textContent = counts.expiring_soon;
    if (statHealthy) statHealthy.textContent = counts.healthy;
  }

  function pickAt(e) {
    var rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    var hits = raycaster.intersectObjects(markers.map(function (m) { return m.mesh; }));
    return hits.length ? hits[0].object.userData.item : null;
  }

  function onMouseMove(e) {
    var item = pickAt(e);
    if (item) {
      var daysTxt = item.days_left < 0
        ? Math.abs(item.days_left) + ' day(s) ago'
        : item.days_left === 0 ? 'Today' : 'in ' + item.days_left + ' day(s)';
      tooltip.style.display = 'block';
      tooltip.style.left = (e.clientX + 14) + 'px';
      tooltip.style.top = (e.clientY + 14) + 'px';
      tooltip.innerHTML = '<strong>' + item.name + '</strong><br>' + item.expiry_date + ' (' + daysTxt + ')';
      renderer.domElement.style.cursor = 'pointer';
    } else {
      tooltip.style.display = 'none';
      renderer.domElement.style.cursor = 'default';
    }
  }

  function onClick(e) {
    var item = pickAt(e);
    if (item) showDetail(item);
  }

  function hex(n) { return '#' + n.toString(16).padStart(6, '0'); }

  function showDetail(item) {
    var daysTxt = item.days_left < 0
      ? Math.abs(item.days_left) + ' day(s) overdue'
      : item.days_left === 0 ? 'Expires today' : item.days_left + ' day(s) remaining';
    detailPanel.classList.remove('threed-detail-panel');
    detailPanel.innerHTML =
      '<div class="w-100">' +
        '<div class="d-flex justify-content-between align-items-start mb-2">' +
          '<div><div class="fw-bold">' + item.name + '</div>' +
          '<div class="text-muted small">' + item.brand + '</div></div>' +
          '<span class="badge" style="background:' + hex(STATUS_COLORS[item.status] || 0x64748b) + '">' +
            (STATUS_LABELS[item.status] || item.status) + '</span>' +
        '</div>' +
        '<div class="row g-2 small">' +
          '<div class="col-6"><span class="text-muted">Expiry date</span><br><strong>' + item.expiry_date + '</strong></div>' +
          '<div class="col-6"><span class="text-muted">Timeline</span><br><strong>' + daysTxt + '</strong></div>' +
          '<div class="col-6"><span class="text-muted">Stock left</span><br><strong>' + item.stock + '</strong></div>' +
        '</div>' +
      '</div>';
  }

  function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
  }

  init();
})();
