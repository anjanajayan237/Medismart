// MediSmart — Landing page animations
(function () {
  "use strict";

  // Scroll reveal
  var revealEls = document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window && revealEls.length) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting) {
            e.target.classList.add("active");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("active"); });
  }

  // Soft tilt on feature cards (desktop only)
  if (window.matchMedia("(pointer: fine)").matches) {
    document.querySelectorAll("[data-tilt]").forEach(function (card) {
      card.addEventListener("mousemove", function (e) {
        var rect = card.getBoundingClientRect();
        var x = e.clientX - rect.left;
        var y = e.clientY - rect.top;
        var cx = rect.width / 2;
        var cy = rect.height / 2;
        var rotX = ((y - cy) / cy) * -5;
        var rotY = ((x - cx) / cx) * 5;
        card.style.transform =
          "translateY(-6px) perspective(700px) rotateX(" + rotX + "deg) rotateY(" + rotY + "deg)";
      });
      card.addEventListener("mouseleave", function () {
        card.style.transform = "";
      });
    });
  }

  // Counter animation
  var counters = document.querySelectorAll("[data-count]");
  var fired = {};
  if ("IntersectionObserver" in window && counters.length) {
    var cio = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting && !fired[e.target.id]) {
            fired[e.target.id] = true;
            animateCount(e.target);
          }
        });
      },
      { threshold: 0.45 }
    );
    counters.forEach(function (c, i) {
      c.id = c.id || "ctr" + i;
      cio.observe(c);
    });
  }

  function animateCount(el) {
    var target = parseInt(el.getAttribute("data-count"), 10) || 0;
    var suffix = el.getAttribute("data-suffix") || "";
    var cur = 0;
    var step = Math.max(1, Math.ceil(target / 48));
    var t = setInterval(function () {
      cur += step;
      if (cur >= target) {
        cur = target;
        clearInterval(t);
      }
      el.textContent = cur.toLocaleString() + suffix;
    }, 28);
  }

  // Highlight delivery steps as rider loops
  var steps = document.querySelectorAll(".delivery-step-bubble .icon-circle");
  if (steps.length) {
    var idx = 0;
    setInterval(function () {
      steps.forEach(function (s) { s.classList.remove("is-active"); });
      steps[idx].classList.add("is-active");
      idx = (idx + 1) % steps.length;
    }, 2400);
  }
})();
