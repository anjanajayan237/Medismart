// MediSmart — AI Assistant chat widget
(function () {
  "use strict";

  var fab = document.getElementById("aiAssistantToggle");
  var panel = document.getElementById("aiAssistantPanel");
  var closeBtn = document.getElementById("aiAssistantClose");
  var messagesEl = document.getElementById("aiAssistantMessages");
  var suggestionsEl = document.getElementById("aiAssistantSuggestions");
  var form = document.getElementById("aiAssistantForm");
  var input = document.getElementById("aiAssistantInput");

  if (!fab || !panel || !form) return;

  var opened = false;
  var greeted = false;

  function escapeHtml(str) {
    var div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  // Server replies use **bold** for emphasis only — escape everything else
  // first, then re-enable just that one safe pattern.
  function formatReply(text) {
    var escaped = escapeHtml(text);
    return escaped.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  }

  function scrollToBottom() {
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function addMessage(role, html, links) {
    var wrap = document.createElement("div");
    wrap.className = "ai-msg ai-msg-" + role;

    if (role === "assistant") {
      var avatar = document.createElement("span");
      avatar.className = "ai-msg-avatar";
      avatar.innerHTML = '<i class="bi bi-robot"></i>';
      wrap.appendChild(avatar);
    }

    var bubble = document.createElement("div");
    bubble.className = "ai-msg-bubble";
    bubble.innerHTML = html;
    wrap.appendChild(bubble);

    messagesEl.appendChild(wrap);

    if (links && links.length) {
      var linkRow = document.createElement("div");
      linkRow.className = "ai-msg-links";
      links.forEach(function (l) {
        var a = document.createElement("a");
        a.href = l.url;
        a.textContent = l.label;
        a.className = "ai-link-chip";
        linkRow.appendChild(a);
      });
      messagesEl.appendChild(linkRow);
    }

    scrollToBottom();
  }

  function addTyping() {
    var wrap = document.createElement("div");
    wrap.className = "ai-msg ai-msg-assistant ai-msg-typing";
    wrap.id = "aiTypingIndicator";
    wrap.innerHTML =
      '<span class="ai-msg-avatar"><i class="bi bi-robot"></i></span>' +
      '<div class="ai-msg-bubble"><span class="ai-typing-dot"></span><span class="ai-typing-dot"></span><span class="ai-typing-dot"></span></div>';
    messagesEl.appendChild(wrap);
    scrollToBottom();
  }

  function removeTyping() {
    var el = document.getElementById("aiTypingIndicator");
    if (el) el.remove();
  }

  function loadSuggestions() {
    fetch("/assistant/suggestions")
      .then(function (r) { return r.json(); })
      .then(function (data) {
        suggestionsEl.innerHTML = "";
        (data.suggestions || []).forEach(function (s) {
          var chip = document.createElement("button");
          chip.type = "button";
          chip.className = "ai-suggestion-chip";
          chip.textContent = s;
          chip.addEventListener("click", function () {
            sendMessage(s);
          });
          suggestionsEl.appendChild(chip);
        });
      })
      .catch(function () {});
  }

  function sendMessage(text) {
    if (!text) return;
    addMessage("user", escapeHtml(text));
    input.value = "";
    addTyping();

    fetch("/assistant/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text }),
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        removeTyping();
        addMessage("assistant", formatReply(data.reply || "Sorry, something went wrong."), data.links);
      })
      .catch(function () {
        removeTyping();
        addMessage("assistant", "Sorry, I couldn't reach the server. Please try again.");
      });
  }

  var fabIcon = fab.querySelector("i");

  function openPanel() {
    panel.classList.add("open");
    fab.classList.add("active");
    if (fabIcon) fabIcon.className = "bi bi-x-lg";
    opened = true;
    if (!greeted) {
      greeted = true;
      addTyping();
      setTimeout(function () {
        removeTyping();
        addMessage(
          "assistant",
          "Hi! I'm the MediSmart AI Assistant. Ask me about orders, medicine prices, prescriptions, delivery, loyalty points, or coupons."
        );
        loadSuggestions();
      }, 500);
    }
    setTimeout(function () { input.focus(); }, 100);
  }

  function closePanel() {
    panel.classList.remove("open");
    fab.classList.remove("active");
    if (fabIcon) fabIcon.className = "bi bi-robot";
    opened = false;
  }

  fab.addEventListener("click", function () {
    if (opened) closePanel();
    else openPanel();
  });
  closeBtn.addEventListener("click", closePanel);

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var text = input.value.trim();
    if (text) sendMessage(text);
  });
})();
