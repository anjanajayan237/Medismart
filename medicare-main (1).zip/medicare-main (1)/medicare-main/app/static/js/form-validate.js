/* MediSmart — live animated form validation + special-char stripping */
(function () {
  "use strict";

  var PATTERNS = {
    name: /[^\w\s.'\-]/gu,
    phone: /[^\d+\-\s()]/g,
    medicine: /[^\w\s.\-%/+]/gu,
    description: /[^\w\s.,;:!?'\-/%()+]/gu,
    emailIllegal: /[<>\"'\\;]/g,
  };

  var RULES = {
    name: function (v) {
      if (!v || v.length < 2) return "Name must be at least 2 characters.";
      if (v.length > 80) return "Name is too long.";
      if (!/[A-Za-z\u00C0-\u024F\u0900-\u0D7F]/.test(v)) return "Name must include letters.";
      return "";
    },
    email: function (v) {
      if (!v) return "Email is required.";
      if (/[<>\"'\\;]/.test(v)) return "Email has invalid special characters.";
      if (!/^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/.test(v)) {
        return "Enter a valid email (e.g. you@example.com).";
      }
      return "";
    },
    gmail: function (v) {
      if (!v) return "Email is required.";
      if (!/^[a-zA-Z0-9._%+\-]+@gmail\.com$/i.test(v) || v.indexOf("..") !== -1) {
        return "Only @gmail.com addresses are allowed (must end with .com).";
      }
      return "";
    },
    phone: function (v) {
      if (!v) return "";
      var digits = v.replace(/\D/g, "");
      if (digits.length < 10 || digits.length > 15) return "Phone must have 10–15 digits.";
      return "";
    },
    address: function (v) {
      if (!v) return "";
      if (v.length < 5) return "Address looks too short.";
      return "";
    },
    password: function (v) {
      if (!v) return "Password is required.";
      if (v.length < 6) return "Password must be at least 6 characters.";
      if (/[\x00-\x1f<>]/.test(v)) return "Password contains invalid characters.";
      return "";
    },
    confirm: function (v, form) {
      var pw = form.querySelector('[name="password"]');
      if (!v) return "Please confirm your password.";
      if (pw && v !== pw.value) return "Passwords do not match.";
      return "";
    },
    medicine: function (v) {
      if (!v || v.length < 2) return "Medicine name must be at least 2 characters.";
      return "";
    },
    brand: function (v) {
      return "";
    },
    unit: function (v) {
      if (!v) return "Unit is required.";
      return "";
    },
    description: function () {
      return "";
    },
    price: function (v) {
      if (v === "" || v == null) return "Price is required.";
      if (isNaN(Number(v)) || Number(v) < 0) return "Enter a valid price.";
      return "";
    },
    stock: function (v) {
      if (v === "" || v == null) return "Stock is required.";
      if (!/^\d+$/.test(String(v)) || Number(v) < 0) return "Stock must be a whole number.";
      return "";
    },
  };

  function strengthScore(pw) {
    var s = 0;
    if (!pw) return 0;
    if (pw.length >= 6) s++;
    if (pw.length >= 10) s++;
    if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
    if (/\d/.test(pw)) s++;
    if (/[^A-Za-z0-9]/.test(pw)) s++;
    return Math.min(s, 4);
  }

  function strengthLabel(score) {
    return ["", "Weak", "Fair", "Good", "Strong"][score] || "";
  }

  function ensureMsg(field) {
    var msg = field.querySelector(".fv-msg");
    if (!msg) {
      msg = document.createElement("small");
      msg.className = "fv-msg";
      field.appendChild(msg);
    }
    return msg;
  }

  function ensureStripHint(field) {
    var hint = field.querySelector(".fv-strip-hint");
    if (!hint) {
      hint = document.createElement("span");
      hint.className = "fv-strip-hint";
      hint.innerHTML = '<i class="bi bi-magic"></i> Special characters removed';
      field.appendChild(hint);
    }
    return hint;
  }

  function setState(field, state, text) {
    field.classList.remove("is-valid", "is-invalid");
    if (state) field.classList.add(state === "ok" ? "is-valid" : "is-invalid");
    var msg = ensureMsg(field);
    msg.className = "fv-msg show " + (state === "ok" ? "is-ok" : state === "error" ? "is-error" : "is-warn");
    msg.textContent = text || (state === "ok" ? "Looks good" : "");
    if (!text && state === "ok") {
      msg.innerHTML = '<i class="bi bi-check-circle-fill me-1"></i>Looks good';
    } else if (state === "error" && text) {
      msg.innerHTML = '<i class="bi bi-exclamation-circle-fill me-1"></i>' + text;
    }
  }

  function clearState(field) {
    field.classList.remove("is-valid", "is-invalid");
    var msg = field.querySelector(".fv-msg");
    if (msg) {
      msg.className = "fv-msg";
      msg.textContent = "";
    }
  }

  function stripValue(input, kind) {
    if (kind === "email") {
      var beforeE = input.value;
      input.value = input.value.replace(/[<>\"'\\;]/g, "");
      return beforeE !== input.value;
    }
    var pattern = PATTERNS[kind];
    if (!pattern || input.type === "password" || input.type === "number") {
      return false;
    }
    var before = input.value;
    pattern.lastIndex = 0;
    input.value = input.value.replace(pattern, "");
    input.value = input.value.replace(/\s{2,}/g, " ");
    return before !== input.value;
  }

  function flashStrip(field) {
    field.classList.add("is-cleaning");
    var hint = ensureStripHint(field);
    hint.classList.add("show");
    clearTimeout(field._stripT);
    field._stripT = setTimeout(function () {
      field.classList.remove("is-cleaning");
      hint.classList.remove("show");
    }, 1400);
  }

  function validateField(input, form) {
    var field = input.closest(".fv-field");
    if (!field) return true;
    var rule = input.getAttribute("data-fv") || "";
    var kind = input.getAttribute("data-strip") || "";
    if (kind && stripValue(input, kind)) flashStrip(field);

    if (!rule || !RULES[rule]) {
      clearState(field);
      return true;
    }
    var err = RULES[rule](input.value.trim(), form);
    if (!input.value.trim() && input.getAttribute("data-fv-optional") === "1") {
      clearState(field);
      return true;
    }
    if (err) {
      setState(field, "error", err);
      return false;
    }
    if (input.value.trim()) setState(field, "ok", "");
    else clearState(field);
    return true;
  }

  function updateStrength(form) {
    var pw = form.querySelector('[name="password"][data-fv="password"]');
    var meter = form.querySelector(".fv-strength");
    var label = form.querySelector(".fv-strength-label");
    if (!pw || !meter) return;
    var score = strengthScore(pw.value);
    meter.setAttribute("data-score", String(score));
    if (label) label.textContent = strengthLabel(score);
  }

  function updateBanner(form) {
    var banner = form.querySelector(".fv-live-banner");
    if (!banner) return;
    var invalids = form.querySelectorAll(".fv-field.is-invalid");
    if (invalids.length) {
      banner.className = "fv-live-banner show is-error";
      banner.innerHTML =
        '<i class="bi bi-exclamation-triangle-fill"></i>' +
        '<span>Fix ' + invalids.length + ' field' + (invalids.length > 1 ? "s" : "") + " highlighted below</span>";
    } else {
      var touched = form.querySelectorAll(".fv-field.is-valid").length;
      if (touched > 0) {
        banner.className = "fv-live-banner show is-ok";
        banner.innerHTML =
          '<i class="bi bi-check2-circle"></i><span>Looking good — ready to submit</span>';
      } else {
        banner.className = "fv-live-banner";
        banner.innerHTML = "";
      }
    }
  }

  function bindForm(form) {
    if (form._fvBound) return;
    form._fvBound = true;

    form.querySelectorAll("[data-fv], [data-strip]").forEach(function (input) {
      var field = input.closest(".fv-field");
      if (!field) {
        field = document.createElement("div");
        field.className = "fv-field";
        input.parentNode.insertBefore(field, input);
        field.appendChild(input);
      }

      input.addEventListener("input", function () {
        validateField(input, form);
        if (input.name === "password") {
          updateStrength(form);
          var confirm = form.querySelector('[name="confirm"]');
          if (confirm && confirm.value) validateField(confirm, form);
        }
        if (input.name === "confirm") validateField(input, form);
        updateBanner(form);
      });
      input.addEventListener("blur", function () {
        validateField(input, form);
        updateBanner(form);
      });
    });

    form.addEventListener("submit", function (e) {
      var ok = true;
      form.querySelectorAll("[data-fv]").forEach(function (input) {
        if (!validateField(input, form)) ok = false;
      });
      updateBanner(form);
      if (!ok) {
        e.preventDefault();
        var first = form.querySelector(".fv-field.is-invalid .form-control, .fv-field.is-invalid .form-select");
        if (first) {
          first.focus();
          first.scrollIntoView({ behavior: "smooth", block: "center" });
        }
        if (window.medismartToast) {
          window.medismartToast("Please fix the highlighted fields.", "danger");
        }
      } else {
        var btn = form.querySelector('[type="submit"]');
        if (btn) {
          btn.classList.add("fv-submit-pulse");
          btn.disabled = true;
          var original = btn.innerHTML;
          btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Please wait…';
          setTimeout(function () {
            btn.disabled = false;
            btn.innerHTML = original;
          }, 4000);
        }
      }
    });
  }

  document.querySelectorAll("form[data-validate]").forEach(bindForm);

  document.querySelectorAll("[data-pw-toggle]").forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      var wrap = btn.closest(".auth-input-icon");
      var input = wrap && wrap.querySelector("input");
      var icon = btn.querySelector("i");
      if (!input) return;
      var show = input.type === "password";
      input.type = show ? "text" : "password";
      if (icon) {
        icon.classList.toggle("bi-eye", !show);
        icon.classList.toggle("bi-eye-slash", show);
      }
      btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
    });
  });
})();
