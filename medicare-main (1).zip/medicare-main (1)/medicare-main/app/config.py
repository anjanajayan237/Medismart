import os

try:
    from dotenv import load_dotenv
    # Loads a .env file (if present) from the project root into os.environ,
    # so GEMINI_API_KEY etc. can be set once locally without exporting shell
    # env vars every session. Optional — app works fine without python-dotenv
    # installed, using real environment variables instead.
    load_dotenv()
except ImportError:  # pragma: no cover - optional dependency
    pass

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Built-in fallback so AI prescription reading works even when .env is missing
# on a fresh clone / another PC. Prefer GEMINI_API_KEY from the environment
# or .env when present (overrides this default).
_DEFAULT_GEMINI_API_KEY = "AQ.Ab8RN6JgyHwvuw6FR8OXAqDmwoMHy6HwiWbjxlcZWH0M66lTqQ"


def _resolve_gemini_api_key():
    key = (os.environ.get("GEMINI_API_KEY") or "").strip()
    if key:
        return key
    return _DEFAULT_GEMINI_API_KEY


# Ensure the rest of the app (gemini_ocr, system_check) sees a key even
# without a .env file on disk.
if not (os.environ.get("GEMINI_API_KEY") or "").strip():
    os.environ["GEMINI_API_KEY"] = _DEFAULT_GEMINI_API_KEY


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "medismart-dev-secret-change-me")

    # SQLite for development (per project spec). Switch to PostgreSQL via
    # DATABASE_URL env var for production.
    DATABASE_URL = os.environ.get("DATABASE_URL")
    if DATABASE_URL:
        SQLALCHEMY_DATABASE_URI = DATABASE_URL
    else:
        SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(BASE_DIR, "medismart.db")

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Overridable so Docker (see Dockerfile/docker-compose.yml) can point
    # this at a mounted volume and persist uploads across container
    # rebuilds. Defaults to the in-repo static folder for a normal install.
    UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER") or os.path.join(BASE_DIR, "static", "uploads")
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "pdf"}

    REMEMBER_COOKIE_DURATION = 60 * 60 * 24 * 7  # 7 days

    # Delivery pricing (Kerala-based pharmacy, amounts in INR). Flat charge
    # for home delivery below the free-delivery threshold; store pickup is
    # always free. Override via env vars if needed.
    DELIVERY_CHARGE = float(os.environ.get("DELIVERY_CHARGE", 40))
    FREE_DELIVERY_THRESHOLD = float(os.environ.get("FREE_DELIVERY_THRESHOLD", 500))

    # Optional explicit path to the Tesseract OCR binary. If unset, the app
    # auto-detects common install locations (see app/ocr.py).
    TESSERACT_CMD = os.environ.get("TESSERACT_CMD")

    # Gemini API key for handwritten prescription reading. Uses .env / env
    # when set; otherwise falls back to the built-in project default above.
    GEMINI_API_KEY = _resolve_gemini_api_key()
