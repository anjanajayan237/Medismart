from flask import Blueprint, render_template

bp = Blueprint("errors", __name__)


@bp.app_errorhandler(404)
def not_found(err):
    return render_template("errors/404.html"), 404


@bp.app_errorhandler(403)
def forbidden(err):
    return render_template("errors/404.html", message="You do not have permission to access this page."), 403


@bp.app_errorhandler(500)
def server_error(err):
    return render_template("errors/500.html"), 500
