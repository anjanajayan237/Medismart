"""Shop-staff portal: each pharmacist logs in and only sees their branch."""
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models import Order, Medicine, StoreStock, Notification
from app.utils import paginate, status_badge

bp = Blueprint("store", __name__, url_prefix="/store")


@bp.before_request
@login_required
def require_store_staff():
    if current_user.is_admin:
        return redirect(url_for("admin.dashboard"))
    if not current_user.is_store_staff:
        abort(403)


def _my_store():
    """Staff portal store — allow access even if branch was deactivated so
    open pickups can still be confirmed / released."""
    if not current_user.store_id:
        flash("Your shop account is not linked to a branch. Contact admin.", "danger")
        abort(403)
    store = current_user.store
    if not store:
        flash("Your assigned shop no longer exists. Contact admin.", "danger")
        abort(403)
    return store


@bp.route("/dashboard")
def dashboard():
    store = _my_store()
    pending = Order.query.filter_by(store_id=store.id, status="pending").count()
    ready = Order.query.filter(
        Order.store_id == store.id,
        Order.status.in_(["confirmed", "shipped"]),
    ).count()
    recent = (
        Order.query.filter_by(store_id=store.id)
        .order_by(Order.created_at.desc())
        .limit(8)
        .all()
    )
    low_stock = (
        StoreStock.query.filter_by(store_id=store.id)
        .filter(StoreStock.stock <= 5)
        .order_by(StoreStock.stock.asc())
        .limit(8)
        .all()
    )
    unread = Notification.query.filter_by(
        user_id=current_user.id, is_read=False
    ).count()
    return render_template(
        "store/dashboard.html",
        store=store,
        pending=pending,
        ready=ready,
        recent=recent,
        low_stock=low_stock,
        unread=unread,
        status_badge=status_badge,
    )


@bp.route("/orders")
def orders():
    store = _my_store()
    page = request.args.get("page", 1, type=int)
    status = (request.args.get("status") or "").strip()
    query = Order.query.filter_by(store_id=store.id)
    if status:
        query = query.filter_by(status=status)
    query = query.order_by(Order.created_at.desc())
    pagination = paginate(query, page, 15)
    return render_template(
        "store/orders.html",
        store=store,
        orders=pagination.items,
        pagination=pagination,
        status_filter=status,
        status_badge=status_badge,
    )


@bp.route("/orders/<int:order_id>/confirm", methods=["POST"])
def confirm_order(order_id):
    store = _my_store()
    order = Order.query.get_or_404(order_id)
    if order.store_id != store.id:
        abort(403)
    if order.status == "pending":
        order.status = "confirmed"
        if order.fulfillment_type == "pickup":
            msg = f"{store.name} confirmed your pickup order. Bring your pickup code when you arrive."
        else:
            msg = f"{store.name} is packing your home delivery order."
        db.session.add(Notification(
            user_id=order.user_id,
            title=f"Order #{order.id} confirmed",
            message=msg,
        ))
        db.session.commit()
        flash(f"Order #{order.id} confirmed.", "success")
    return redirect(url_for("store.orders"))


@bp.route("/orders/<int:order_id>/ship", methods=["POST"])
def ship_order(order_id):
    """Mark a home-delivery order as shipped from this branch."""
    store = _my_store()
    order = Order.query.get_or_404(order_id)
    if order.store_id != store.id or order.fulfillment_type != "delivery":
        abort(403)
    if order.status in ("pending", "confirmed"):
        order.status = "shipped"
        db.session.add(Notification(
            user_id=order.user_id,
            title=f"Order #{order.id} shipped",
            message=f"Your order left {store.name} and is on the way.",
        ))
        db.session.commit()
        flash(f"Order #{order.id} marked as shipped.", "success")
    return redirect(url_for("store.orders"))


@bp.route("/orders/<int:order_id>/deliver", methods=["POST"])
def deliver_order(order_id):
    store = _my_store()
    order = Order.query.get_or_404(order_id)
    if order.store_id != store.id or order.fulfillment_type != "delivery":
        abort(403)
    if order.status in ("confirmed", "shipped"):
        order.status = "delivered"
        db.session.add(Notification(
            user_id=order.user_id,
            title=f"Order #{order.id} delivered",
            message="Your home delivery order has been delivered. Thank you!",
        ))
        db.session.commit()
        flash(f"Order #{order.id} marked as delivered.", "success")
    return redirect(url_for("store.orders"))


@bp.route("/orders/<int:order_id>/verify-pickup", methods=["POST"])
def verify_pickup(order_id):
    store = _my_store()
    order = Order.query.get_or_404(order_id)
    if order.store_id != store.id or order.fulfillment_type != "pickup":
        abort(403)
    if order.status in ("delivered", "cancelled"):
        flash("This order cannot be released.", "danger")
        return redirect(url_for("store.orders"))
    entered = (request.form.get("code") or "").strip()
    if entered and order.pickup_code and entered == order.pickup_code:
        order.status = "delivered"
        order.picked_up_at = datetime.utcnow()
        db.session.add(Notification(
            user_id=order.user_id,
            title=f"Order #{order.id} picked up",
            message=f"Collected from {store.name}. Thank you!",
        ))
        db.session.commit()
        flash(f"Order #{order.id} verified and released.", "success")
    else:
        flash("Incorrect pickup code — order was not released.", "danger")
    return redirect(url_for("store.orders"))


@bp.route("/inventory", methods=["GET", "POST"])
def inventory():
    store = _my_store()
    q = (request.args.get("q") or "").strip()
    if request.method == "POST":
        ids = request.form.getlist("medicine_id")
        for mid_s in ids:
            try:
                mid = int(mid_s)
            except (TypeError, ValueError):
                continue
            stock_val = request.form.get(f"stock_{mid}", type=int)
            rack_val = (request.form.get(f"rack_{mid}") or "").strip() or None
            if stock_val is None:
                continue
            stock_val = max(0, stock_val)
            row = StoreStock.query.filter_by(store_id=store.id, medicine_id=mid).first()
            if row:
                row.stock = stock_val
                row.rack_location = rack_val
            else:
                db.session.add(StoreStock(
                    store_id=store.id,
                    medicine_id=mid,
                    stock=stock_val,
                    rack_location=rack_val,
                ))
        db.session.commit()
        flash("Shelf stock updated.", "success")
        return redirect(url_for("store.inventory", q=q or None))

    query = Medicine.query
    if q:
        query = query.filter(Medicine.name.ilike(f"%{q}%"))
    medicines = query.order_by(Medicine.name).limit(80).all()
    existing = {
        r.medicine_id: r
        for r in StoreStock.query.filter_by(store_id=store.id).all()
    }
    tracked_count = len(existing)
    total_units = sum(r.stock for r in existing.values())
    return render_template(
        "store/inventory.html",
        store=store,
        medicines=medicines,
        existing=existing,
        tracked_count=tracked_count,
        total_units=total_units,
        q=q,
    )


@bp.route("/notifications")
def notifications():
    store = _my_store()
    notes = (
        Notification.query.filter_by(user_id=current_user.id)
        .order_by(Notification.created_at.desc())
        .limit(40)
        .all()
    )
    for n in notes:
        if not n.is_read:
            n.is_read = True
    db.session.commit()
    return render_template("store/notifications.html", store=store, notes=notes)
