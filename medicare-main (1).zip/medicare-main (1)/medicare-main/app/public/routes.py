from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import current_user
from app.models import Medicine, Category, Store, User, Notification
from app.extensions import db
from app.assistant import get_response, QUICK_SUGGESTIONS

bp = Blueprint("public", __name__)


@bp.route("/")
def home():
    featured = Medicine.query.order_by(Medicine.created_at.desc()).limit(8).all()
    categories = Category.query.order_by(Category.name).all()
    top_rated = Medicine.query.filter_by(requires_prescription=False).limit(3).all()
    return render_template(
        "public/home.html",
        featured=featured,
        categories=categories,
        top_rated=top_rated,
    )


@bp.route("/about")
def about():
    return render_template(
        "public/about.html",
        medicine_count=Medicine.query.count(),
        store_count=Store.query.filter_by(is_active=True).count(),
        category_count=Category.query.count(),
    )


@bp.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        name = (request.form.get("name") or "").strip()[:120]
        email = (request.form.get("email") or "").strip()[:180]
        subject = (request.form.get("subject") or "Message").strip()[:180] or "Message"
        message = (request.form.get("message") or "").strip()[:2000]
        if not name or not email or not message:
            flash("Please fill in your name, email, and message.", "warning")
            return redirect(url_for("public.contact"))
        admins = User.query.filter_by(role="admin").all()
        body = f"From {name} ({email})\n\n{message}"
        for admin in admins:
            db.session.add(Notification(
                user_id=admin.id,
                title=f"Contact: {subject}",
                message=body,
            ))
        if admins:
            db.session.commit()
            flash("Your message was sent to the pharmacy admin.", "success")
        else:
            flash("No admin account is available to receive this message.", "danger")
        return redirect(url_for("public.contact"))
    return render_template("public/contact.html")


@bp.route("/assistant/chat", methods=["POST"])
def assistant_chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", ""))[:500]  # guard against huge payloads
    result = get_response(message, current_user)
    return jsonify(result)


@bp.route("/assistant/suggestions")
def assistant_suggestions():
    return jsonify({"suggestions": QUICK_SUGGESTIONS})
