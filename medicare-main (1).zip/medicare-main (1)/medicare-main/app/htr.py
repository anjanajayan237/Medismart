"""Handwritten prescription reader (HTR = Handwritten Text Recognition).

Tesseract (see app/ocr.py) is a *printed*-text engine and is genuinely weak
on messy doctor handwriting. This module adds a second, complementary pass
using Microsoft's TrOCR model (a transformer OCR model trained specifically
on handwritten text) so messy prescriptions have a real shot at being read
instead of silently falling back to "low confidence".

Design:
    1. Tesseract's layout analysis (`image_to_data`) is still used here, but
       only to find *where* the lines of text are (bounding boxes) — that
       part works even when Tesseract can't correctly recognize the messy
       characters inside those boxes.
    2. Each detected line is cropped out and fed to TrOCR, which is far
       better than Tesseract at decoding cursive / sloppy handwriting.
    3. Results are joined back into a single block of text.

Fully optional and self-contained:
    - If `torch` / `transformers` aren't installed, or the model can't be
      downloaded/loaded, every function degrades to "unavailable" and never
      raises. The rest of the app works exactly as before.
    - The model is downloaded from HuggingFace Hub on first use (~120MB for
      the "small" model) and cached locally afterwards — after that first
      run, no internet connection is required.
"""
import os

try:
    import pytesseract
    from PIL import Image, ImageOps
    PIL_AVAILABLE = True
except ImportError:  # pragma: no cover - optional dependency
    PIL_AVAILABLE = False

try:
    import torch  # noqa: F401
    from transformers import TrOCRProcessor, VisionEncoderDecoderModel
    from transformers.utils import logging as hf_logging
    hf_logging.set_verbosity_error()  # silence routine "newly initialized weights" noise
    TRANSFORMERS_AVAILABLE = True
except Exception:  # pragma: no cover - optional dependency (or broken install)
    # Deliberately broad: a mismatched/corrupt torch install raises OSError
    # (native DLL load failures) rather than ImportError on some systems
    # (seen on Windows). Either way this feature must degrade, not crash
    # the whole app at startup.
    TRANSFORMERS_AVAILABLE = False


# Small handwritten-text checkpoint: good accuracy/speed trade-off for a
# CPU-only Flask server. Swap for "microsoft/trocr-base-handwritten" if you
# have GPU/CPU headroom and want higher accuracy.
MODEL_NAME = os.environ.get("HTR_MODEL_NAME", "microsoft/trocr-small-handwritten")

_processor = None
_model = None
_load_failed = False


def configure_htr(app):
    """Cheap availability check (no model download) run at app startup.
    Sets app.config['HTR_READY'] so routes can check without re-probing."""
    app.config["HTR_READY"] = PIL_AVAILABLE and TRANSFORMERS_AVAILABLE


def is_available():
    return PIL_AVAILABLE and TRANSFORMERS_AVAILABLE and not _load_failed


def _get_model():
    """Lazily load (and cache) the TrOCR processor/model on first real use,
    so app startup stays fast and a missing/broken model never crashes the
    server — it just disables the handwriting pass."""
    global _processor, _model, _load_failed
    if _load_failed:
        return None, None
    if _model is not None:
        return _processor, _model
    try:
        _processor = TrOCRProcessor.from_pretrained(MODEL_NAME)
        _model = VisionEncoderDecoderModel.from_pretrained(MODEL_NAME)
        _model.eval()
    except Exception:
        _load_failed = True
        return None, None
    return _processor, _model


def _segment_lines(image, max_lines=25):
    """Use Tesseract's layout analysis purely to locate text-line bounding
    boxes (not to read them). Returns a list of cropped PIL line images,
    top-to-bottom. Falls back to a single crop of the whole image if layout
    analysis finds nothing usable (e.g. very sparse/low-contrast photos)."""
    gray = ImageOps.autocontrast(image.convert("L"))
    w, h = gray.size

    try:
        data = pytesseract.image_to_data(gray, output_type=pytesseract.Output.DICT)
    except Exception:
        return [gray]

    lines = {}
    n = len(data.get("text", []))
    for i in range(n):
        word = data["text"][i].strip()
        if not word:
            continue
        key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        x, y, bw, bh = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
        box = lines.setdefault(key, [x, y, x + bw, y + bh])
        box[0] = min(box[0], x)
        box[1] = min(box[1], y)
        box[2] = max(box[2], x + bw)
        box[3] = max(box[3], y + bh)

    if not lines:
        return [gray]

    pad = 6
    crops = []
    for (x0, y0, x1, y1) in sorted(lines.values(), key=lambda b: b[1]):
        x0, y0 = max(0, x0 - pad), max(0, y0 - pad)
        x1, y1 = min(w, x1 + pad), min(h, y1 + pad)
        if x1 - x0 < 8 or y1 - y0 < 8:
            continue
        crops.append(gray.crop((x0, y0, x1, y1)))

    return crops[:max_lines] if crops else [gray]


def recognize_handwriting(file_path):
    """Full handwriting-recognition pass. Never raises — returns "" on any
    failure (missing deps, bad file, model error, etc.)."""
    if not is_available():
        return ""

    processor, model = _get_model()
    if processor is None or model is None:
        return ""

    try:
        image = Image.open(file_path).convert("RGB")
    except Exception:
        return ""

    try:
        line_images = _segment_lines(image)
    except Exception:
        line_images = [image]

    recognized = []
    for line_img in line_images:
        try:
            rgb_line = line_img.convert("RGB")
            pixel_values = processor(images=rgb_line, return_tensors="pt").pixel_values
            with torch.no_grad():
                generated_ids = model.generate(pixel_values, max_length=64)
            text = processor.batch_decode(generated_ids, skip_special_tokens=True)[0].strip()
            if text:
                recognized.append(text)
        except Exception:
            continue

    return "\n".join(recognized).strip()
