"""Shared input validation for auth + medicine forms.

Special characters are stripped (or rejected) so names, phones, and medicine
labels stay clean — passwords keep a normal character set so accounts stay
secure. Used by both the Flask routes (server-side) and mirrored by the
live form-validate.js (client-side).
"""
import re

# Letters (incl. Unicode letters for Malayalam/Indian names), digits, spaces,
# and a small safe punctuation set. Everything else is treated as "special".
_NAME_KEEP = re.compile(r"[^\w\s.'\-]", flags=re.UNICODE)
_PHONE_KEEP = re.compile(r"[^\d+\-\s()]")
_MED_TEXT_KEEP = re.compile(r"[^\w\s.\-%/+]", flags=re.UNICODE)
_DESC_KEEP = re.compile(r"[^\w\s.,;:!?'\-/%()+]", flags=re.UNICODE)
_EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")
_HAS_SPECIAL = re.compile(r"[^\w\s.'\-@]", flags=re.UNICODE)


def strip_special(value, kind="text"):
    """Remove disallowed special characters from a string."""
    if value is None:
        return ""
    value = str(value).strip()
    if kind == "name":
        cleaned = _NAME_KEEP.sub("", value)
    elif kind == "phone":
        cleaned = _PHONE_KEEP.sub("", value)
    elif kind == "medicine":
        cleaned = _MED_TEXT_KEEP.sub("", value)
    elif kind == "description":
        cleaned = _DESC_KEEP.sub("", value)
    else:
        cleaned = _NAME_KEEP.sub("", value)
    # Collapse repeated whitespace left behind after stripping.
    return re.sub(r"\s+", " ", cleaned).strip()


def validate_name(name):
    name = strip_special(name, "name")
    if not name or len(name) < 2:
        return None, "Name must be at least 2 characters."
    if len(name) > 80:
        return None, "Name is too long (max 80 characters)."
    if not re.search(r"[A-Za-z\u00C0-\u024F\u0900-\u0D7F]", name):
        return None, "Name must include letters."
    return name, None


def validate_email(email):
    email = (email or "").strip().lower()
    if not email:
        return None, "Email is required."
    if re.search(r"[<>\"'\\;]", email):
        return None, "Email contains invalid special characters."
    if not _EMAIL_RE.match(email):
        return None, "Enter a valid email address (e.g. you@example.com)."
    if len(email) > 150:
        return None, "Email is too long."
    return email, None


def validate_signup_email(email):
    """Customer signup is Gmail only, and the domain must be exactly gmail.com."""
    email, err = validate_email(email)
    if err:
        return None, err
    local, _, domain = email.partition("@")
    if domain != "gmail.com" or not local or local.startswith(".") or local.endswith(".") or ".." in local:
        return None, "Signup allows only @gmail.com addresses (must end with .com)."
    return email, None


def validate_phone(phone, required=False):
    phone = strip_special(phone or "", "phone")
    if not phone:
        return (None, "Phone number is required.") if required else ("", None)
    digits = re.sub(r"\D", "", phone)
    if len(digits) < 10 or len(digits) > 15:
        return None, "Phone must have 10–15 digits."
    return phone, None


def validate_address(address, required=False):
    address = strip_special(address or "", "description")
    if not address:
        return (None, "Address is required.") if required else ("", None)
    if len(address) < 5:
        return None, "Address looks too short."
    if len(address) > 255:
        return None, "Address is too long."
    return address, None


def validate_password(password, confirm=None):
    password = password or ""
    if len(password) < 6:
        return None, "Password must be at least 6 characters."
    if len(password) > 72:
        return None, "Password is too long (max 72 characters)."
    # Block only a few control / injection-prone characters — normal specials
    # like !@# are fine for passwords.
    if re.search(r"[\x00-\x1f<>]", password):
        return None, "Password contains invalid characters."
    if confirm is not None and password != confirm:
        return None, "Passwords do not match."
    return password, None


def validate_medicine_name(name):
    name = strip_special(name, "medicine")
    if not name or len(name) < 2:
        return None, "Medicine name must be at least 2 characters."
    if len(name) > 150:
        return None, "Medicine name is too long."
    return name, None


def validate_medicine_brand(brand):
    brand = strip_special(brand or "", "medicine")
    if brand and len(brand) > 100:
        return None, "Brand name is too long."
    return brand, None


def validate_medicine_unit(unit):
    unit = strip_special(unit or "pack", "medicine") or "pack"
    if len(unit) > 40:
        return None, "Unit label is too long."
    return unit, None


def validate_medicine_description(description):
    description = strip_special(description or "", "description")
    if len(description) > 2000:
        return None, "Description is too long."
    return description, None


def password_strength(password):
    """Return a 0–4 score used by the animated strength meter."""
    password = password or ""
    score = 0
    if len(password) >= 6:
        score += 1
    if len(password) >= 10:
        score += 1
    if re.search(r"[A-Z]", password) and re.search(r"[a-z]", password):
        score += 1
    if re.search(r"\d", password):
        score += 1
    if re.search(r"[^A-Za-z0-9]", password):
        score += 1
    return min(score, 4)
