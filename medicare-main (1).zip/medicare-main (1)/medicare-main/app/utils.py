import os
import random
from flask import current_app
from werkzeug.utils import secure_filename


def format_inr(value):
    """Format a number as Indian Rupees with Indian-style digit grouping
    (lakh/crore commas), e.g. 123456.5 -> '₹1,23,456.50'. Used as the
    `|inr` Jinja filter registered in app/__init__.py — this project is
    Kerala-based, so all prices/totals are shown in INR, not USD."""
    try:
        value = float(value or 0)
    except (TypeError, ValueError):
        value = 0.0
    negative = value < 0
    value = abs(value)
    rupees = int(value)
    paise = round((value - rupees) * 100)
    if paise == 100:
        rupees += 1
        paise = 0

    s = str(rupees)
    if len(s) > 3:
        last3, rest = s[-3:], s[:-3]
        groups = []
        while len(rest) > 2:
            groups.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            groups.insert(0, rest)
        grouped = ",".join(groups) + "," + last3
    else:
        grouped = s

    formatted = f"\u20b9{grouped}.{paise:02d}"
    return f"-{formatted}" if negative else formatted


def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower()
        in current_app.config["ALLOWED_EXTENSIONS"]
    )


def save_upload(file_storage, subfolder="prescriptions"):
    """Save an uploaded file under static/uploads/<subfolder>/ and return the
    web-relative path (e.g. 'uploads/prescriptions/abc.png')."""
    if not file_storage or file_storage.filename == "":
        return None
    filename = secure_filename(file_storage.filename)
    base = current_app.config["UPLOAD_FOLDER"]
    target_dir = os.path.join(base, subfolder)
    os.makedirs(target_dir, exist_ok=True)
    # avoid collisions
    i = 1
    final = filename
    while os.path.exists(os.path.join(target_dir, final)):
        name, ext = os.path.splitext(filename)
        final = f"{name}_{i}{ext}"
        i += 1
    file_storage.save(os.path.join(target_dir, final))
    return f"uploads/{subfolder}/{final}"


def paginate(query, page, per_page=10):
    page = max(1, int(page or 1))
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    return pagination


def status_badge(status):
    """Return a Bootstrap badge class for a given status string."""
    mapping = {
        "pending": "bg-warning text-dark",
        "confirmed": "bg-info text-dark",
        "shipped": "bg-primary",
        "delivered": "bg-success",
        "cancelled": "bg-danger",
        "approved": "bg-success",
        "rejected": "bg-danger",
        "needs_info": "bg-info text-dark",
    }
    return mapping.get(status, "bg-secondary")


def generate_pickup_code():
    """6-digit numeric code shown to the customer for a Store Pickup order.
    The pharmacist types back whatever the customer tells them into the
    admin "Verify Pickup" box before releasing the medicines — nothing is
    ever displayed to store staff ahead of time, so a stranger can't just
    walk in and claim someone else's order."""
    return f"{random.randint(0, 999999):06d}"


def reverse_order_effects(order):
    """Undo everything an order placement did — restock every item,
    release the coupon usage slot, and refund/claw back loyalty points —
    so cancelling an order (by the admin or the customer) never leaves
    inventory or loyalty points out of sync. Caller is responsible for
    setting order.status and committing the session afterwards.

    Safe to call at most once per order (call only on the transition INTO
    'cancelled', not on every save) — calling it twice would double-restock.

    Inventory policy (mirrors checkout):
      - Any order with store_id (pickup or delivery dispatch) → restock that
        branch's StoreStock
      - Legacy delivery with no store → restock Medicine.stock
    """
    from app.models import Coupon  # local import: avoids any import-order issues

    from_store = bool(order.store_id)

    for item in order.items:
        if not item.medicine:
            continue
        if from_store:
            row = next(
                (s for s in item.medicine.store_stocks if s.store_id == order.store_id),
                None,
            )
            if row:
                row.stock += item.quantity
        else:
            item.medicine.stock += item.quantity

    if order.coupon_code:
        coupon = Coupon.query.filter_by(code=order.coupon_code).first()
        if coupon and coupon.used_count > 0:
            coupon.used_count -= 1

    user = order.user
    if user:
        # Refund any points the customer redeemed, and claw back the points
        # they earned on this order — never let the balance go negative in
        # case some of those points were already spent elsewhere.
        user.loyalty_points += order.points_redeemed
        user.loyalty_points = max(0, user.loyalty_points - order.points_earned)


def notify_store_staff(store_id, title, message):
    """Push an in-app notification to every staff account for a branch."""
    from app.extensions import db
    from app.models import User, Notification

    if not store_id:
        return
    for staff in User.query.filter_by(role="store", store_id=store_id).all():
        db.session.add(Notification(
            user_id=staff.id,
            title=title,
            message=message,
        ))
