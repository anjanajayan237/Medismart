from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app.extensions import db
from app.models import User
from app.validation import (
    validate_name, validate_email, validate_signup_email, validate_phone, validate_address, validate_password,
)

bp = Blueprint("auth", __name__, url_prefix="/auth")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(_home_for(current_user))
    form = {"email": ""}
    if request.method == "POST":
        email, email_err = validate_email(request.form.get("email", ""))
        password = request.form.get("password", "")
        remember = bool(request.form.get("remember"))
        form["email"] = request.form.get("email", "")
        if email_err:
            flash(email_err, "danger")
            return render_template("auth/login.html", form=form)
        if not password:
            flash("Password is required.", "danger")
            return render_template("auth/login.html", form=form)
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            if not user.is_active_user:
                flash("This account has been disabled. Please contact support.", "danger")
                return render_template("auth/login.html", form=form)
            login_user(user, remember=remember)
            flash("Welcome back, %s!" % user.name, "success")
            return redirect(_home_for(user))
        flash("Invalid email or password.", "danger")
    return render_template("auth/login.html", form=form)


@bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(_home_for(current_user))
    form = request.form if request.method == "POST" else {}
    if request.method == "POST":
        name, name_err = validate_name(request.form.get("name", ""))
        email, email_err = validate_signup_email(request.form.get("email", ""))
        phone, phone_err = validate_phone(request.form.get("phone", ""), required=False)
        address, address_err = validate_address(request.form.get("address", ""), required=False)
        password, password_err = validate_password(
            request.form.get("password", ""),
            confirm=request.form.get("confirm", ""),
        )
        errors = [e for e in (name_err, email_err, phone_err, address_err, password_err) if e]
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("auth/register.html", form=request.form)
        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "danger")
            return render_template("auth/register.html", form=request.form)
        user = User(name=name, email=email, phone=phone or None, address=address or None, role="user")
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash("Account created. Please log in.", "success")
        return redirect(url_for("auth.login"))
    return render_template("auth/register.html", form=form)


@bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email, email_err = validate_email(request.form.get("email", ""))
        if email_err:
            flash(email_err, "danger")
            return render_template("auth/forgot_password.html")
        user = User.query.filter_by(email=email).first()
        # Always show the same message to avoid leaking accounts.
        flash("If that email exists, a reset link has been sent.", "info")
        if user:
            current_app.logger.info("Password reset requested for user %s", user.id)
        return redirect(url_for("auth.login"))
    return render_template("auth/forgot_password.html")


@bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.login"))


def _home_for(user):
    if user.is_admin:
        return url_for("admin.dashboard")
    if getattr(user, "is_store_staff", False):
        return url_for("store.dashboard")
    return url_for("user.dashboard")
