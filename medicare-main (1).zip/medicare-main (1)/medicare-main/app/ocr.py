"""AI-assisted prescription reader.

Runs local OCR (Tesseract, via pytesseract) on uploaded prescription photos
and fuzzy-matches the extracted text against the medicine catalog. Fully
offline — no external API calls, no API key required. Degrades gracefully
(never raises) when the OCR engine isn't installed or the file is a PDF.

Messy / handwritten prescriptions: Tesseract alone is weak on handwriting.
Two complementary passes can be layered on top, tried in priority order:
  1. app.gemini_ocr — cloud (free-tier Gemini), by far the most reliable on
     genuinely messy doctor cursive, when a GEMINI_API_KEY is configured.
  2. app.htr — a local TrOCR handwriting model, used when Gemini isn't
     configured/available (fully offline fallback, lower accuracy).
Both are optional; with neither, this module behaves exactly like plain
Tesseract OCR. See app/gemini_ocr.py and app/htr.py.
"""
import os
import re
import shutil
import difflib

from app import htr
from app import gemini_ocr

try:
    import pytesseract
    from PIL import Image, ImageOps, ImageFilter
    PIL_AVAILABLE = True
except ImportError:  # pragma: no cover - optional dependency
    PIL_AVAILABLE = False


IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "bmp", "tiff"}

DOSAGE_PATTERN = re.compile(
    r"(\d+\s?(?:mg|mcg|ml|g|iu)\b|\b(?:once|twice|thrice)\s*(?:a|per)?\s*day\b|\bOD\b|\bBD\b|\bTDS\b|\bQID\b)",
    re.IGNORECASE,
)


def configure_tesseract(app):
    """Locate the Tesseract OCR binary and wire it into pytesseract.
    Sets app.config['TESSERACT_READY'] so the rest of the app can check
    availability without re-probing the filesystem on every request."""
    if not PIL_AVAILABLE:
        app.config["TESSERACT_READY"] = False
        return

    home = os.path.expanduser("~")
    candidates = [
        app.config.get("TESSERACT_CMD"),
        os.environ.get("TESSERACT_CMD"),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        os.path.join(home, r"AppData\Local\Programs\Tesseract-OCR\tesseract.exe"),
        os.path.join(home, r"AppData\Local\Tesseract-OCR\tesseract.exe"),
        "/usr/bin/tesseract",
        "/usr/local/bin/tesseract",
        "/opt/homebrew/bin/tesseract",
    ]
    for path in candidates:
        if path and os.path.exists(path):
            pytesseract.pytesseract.tesseract_cmd = path
            app.config["TESSERACT_READY"] = True
            app.config["TESSERACT_CMD"] = path
            return

    on_path = shutil.which("tesseract")
    if on_path:
        pytesseract.pytesseract.tesseract_cmd = on_path
        app.config["TESSERACT_READY"] = True
        app.config["TESSERACT_CMD"] = on_path
        return

    app.config["TESSERACT_READY"] = False


def _preprocess(image):
    """Grayscale + autocontrast + sharpen + upscale small photos — noticeably
    improves OCR accuracy on phone-camera prescription photos."""
    img = image.convert("L")
    img = ImageOps.autocontrast(img)
    img = img.filter(ImageFilter.SHARPEN)
    w, h = img.size
    if max(w, h) < 1400:
        scale = 1400 / max(w, h)
        img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
    return img


def _extract_text(file_path):
    image = Image.open(file_path)
    processed = _preprocess(image)
    return pytesseract.image_to_string(processed).strip()


def _find_dosage_near(text, index):
    window = text[max(0, index - 25): index + 45]
    m = DOSAGE_PATTERN.search(window)
    return m.group(0) if m else None


# Strip strength / form noise so "Paracetamol 500mg" and "paracetamol tab"
# compare on the core drug name.
_DOSAGE_STRIP = re.compile(
    r"\b(\d+([./]\d+)?\s*(mg|mcg|µg|ug|g|ml|iu|%|units?)|tab(?:let)?s?|cap(?:sule)?s?|"
    r"syrup|susp(?:ension)?|inj(?:ection)?|cream|gel|ointment|drops?|sachet|inhaler|pen)\b",
    re.IGNORECASE,
)
_NON_ALNUM = re.compile(r"[^a-z0-9\s\-]+")

# Common Indian brand / synonym → catalog drug stem (lowercase).
DRUG_ALIASES = {
    "crocin": "paracetamol",
    "dolo": "paracetamol",
    "calpol": "paracetamol",
    "acetaminophen": "paracetamol",
    "tylenol": "paracetamol",
    "brufen": "ibuprofen",
    "combiflam": "ibuprofen",
    "mox": "amoxicillin",
    "moxikind": "amoxicillin",
    "novamox": "amoxicillin",
    "amox": "amoxicillin",
    "azee": "azithromycin",
    "azithral": "azithromycin",
    "zithrox": "azithromycin",
    "glycomet": "metformin",
    "glucophage": "metformin",
    # Common OCR / cursive misreads of Metformin
    "methomin": "metformin",
    "metformine": "metformin",
    "metfromin": "metformin",
    "metformim": "metformin",
    "metfomin": "metformin",
    "atorva": "atorvastatin",
    "lipitor": "atorvastatin",
    "storvas": "atorvastatin",
    "asthalin": "salbutamol",
    "ventolin": "salbutamol",
    "albuterol": "salbutamol",
    "lantus": "insulin",
    "basalog": "insulin",
    "ascorbic": "vitamin c",
    "cholecalciferol": "vitamin d",
    "limcee": "vitamin c",
    "shelcal": "calcium",
    "pantop": "pantoprazole",
    "pantocid": "pantoprazole",
    "omez": "omeprazole",
    "omeprazole": "omeprazole",
    "rantac": "ranitidine",
    "cetrizine": "cetirizine",
    "cetzine": "cetirizine",
    "okacet": "cetirizine",
    "allegra": "fexofenadine",
    "montair": "montelukast",
    "telekast": "montelukast",
    "augmentin": "amoxicillin",
    "clavam": "amoxicillin",
    "cipro": "ciprofloxacin",
    "ciplox": "ciprofloxacin",
    "norflox": "norfloxacin",
    "taxim": "cefixime",
    "monocef": "ceftriaxone",
    "ecosprin": "aspirin",
    "disprin": "aspirin",
    "voveran": "diclofenac",
    "diclo": "diclofenac",
    "thyronorm": "thyroxine",
    "eltroxin": "thyroxine",
    "levothyroxine": "thyroxine",
    "amlopres": "amlodipine",
    "stamlo": "amlodipine",
    "telma": "telmisartan",
    "losar": "losartan",
}


def _normalize_drug_label(text):
    """Lowercase + strip dosage/form tokens for fuzzy comparison."""
    if not text:
        return ""
    t = text.lower().strip()
    t = _DOSAGE_STRIP.sub(" ", t)
    t = _NON_ALNUM.sub(" ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def _expand_aliases(label):
    """Return label plus any known brand→generic expansions."""
    out = {label}
    base = _normalize_drug_label(label)
    if base:
        out.add(base)
    # whole-string alias
    if base in DRUG_ALIASES:
        out.add(DRUG_ALIASES[base])
    # first-token alias (e.g. "crocin 500" → paracetamol)
    first = base.split(" ", 1)[0] if base else ""
    if first in DRUG_ALIASES:
        out.add(DRUG_ALIASES[first])
    return {x for x in out if x}


def _similarity(a, b):
    """Return (score, strong) where strong=True means containment/alias-quality
    match (safe at lower thresholds). Plain SequenceMatcher-only hits need a
    higher score to avoid false positives like crocin→ciprofloxacin."""
    if not a or not b:
        return 0.0, False
    if a == b:
        return 1.0, True

    base = difflib.SequenceMatcher(None, a, b).ratio()
    strong = False
    score = base

    stem_a = re.sub(r"[^a-z]", "", a)
    stem_b = re.sub(r"[^a-z]", "", b)
    if stem_a and stem_b:
        shorter, longer = (stem_a, stem_b) if len(stem_a) <= len(stem_b) else (stem_b, stem_a)
        # Whole-stem containment (paracetamol in paracetamolxxx) — not tiny
        # substrings like "some" inside longer words.
        if len(shorter) >= 5 and (longer == shorter or longer.startswith(shorter) or longer.endswith(shorter) or f" {shorter} " in f" {longer} "):
            score = max(score, 0.92)
            strong = True
        elif len(shorter) >= 6 and shorter in longer:
            score = max(score, 0.90)
            strong = True

    def _drug_tokens(s):
        out = set()
        for t in s.split():
            if len(t) < 4 or re.search(r"\d", t):
                continue
            if t in {"tablet", "tablets", "capsule", "capsules", "syrup", "before", "after", "food", "days", "some", "obscure", "drug", "and"}:
                continue
            out.add(t)
        return out

    ta, tb = _drug_tokens(a), _drug_tokens(b)
    if ta and tb:
        inter = ta & tb
        if inter and any(len(t) >= 5 for t in inter):
            overlap = len(inter) / max(len(ta), len(tb))
            score = max(score, 0.7 + 0.3 * overlap)
            strong = True

    return min(score, 1.0), strong


def _catalog_labels(medicines):
    """Build (label, medicine) pairs including normalized + alias forms."""
    catalog = []
    for m in medicines:
        labels = set()
        for raw in filter(None, [m.name, m.brand]):
            labels |= _expand_aliases(raw)
            labels.add(raw.lower())
            labels.add(_normalize_drug_label(raw))
        for label in labels:
            if label and len(label) >= 3:
                catalog.append((label, m))
    return catalog


def _match_medicines(ocr_text, medicines, min_ratio=0.78, max_results=8):
    """Fuzzy-match OCR text against the medicine catalog (name + brand + aliases)."""
    if not ocr_text:
        return []

    catalog = _catalog_labels(medicines)
    if not catalog:
        return []

    lines = [l.strip() for l in ocr_text.splitlines() if l.strip()]
    candidates = set()
    for line in lines:
        candidates.add(line.lower())
        candidates.add(_normalize_drug_label(line))
        candidates |= _expand_aliases(line)
        words = re.findall(r"[a-zA-Z][a-zA-Z0-9\-]{2,}", line)
        for n in (1, 2, 3):
            for i in range(len(words) - n + 1):
                phrase = " ".join(words[i:i + n]).lower()
                candidates.add(phrase)
                candidates.add(_normalize_drug_label(phrase))
                candidates |= _expand_aliases(phrase)

    lower_text = ocr_text.lower()
    best_per_medicine = {}
    for cand in candidates:
        if len(cand) < 3:
            continue
        for label, medicine in catalog:
            ratio, strong = _similarity(cand, label)
            need = 0.72 if strong else min_ratio
            if ratio < need:
                continue
            existing = best_per_medicine.get(medicine.id)
            if not existing or ratio > existing["confidence"]:
                idx = lower_text.find(cand)
                best_per_medicine[medicine.id] = {
                    "medicine": medicine,
                    "matched_text": cand,
                    "confidence": min(ratio, 1.0),
                    "dosage_hint": _find_dosage_near(ocr_text, idx if idx >= 0 else 0),
                }

    results = sorted(best_per_medicine.values(), key=lambda r: r["confidence"], reverse=True)
    return _prefer_primary_matches(results, max_results)


def _prefer_primary_matches(results, max_results=8):
    """When a bare drug name matches both 'Metformin 500mg' and
    'Metformin + Glimepiride', prefer the simple (non-combo) products."""
    if not results:
        return []
    adjusted = []
    for r in results:
        name = r["medicine"].name.lower()
        cand = (r.get("matched_text") or "").lower()
        conf = r["confidence"]
        if "+" in name and "+" not in cand and "clav" not in cand:
            conf = max(0.0, conf - 0.12)
        adjusted.append({**r, "confidence": conf})
    adjusted.sort(key=lambda x: x["confidence"], reverse=True)
    # Drop very weak leftovers after combo penalty
    adjusted = [r for r in adjusted if r["confidence"] >= 0.70]
    return adjusted[:max_results]


def _match_medicines_from_candidates(candidates, medicines, min_ratio=0.75, max_results=8):
    """Fuzzy-match clean AI-extracted names against the catalog (+ aliases)."""
    catalog = _catalog_labels(medicines)
    if not catalog:
        return []

    best_per_medicine = {}
    for cand in candidates:
        variants = _expand_aliases(cand) | {_normalize_drug_label(cand), (cand or "").strip().lower()}
        for cand_l in variants:
            if len(cand_l) < 3:
                continue
            for label, medicine in catalog:
                ratio, strong = _similarity(cand_l, label)
                need = 0.70 if strong else min_ratio
                if ratio < need:
                    continue
                existing = best_per_medicine.get(medicine.id)
                if not existing or ratio > existing["confidence"]:
                    best_per_medicine[medicine.id] = {
                        "medicine": medicine,
                        "matched_text": cand,
                        "confidence": min(ratio, 1.0),
                        "dosage_hint": None,
                    }
    results = sorted(best_per_medicine.values(), key=lambda r: r["confidence"], reverse=True)
    return _prefer_primary_matches(results, max_results)


DOCTOR_KEYWORDS = re.compile(
    r"\b(dr\.?|doctor|physician|clinic|hospital|medical\s*(centre|center)|pharmacy|health\s*care)\b",
    re.IGNORECASE,
)
REG_NO_PATTERN = re.compile(r"\b(reg(?:istration)?\.?\s*no\.?|license\s*no\.?|mci\s*no\.?)\s*[:.\-]?\s*\w+", re.IGNORECASE)
DATE_PATTERN = re.compile(r"\b\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}\b")
RX_MARKER_PATTERN = re.compile(r"\b(rx|prescription|sig\.?|take|tab\.?|cap\.?)\b", re.IGNORECASE)


def _assess_authenticity(ocr_text, matches):
    """Rule-based genuineness signal for an uploaded prescription photo.

    This is a transparent, explainable heuristic (not a deep fraud model):
    it looks for the kinds of information a real prescription almost always
    carries — a doctor/clinic reference, a registration/license number, a
    date, prescription-style shorthand, and at least one recognizable
    medicine — and scores how many of those signals are present. It is a
    convenience aid for pharmacists, not a replacement for their review.
    """
    if not ocr_text:
        return 0.0, "low_confidence", ["No readable text was extracted from the image."]

    reasons = []
    score = 0.0

    if DOCTOR_KEYWORDS.search(ocr_text):
        score += 0.25
        reasons.append("Mentions a doctor / clinic / hospital.")
    else:
        reasons.append("No doctor, clinic, or hospital reference detected.")

    if REG_NO_PATTERN.search(ocr_text):
        score += 0.15
        reasons.append("Contains a registration/license number.")
    else:
        reasons.append("No registration or license number detected.")

    if DATE_PATTERN.search(ocr_text):
        score += 0.15
        reasons.append("Contains a date.")
    else:
        reasons.append("No date detected on the document.")

    if RX_MARKER_PATTERN.search(ocr_text):
        score += 0.10
        reasons.append("Contains prescription-style shorthand (Rx/Sig/Tab/Cap).")

    if matches:
        score += 0.20
        reasons.append(f"{len(matches)} medicine name(s) recognized from our catalog.")
    else:
        reasons.append("No known medicines were recognized in the text.")

    if len(ocr_text.strip()) >= 40:
        score += 0.15
        reasons.append("Sufficient readable text volume.")
    else:
        reasons.append("Very little readable text was extracted — image may be unclear.")

    score = round(min(1.0, score), 2)
    if score >= 0.7:
        label = "likely_genuine"
    elif score >= 0.4:
        label = "needs_review"
    else:
        label = "low_confidence"
    return score, label, reasons


def _build_summary(ocr_text, matches):
    if not ocr_text:
        return "No readable text was detected in this file. A pharmacist will review it manually."
    if not matches:
        return (
            "Text was extracted, but none of the detected drug names match medicines currently "
            "in the MediSmart catalog. A pharmacist will still review this prescription manually."
        )
    names = ", ".join(m["medicine"].name for m in matches[:4])
    more = "" if len(matches) <= 4 else f" and {len(matches) - 4} more"
    return f"AI detected possible mentions of: {names}{more}. Please confirm with your pharmacist before ordering."


def _build_gemini_summary(catalog_matches, unmatched_names, notes):
    parts = []
    if catalog_matches:
        names = ", ".join(m["medicine"].name for m in catalog_matches[:4])
        more = "" if len(catalog_matches) <= 4 else f" and {len(catalog_matches) - 4} more"
        parts.append(f"Matched in catalog: {names}{more}.")
    if unmatched_names:
        listed = ", ".join(unmatched_names[:6])
        if catalog_matches:
            parts.append(f"Also read (not in catalog yet): {listed}.")
        else:
            parts.append(
                f"AI read these medicines: {listed} — they are not in the MediSmart catalog yet, "
                f"so nothing was auto-matched. A pharmacist will review manually."
            )
    if not parts:
        parts.append("AI could not confidently identify any medicines in this image.")
    if notes:
        parts.append(notes)
    parts.append("Please confirm with your pharmacist before ordering.")
    return " ".join(parts)


def _merge_matches(match_lists):
    """Union multiple match lists (e.g. from Tesseract and the handwriting
    model), keeping the highest-confidence hit per medicine."""
    best = {}
    for matches in match_lists:
        for m in matches:
            mid = m["medicine"].id
            existing = best.get(mid)
            if not existing or m["confidence"] > existing["confidence"]:
                best[mid] = m
    return sorted(best.values(), key=lambda r: r["confidence"], reverse=True)


def analyze_prescription_file(file_path, medicines, tesseract_ready, htr_ready=False, gemini_ready=False):
    """Full OCR + matching pipeline. Always returns a result dict and never
    raises — any failure degrades to a friendly 'manual review' message.

    Engines, tried in priority order for reading the handwriting:
      1. app.gemini_ocr (cloud, free tier) — by far the most reliable on
         messy doctor cursive, when configured. Deliberately scoped to
         medicines only (not patient/doctor names).
      2. app.htr (local TrOCR) — offline fallback, used only when Gemini
         isn't configured/available, since it's much slower and far less
         accurate on genuinely messy handwriting.
    Tesseract always runs too (fast) — it reads the printed header well
    (doctor/clinic/date/reg-no) for the authenticity check, and acts as a
    second source of medicine matches regardless of which path is used.

    Returns: {status, ocr_text, summary, confidence, matches, ...}
      status: processed | unavailable | failed
      matches: [{medicine, matched_text, confidence, dosage_hint}, ...]
    """
    if not PIL_AVAILABLE:
        return {
            "status": "unavailable",
            "ocr_text": None,
            "summary": (
                "AI analysis is unavailable (image library not installed). "
                "Your prescription has still been submitted for manual pharmacist review."
            ),
            "confidence": None,
            "matches": [],
            "authenticity_score": None,
            "authenticity_label": None,
            "authenticity_reasons": [],
        }

    # Need at least one reader: Gemini (preferred), Tesseract, or local HTR.
    if not (gemini_ready or tesseract_ready or htr_ready):
        return {
            "status": "unavailable",
            "ocr_text": None,
            "summary": (
                "AI analysis is unavailable on this server (no OCR/AI engine ready). "
                "Install Tesseract or configure Gemini, then retry. "
                "Your prescription has still been submitted for manual pharmacist review."
            ),
            "confidence": None,
            "matches": [],
            "authenticity_score": None,
            "authenticity_label": None,
            "authenticity_reasons": [],
        }

    ext = file_path.rsplit(".", 1)[-1].lower() if "." in file_path else ""
    if ext not in IMAGE_EXTENSIONS:
        return {
            "status": "unavailable",
            "ocr_text": None,
            "summary": (
                "AI analysis works on photo uploads (JPG/PNG/GIF). This file is a PDF, "
                "so a pharmacist will review it manually."
            ),
            "confidence": None,
            "matches": [],
            "authenticity_score": None,
            "authenticity_label": None,
            "authenticity_reasons": [],
        }

    tesseract_text = ""
    tesseract_matches = []
    if tesseract_ready:
        try:
            tesseract_text = _extract_text(file_path)
        except Exception:
            tesseract_text = ""
        try:
            tesseract_matches = _match_medicines(tesseract_text, medicines)
        except Exception:
            tesseract_matches = []

    # --- Tier 1: Gemini FIRST (best on cursive / cropped drug-name photos) ---
    gemini_result = None
    if gemini_ready:
        try:
            gemini_result = gemini_ocr.extract_medicines(file_path)
        except Exception:
            gemini_result = None

    if gemini_result is not None and gemini_result.get("medicines"):
        gem_medicines = gemini_result["medicines"]
        candidates = []
        for gm in gem_medicines:
            candidates.append(gm["name"])
            if gm["raw_text"] and gm["raw_text"].lower() != gm["name"].lower():
                candidates.append(gm["raw_text"])

        gemini_catalog_matches = _match_medicines_from_candidates(candidates, medicines)

        # Attach dosage/frequency straight from Gemini's structured output.
        by_text = {}
        for gm in gem_medicines:
            hint = " ".join(filter(None, [gm.get("dosage"), gm.get("frequency")])) or None
            by_text[gm["name"].lower()] = hint
            by_text[(gm.get("raw_text") or "").lower()] = hint
        for m in gemini_catalog_matches:
            m["dosage_hint"] = by_text.get((m["matched_text"] or "").lower())

        matches = _merge_matches([gemini_catalog_matches, tesseract_matches])

        unmatched_names = []
        for gm in gem_medicines:
            hit = _match_medicines_from_candidates(
                [gm["name"], gm.get("raw_text") or ""], medicines, min_ratio=0.62, max_results=1
            )
            if not hit:
                unmatched_names.append(gm["name"])

        combined_text = "\n".join(t for t in (
            tesseract_text,
            "\n".join(f"{gm['name']} {gm.get('dosage') or ''} {gm.get('frequency') or ''}".strip() for gm in gem_medicines),
        ) if t)

        if matches:
            confidence = round(sum(m["confidence"] for m in matches) / len(matches), 2)
        elif gem_medicines:
            confidence = 0.5  # AI read medicine names, just none matched our catalog
        else:
            confidence = 0.25 if combined_text.strip() else 0.0

        auth_score, auth_label, auth_reasons = _assess_authenticity(combined_text, matches)
        auth_reasons.append("Handwriting read using Gemini AI vision (cloud), scoped to medicines only.")

        display_sections = []
        if tesseract_text:
            display_sections.append("— Printed-text OCR (Tesseract) —\n" + tesseract_text)
        if gem_medicines:
            gem_lines = "\n".join(
                f"- {gm['name']}" + (f" ({gm['dosage']})" if gm.get("dosage") else "")
                + (f" — {gm['frequency']}" if gm.get("frequency") else "")
                for gm in gem_medicines
            )
            display_sections.append("— Medicines read by Gemini AI (handwriting) —\n" + gem_lines)
        if gemini_result.get("notes"):
            display_sections.append("— AI note —\n" + gemini_result["notes"])

        return {
            "status": "processed",
            "ocr_text": "\n\n".join(display_sections) or None,
            "summary": _build_gemini_summary(gemini_catalog_matches, unmatched_names, gemini_result.get("notes")),
            "confidence": confidence,
            "matches": matches,
            "authenticity_score": auth_score,
            "authenticity_label": auth_label,
            "authenticity_reasons": auth_reasons,
        }

    # --- Tier 2: local HTR (TrOCR) fallback, only when Gemini unavailable ---
    htr_text = ""
    if htr_ready:
        try:
            htr_text = htr.recognize_handwriting(file_path)
        except Exception:
            htr_text = ""

    if not tesseract_text and not htr_text:
        return {
            "status": "failed",
            "ocr_text": None,
            "summary": "AI analysis could not process this image. A pharmacist will review it manually.",
            "confidence": None,
            "matches": [],
            "authenticity_score": None,
            "authenticity_label": None,
            "authenticity_reasons": [],
        }

    htr_matches = []
    if htr_text:
        try:
            htr_matches = _match_medicines(htr_text, medicines)
        except Exception:
            htr_matches = []

    matches = _merge_matches([tesseract_matches, htr_matches])
    combined_text = "\n".join(t for t in (tesseract_text, htr_text) if t)

    if matches:
        confidence = round(sum(m["confidence"] for m in matches) / len(matches), 2)
    else:
        confidence = 0.25 if combined_text else 0.0

    auth_score, auth_label, auth_reasons = _assess_authenticity(combined_text, matches)

    tesseract_ids = {m["medicine"].id for m in tesseract_matches}
    extra_from_htr = sum(1 for m in htr_matches if m["medicine"].id not in tesseract_ids)
    if extra_from_htr:
        auth_reasons.append(
            f"Handwriting-recognition model decoded {extra_from_htr} additional item(s) "
            "that the standard OCR missed."
        )

    display_sections = []
    if tesseract_text:
        display_sections.append("— Printed-text OCR (Tesseract) —\n" + tesseract_text)
    if htr_text:
        display_sections.append("— Handwriting model (TrOCR) —\n" + htr_text)
    ocr_text_display = "\n\n".join(display_sections) or None

    return {
        "status": "processed",
        "ocr_text": ocr_text_display,
        "summary": _build_summary(combined_text, matches),
        "confidence": confidence,
        "matches": matches,
        "authenticity_score": auth_score,
        "authenticity_label": auth_label,
        "authenticity_reasons": auth_reasons,
    }
