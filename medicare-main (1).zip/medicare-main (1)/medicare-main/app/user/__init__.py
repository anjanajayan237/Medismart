from app.user.routes import bp  # noqa: F401
