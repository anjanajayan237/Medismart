import os
import random
import re
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, current_app, session, jsonify
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.extensions import db
from app.models import (
    Medicine, Category, CartItem, Order, OrderItem, Prescription, PrescriptionMatch,
    Coupon, Review, Notification, Store, StoreStock,
)
from app.utils import (
    save_upload, paginate, status_badge, reverse_order_effects,
    generate_pickup_code, notify_store_staff,
)
from app.ocr import analyze_prescription_file

bp = Blueprint("user", __name__, url_prefix="/user")


@bp.before_request
@login_required
def require_user():
    if current_user.is_admin:
        return redirect(url_for("admin.dashboard"))
    if getattr(current_user, "role", None) == "store":
        return redirect(url_for("store.dashboard"))


@bp.route("/dashboard")
def dashboard():
    recent_orders = (
        Order.query.filter_by(user_id=current_user.id)
        .order_by(Order.created_at.desc())
        .limit(5)
        .all()
    )
    prescriptions = (
        Prescription.query.filter_by(user_id=current_user.id)
        .order_by(Prescription.created_at.desc())
        .limit(5)
        .all()
    )
    notifications = (
        Notification.query.filter_by(user_id=current_user.id)
        .order_by(Notification.created_at.desc())
        .limit(5)
        .all()
    )
    recommended = Medicine.query.filter_by(requires_prescription=False).limit(4).all()
    cart_count = sum(c.quantity for c in current_user.cart_items)
    return render_template(
        "user/dashboard.html",
        recent_orders=recent_orders,
        prescriptions=prescriptions,
        notifications=notifications,
        recommended=recommended,
        cart_count=cart_count,
        status_badge=status_badge,
    )


@bp.route("/medicines")
def medicines():
    """Browse full catalog. Optional nearby-shop filter shows only medicines
    that are in stock on that branch's shelf — so customers can explore →
    pick a nearby shop → add items → checkout with that shop pre-selected."""
    from app.geo import resolve_customer_point, haversine_km, store_coords, format_distance, districts_match

    q = request.args.get("q", "").strip()
    category_id = request.args.get("category", type=int)
    sort = request.args.get("sort", "newest")
    page = request.args.get("page", 1, type=int)
    store_id = request.args.get("store_id", type=int)
    nearby_district = (request.args.get("nearby_district") or "").strip() or None
    lat = request.args.get("lat")
    lng = request.args.get("lng")

    today = datetime.utcnow().date()
    query = Medicine.query.filter(
        db.or_(Medicine.expiry_date.is_(None), Medicine.expiry_date >= today)
    )
    if q:
        query = query.filter(Medicine.name.ilike(f"%{q}%"))
    if category_id:
        query = query.filter_by(category_id=category_id)

    active_stores = Store.query.filter_by(is_active=True).order_by(Store.name).all()
    # District pick and GPS are separate modes. A chosen city must not be
    # overridden by a leftover GPS coordinate.
    if nearby_district:
        clat, clng, loc_source = resolve_customer_point(None, None, nearby_district, None)
    else:
        clat, clng, loc_source = resolve_customer_point(lat, lng, None, current_user.address)

    # Rank shops: in the chosen district first, then nearby by distance.
    ranked_stores = []
    district_key = (nearby_district or "").strip().lower()
    for s in active_stores:
        dist = None
        coords = store_coords(s)
        if clat is not None and clng is not None and coords:
            dist = haversine_km(clat, clng, coords[0], coords[1])
        same = districts_match(district_key, s.district)
        ranked_stores.append({
            "store": s,
            "distance_km": dist,
            "distance_label": format_distance(dist),
            "same_district": same,
        })
    ranked_stores.sort(
        key=lambda r: (
            0 if r["same_district"] else 1,
            r["distance_km"] is None,
            r["distance_km"] if r["distance_km"] is not None else 99999,
            r["store"].name,
        )
    )
    local_shop_count = sum(1 for r in ranked_stores if r["same_district"])
    if nearby_district and local_shop_count == 0:
        location_notice = f"No shop at {nearby_district}. Nearby available shops are listed below."
    elif nearby_district:
        location_notice = (
            f"{local_shop_count} shop(s) in {nearby_district}. "
            "Nearby shops in other places are also listed."
        )
    else:
        location_notice = None

    selected_store = next((s for s in active_stores if s.id == store_id), None)
    shelf_by_med = {}
    if selected_store:
        # Only medicines with shelf stock at this shop.
        stocked_ids = [
            r.medicine_id
            for r in StoreStock.query.filter_by(store_id=selected_store.id)
            .filter(StoreStock.stock > 0)
            .all()
        ]
        if stocked_ids:
            query = query.filter(Medicine.id.in_(stocked_ids))
            shelf_by_med = {
                r.medicine_id: r
                for r in StoreStock.query.filter_by(store_id=selected_store.id).all()
            }
        else:
            query = query.filter(Medicine.id == -1)  # empty result
        session["preferred_store_id"] = selected_store.id

    if sort == "price_asc":
        query = query.order_by(Medicine.price.asc())
    elif sort == "price_desc":
        query = query.order_by(Medicine.price.desc())
    elif sort == "name":
        query = query.order_by(Medicine.name.asc())
    else:
        query = query.order_by(Medicine.created_at.desc())

    pagination = paginate(query, page, 12)
    categories = Category.query.order_by(Category.name).all()

    # Per-card shelf qty when a shop filter is active.
    med_shelf = {}
    for m in pagination.items:
        if selected_store and m.id in shelf_by_med:
            med_shelf[m.id] = shelf_by_med[m.id].stock
        else:
            med_shelf[m.id] = _sellable_units(m)

    district_choices = sorted([
        "Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam",
        "Alappuzha", "Kottayam", "Palakkad", "Malappuram", "Kannur",
        "Pathanamthitta", "Idukki", "Wayanad", "Kasaragod", "Ernakulam",
    ])
    return render_template(
        "user/medicines.html",
        medicines=pagination.items,
        pagination=pagination,
        categories=categories,
        q=q,
        category_id=category_id,
        sort=sort,
        ranked_stores=ranked_stores,
        selected_store=selected_store,
        store_id=store_id,
        nearby_district=nearby_district or "",
        district_choices=district_choices,
        customer_lat=clat,
        customer_lng=clng,
        loc_source=loc_source,
        med_shelf=med_shelf,
        location_notice=location_notice,
        local_shop_count=local_shop_count,
    )


@bp.route("/medicines/<int:medicine_id>")
def medicine_details(medicine_id):
    medicine = Medicine.query.get_or_404(medicine_id)
    related = (
        Medicine.query.filter(Medicine.id != medicine.id)
        .filter_by(category_id=medicine.category_id)
        .limit(4)
        .all()
    )
    reviews = (
        Review.query.filter_by(medicine_id=medicine.id)
        .order_by(Review.created_at.desc())
        .all()
    )
    my_review = next((r for r in reviews if r.user_id == current_user.id), None)
    has_purchased = (
        db.session.query(OrderItem)
        .join(Order, Order.id == OrderItem.order_id)
        .filter(
            Order.user_id == current_user.id,
            OrderItem.medicine_id == medicine.id,
            Order.status == "delivered",
        )
        .first()
        is not None
    )
    # Smart search: which branch(es) currently stock this medicine, and on
    # which rack — helps a customer pick a Store Pickup location before
    # they even get to checkout.
    branch_availability = [
        s for s in medicine.store_stocks if s.store and s.store.is_active
    ]
    branch_availability.sort(key=lambda s: (-s.stock, s.store.name))
    sellable = _sellable_units(medicine)
    preferred_store_id = session.get("preferred_store_id")
    return render_template(
        "user/medicine_details.html",
        medicine=medicine,
        related=related,
        reviews=reviews,
        my_review=my_review,
        has_purchased=has_purchased,
        branch_availability=branch_availability,
        sellable=sellable,
        preferred_store_id=preferred_store_id,
    )


@bp.route("/medicines/<int:medicine_id>/review", methods=["POST"])
def submit_review(medicine_id):
    medicine = Medicine.query.get_or_404(medicine_id)
    has_purchased = (
        db.session.query(OrderItem)
        .join(Order, Order.id == OrderItem.order_id)
        .filter(
            Order.user_id == current_user.id,
            OrderItem.medicine_id == medicine.id,
            Order.status == "delivered",
        )
        .first()
        is not None
    )
    if not has_purchased:
        flash("You can only review medicines from a completed (delivered) order.", "danger")
        return redirect(url_for("user.medicine_details", medicine_id=medicine.id))
    rating = max(1, min(5, int(request.form.get("rating", 5) or 5)))
    comment = request.form.get("comment", "").strip()
    review = Review.query.filter_by(medicine_id=medicine.id, user_id=current_user.id).first()
    if review:
        review.rating = rating
        review.comment = comment
        flash("Your review has been updated.", "success")
    else:
        review = Review(medicine_id=medicine.id, user_id=current_user.id, rating=rating, comment=comment)
        db.session.add(review)
        flash("Thanks for your review!", "success")
    db.session.commit()
    return redirect(url_for("user.medicine_details", medicine_id=medicine.id))


@bp.route("/medicines/<int:medicine_id>/review/delete", methods=["POST"])
def delete_review(medicine_id):
    review = Review.query.filter_by(medicine_id=medicine_id, user_id=current_user.id).first_or_404()
    db.session.delete(review)
    db.session.commit()
    flash("Review deleted.", "info")
    return redirect(url_for("user.medicine_details", medicine_id=medicine_id))


@bp.route("/cart/add/<int:medicine_id>", methods=["POST"])
def add_to_cart(medicine_id):
    medicine = Medicine.query.get_or_404(medicine_id)
    if medicine.is_expired:
        flash(f"{medicine.name} has expired and is no longer available for purchase.", "danger")
        return redirect(request.referrer or url_for("user.medicines"))

    preferred_store_id = request.form.get("store_id", type=int) or session.get("preferred_store_id")
    preferred_store = Store.query.get(preferred_store_id) if preferred_store_id else None
    if preferred_store and not preferred_store.is_active:
        preferred_store = None

    if preferred_store:
        row = preferred_store.stock_row_for(medicine_id)
        available = row.stock if row else 0
        if available <= 0:
            flash(f"{medicine.name} is out of stock at {preferred_store.name}.", "danger")
            return redirect(request.referrer or url_for("user.medicines"))
        session["preferred_store_id"] = preferred_store.id
    else:
        available = _sellable_units(medicine)
        if available <= 0:
            flash(f"{medicine.name} is currently out of stock.", "danger")
            return redirect(request.referrer or url_for("user.medicines"))

    quantity = max(1, int(request.form.get("quantity", 1)))
    item = CartItem.query.filter_by(user_id=current_user.id, medicine_id=medicine_id).first()
    already_in_cart = item.quantity if item else 0
    room_left = max(0, available - already_in_cart)
    if room_left <= 0:
        flash(f"You already have all {available} available unit(s) of {medicine.name} in your cart.", "warning")
        return redirect(request.referrer or url_for("user.medicines"))

    add_qty = min(quantity, room_left)
    if item:
        item.quantity += add_qty
    else:
        item = CartItem(user_id=current_user.id, medicine_id=medicine_id, quantity=add_qty)
        db.session.add(item)
    db.session.commit()

    if medicine.requires_prescription:
        flash(
            f"{medicine.name} needs an approved prescription before checkout. "
            "Upload one under AI Prescriptions if you haven't already.",
            "warning",
        )
    if preferred_store:
        flash(f"{medicine.name} added for {preferred_store.name}.", "success")
    elif add_qty < quantity:
        flash(f"Only {add_qty} unit(s) of {medicine.name} could be added (limited stock available).", "warning")
    else:
        flash(f"{medicine.name} added to cart.", "success")
    return redirect(url_for("user.cart"))


@bp.route("/cart/update/<int:item_id>", methods=["POST"])
def update_cart(item_id):
    item = CartItem.query.get_or_404(item_id)
    if item.user_id != current_user.id:
        abort(403)
    action = request.form.get("action")
    if action == "increase":
        if item.medicine.is_expired:
            flash(f"{item.medicine.name} has expired and cannot be increased.", "danger")
        else:
            available = _sellable_units(item.medicine)
            if item.quantity < available:
                item.quantity += 1
            else:
                flash(f"Only {available} unit(s) of {item.medicine.name} are in stock.", "warning")
    elif action == "decrease":
        item.quantity = max(1, item.quantity - 1)
    elif action == "remove":
        db.session.delete(item)
        db.session.commit()
        flash("Item removed from cart.", "info")
        return redirect(url_for("user.cart"))
    db.session.commit()
    return redirect(url_for("user.cart"))


def _sellable_units(medicine):
    """Units a customer may put in the cart: warehouse delivery pool OR
    the best active-branch shelf qty (whichever is higher). Checkout then
    enforces the correct ledger for the chosen fulfillment type."""
    branch_max = max(
        (s.stock for s in medicine.store_stocks if s.store and s.store.is_active),
        default=0,
    )
    return max(medicine.stock or 0, branch_max)


def _cart_issues(items, fulfillment_type="cart"):
    """Fresh, server-side checks run at cart/checkout time — never trust
    what was true when the item was added, since stock/expiry/approval can
    change in the meantime. Returns a list of human-readable blocking
    messages; an empty list means the cart is clear to check out.

    Stock ledger:
      - delivery / pickup → deferred to _store_stock_issues for the chosen shop
      - cart → warehouse or any branch (sellable units)
    """
    issues = []
    for c in items:
        m = c.medicine
        if m.is_expired:
            issues.append(f"\u201c{m.name}\u201d has expired and must be removed from your cart before checkout.")
        elif fulfillment_type in ("pickup", "delivery"):
            continue
        else:
            available = _sellable_units(m)
            if c.quantity > available:
                issues.append(
                    f"Only {available} unit(s) of \u201c{m.name}\u201d are in stock, "
                    f"but {c.quantity} are in your cart."
                )

    rx_items = [
        c for c in items
        if c.medicine.requires_prescription and not c.medicine.is_expired
    ]
    if rx_items:
        approved = Prescription.query.filter_by(
            user_id=current_user.id, status="approved"
        ).all()
        if not approved:
            issues.append(
                "A pharmacist-approved prescription is required before ordering: "
                + ", ".join(c.medicine.name for c in rx_items)
                + ". Please upload a prescription and wait for approval."
            )
        else:
            matched_ids = set()
            blank_approval = False
            for p in approved:
                p_matches = list(p.matches or [])
                ids = {m.medicine_id for m in p_matches if m.medicine_id}
                if not ids:
                    blank_approval = True
                matched_ids.update(ids)
            if not blank_approval:
                missing = [
                    c.medicine.name for c in rx_items
                    if c.medicine_id not in matched_ids
                ]
                if missing:
                    issues.append(
                        "Your approved prescription does not cover: "
                        + ", ".join(missing)
                        + ". Upload a matching prescription or remove those items."
                    )
    return issues


def _compute_cart_totals(items, coupon_code=None, redeem_points=0, fulfillment_type="delivery"):
    """Shared subtotal/discount/total math for cart, checkout (GET preview)
    and checkout (POST commit) so all three always agree.

    Delivery charge: store pickup is always free; home delivery carries a
    flat DELIVERY_CHARGE (default ₹40) unless the cart subtotal reaches
    FREE_DELIVERY_THRESHOLD (default ₹500), in which case delivery is free.
    """
    subtotal = sum(c.medicine.price * c.quantity for c in items)

    coupon = None
    coupon_discount = 0.0
    coupon_error = None
    if coupon_code:
        coupon = Coupon.query.filter(Coupon.code.ilike(coupon_code.strip())).first()
        if not coupon:
            coupon_error = "Invalid coupon code."
        else:
            valid, msg = coupon.is_valid_for(subtotal)
            if not valid:
                coupon_error = msg
                coupon = None
            else:
                coupon_discount = coupon.compute_discount(subtotal)

    after_coupon = max(0.0, subtotal - coupon_discount)

    max_redeemable_points = min(
        current_user.loyalty_points,
        int(after_coupon * current_user.POINTS_PER_CURRENCY),
    )
    redeem_points = max(0, min(redeem_points, max_redeemable_points))
    points_discount = round(redeem_points / current_user.POINTS_PER_CURRENCY, 2)

    free_delivery_threshold = current_app.config.get("FREE_DELIVERY_THRESHOLD", 500.0)
    delivery_charge = 0.0
    if fulfillment_type != "pickup" and subtotal < free_delivery_threshold:
        delivery_charge = current_app.config.get("DELIVERY_CHARGE", 40.0)
    amount_to_free_delivery = round(max(0.0, free_delivery_threshold - subtotal), 2)

    total = round(max(0.0, after_coupon - points_discount) + delivery_charge, 2)
    return {
        "subtotal": round(subtotal, 2),
        "coupon": coupon,
        "coupon_discount": round(coupon_discount, 2),
        "coupon_error": coupon_error,
        "redeem_points": redeem_points,
        "max_redeemable_points": max_redeemable_points,
        "points_discount": points_discount,
        "delivery_charge": delivery_charge,
        "free_delivery_threshold": free_delivery_threshold,
        "amount_to_free_delivery": amount_to_free_delivery,
        "fulfillment_type": fulfillment_type,
        "total": total,
    }


@bp.route("/cart/apply-coupon", methods=["POST"])
def apply_coupon():
    code = request.form.get("coupon_code", "").strip()
    items = current_user.cart_items
    if not items:
        flash("Your cart is empty.", "info")
        return redirect(url_for("user.cart"))
    subtotal = sum(c.medicine.price * c.quantity for c in items)
    coupon = Coupon.query.filter(Coupon.code.ilike(code)).first()
    if not coupon:
        flash("Invalid coupon code.", "danger")
    else:
        valid, msg = coupon.is_valid_for(subtotal)
        if not valid:
            flash(msg, "danger")
        else:
            session["coupon_code"] = coupon.code
            flash(f"Coupon '{coupon.code}' applied!", "success")
    return redirect(request.referrer or url_for("user.cart"))


@bp.route("/cart/remove-coupon", methods=["POST"])
def remove_coupon():
    session.pop("coupon_code", None)
    flash("Coupon removed.", "info")
    return redirect(request.referrer or url_for("user.cart"))


@bp.route("/cart")
def cart():
    items = current_user.cart_items
    totals = _compute_cart_totals(items, coupon_code=session.get("coupon_code"))
    cart_issues = _cart_issues(items) if items else []
    return render_template("user/cart.html", items=items, totals=totals, cart_issues=cart_issues)


def _store_coverage(items, stores, customer_lat=None, customer_lng=None):
    """For each active store, work out stock coverage + distance from the
    customer so checkout can recommend the nearest takeaway branch."""
    from app.geo import haversine_km, store_coords, format_distance

    coverage = []
    for store in stores:
        lines = []
        all_covered = True
        any_tracked = False
        for c in items:
            row = store.stock_row_for(c.medicine_id)
            have = row.stock if row else 0
            if row:
                any_tracked = True
            covered = have >= c.quantity
            all_covered = all_covered and covered
            lines.append({
                "medicine": c.medicine,
                "have": have,
                "needed": c.quantity,
                "rack": row.rack_location if row else None,
                "covered": covered,
            })

        distance_km = None
        coords = store_coords(store)
        if customer_lat is not None and customer_lng is not None and coords:
            distance_km = haversine_km(customer_lat, customer_lng, coords[0], coords[1])

        coverage.append({
            "store": store,
            "lines": lines,
            "all_covered": all_covered and any_tracked,
            "tracked": any_tracked,
            "distance_km": distance_km,
            "distance_label": format_distance(distance_km),
        })

    # Sort: in-stock first, then nearest, then name. Closest shop rises to top.
    def _sort_key(row):
        dist = row["distance_km"] if row["distance_km"] is not None else 99999
        stock_rank = 0 if row["all_covered"] else (1 if row["tracked"] else 2)
        return (stock_rank, dist, row["store"].name)

    coverage.sort(key=_sort_key)
    return coverage


def _apply_district_groups(coverage, district):
    """Keep shops in the chosen district first, then nearby shops elsewhere.

    If the district has no branch, the notice says so and the list is the
    nearest shops in other districts.
    """
    from app.geo import districts_match
    key = (district or "").strip().lower()
    local = 0
    for row in coverage:
        same = districts_match(key, row["store"].district)
        row["same_district"] = same
        if same:
            local += 1
    if not key:
        return None, 0

    def _sort_key(row):
        dist = row["distance_km"] if row["distance_km"] is not None else 99999
        stock_rank = 0 if row["all_covered"] else (1 if row["tracked"] else 2)
        return (0 if row["same_district"] else 1, stock_rank, dist, row["store"].name)

    coverage.sort(key=_sort_key)
    if local == 0:
        notice = f"No shop at {district}. Nearby available shops are listed below."
    else:
        notice = (
            f"{local} shop(s) in {district}. "
            "Nearby shops in other places are also listed."
        )
    return notice, local


def _store_stock_issues(items, store):
    """Hard gate: every cart line must exist on that shop's shelf with
    enough units (used for both Store Pickup and Home Delivery dispatch)."""
    issues = []
    if not store:
        return ["Please select a shop."]
    for c in items:
        row = store.stock_row_for(c.medicine_id)
        have = row.stock if row else 0
        if not row or have < c.quantity:
            name = c.medicine.name if c.medicine else "Item"
            issues.append(
                f"{store.name} only has {have} of {name} (you need {c.quantity}). "
                "Choose another shop or reduce quantity."
            )
    return issues


# Backwards-compatible alias
_pickup_stock_issues = _store_stock_issues


@bp.route("/checkout", methods=["GET", "POST"])
def checkout():
    items = current_user.cart_items
    if not items:
        flash("Your cart is empty.", "info")
        return redirect(url_for("user.medicines"))

    # Re-validate expiry / Rx on GET; stock ledger is re-checked on POST
    # against the chosen fulfillment type.
    issues = _cart_issues(items, fulfillment_type="cart")
    if issues:
        for issue in issues:
            flash(issue, "danger")
        return redirect(url_for("user.cart"))

    coupon_code = session.get("coupon_code")
    stores = Store.query.filter_by(is_active=True).order_by(Store.name).all()

    def _customer_point_from_request():
        from app.geo import resolve_customer_point
        lat = request.values.get("lat") or request.values.get("customer_lat")
        lng = request.values.get("lng") or request.values.get("customer_lng")
        # A submitted city (even blank) is explicit. Do not fall back to a
        # previously saved district, and do not let leftover GPS coords win.
        if "nearby_district" in request.values:
            district = (request.values.get("nearby_district") or "").strip() or None
        else:
            district = (getattr(current_user, "preferred_district", None) or "").strip() or None
        address = request.values.get("address") or current_user.address
        if district:
            clat, clng, source = resolve_customer_point(None, None, district, None)
        else:
            clat, clng, source = resolve_customer_point(lat, lng, None, address)
        return clat, clng, source, district, sorted([
            "Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam",
            "Alappuzha", "Kottayam", "Palakkad", "Malappuram", "Kannur",
            "Pathanamthitta", "Idukki", "Wayanad", "Kasaragod", "Ernakulam",
        ])

    if request.method == "POST":
        redeem_points = int(request.form.get("redeem_points", 0) or 0)
        fulfillment_type = request.form.get("fulfillment_type", "delivery")
        fulfillment_type = "pickup" if fulfillment_type == "pickup" else "delivery"
        post_issues = _cart_issues(items, fulfillment_type=fulfillment_type)
        if post_issues:
            for issue in post_issues:
                flash(issue, "danger")
            return redirect(url_for("user.cart" if fulfillment_type == "delivery" else "user.checkout"))
        totals = _compute_cart_totals(
            items, coupon_code=coupon_code, redeem_points=redeem_points,
            fulfillment_type=fulfillment_type,
        )

        # Remember the city they actually picked. GPS-only checkout clears a
        # stale city so the next visit does not keep saying "No shop at Idukki".
        nearby_district = (request.form.get("nearby_district") or "").strip()
        if hasattr(current_user, "preferred_district"):
            current_user.preferred_district = nearby_district or None

        payment_method = request.form.get("payment_method", "COD")
        card_last4 = None
        if payment_method == "Card":
            card_name = (request.form.get("card_name") or "").strip()
            digits = "".join(ch for ch in request.form.get("card_number", "") if ch.isdigit())
            expiry = (request.form.get("card_expiry") or "").strip()
            cvv = "".join(ch for ch in request.form.get("card_cvv", "") if ch.isdigit())
            if len(card_name) < 2:
                flash("Please enter the name on the card.", "danger")
                return redirect(url_for("user.checkout"))
            if len(digits) < 13 or len(digits) > 19:
                flash("Please enter a valid card number (13–19 digits).", "danger")
                return redirect(url_for("user.checkout"))
            if not re.match(r"^(0[1-9]|1[0-2])\/\d{2}$", expiry):
                flash("Please enter a valid expiry date (MM/YY).", "danger")
                return redirect(url_for("user.checkout"))
            if len(cvv) < 3 or len(cvv) > 4:
                flash("Please enter a valid CVV.", "danger")
                return redirect(url_for("user.checkout"))
            # Authorise payment and retain only last 4 digits for the receipt.
            card_last4 = digits[-4:]
            payment_method = "Card"

        store = None
        pickup_code = None
        pickup_location = None
        shipping_address = None

        # Both pickup and home delivery need a branch that can cover the cart.
        store_id = request.form.get("store_id", type=int)
        store = next((s for s in stores if s.id == store_id), None)
        if not store:
            # Auto-assign nearest in-stock shop from coverage ranking.
            clat, clng, _, _, _ = _customer_point_from_request()
            coverage = _store_coverage(items, stores, customer_lat=clat, customer_lng=clng)
            store = next((row["store"] for row in coverage if row["all_covered"]), None)
        if not store:
            flash(
                "No shop can fulfill your cart right now. Reduce quantities or try again later.",
                "danger",
            )
            return redirect(url_for("user.checkout"))
        stock_issues = _store_stock_issues(items, store)
        if stock_issues:
            for issue in stock_issues:
                flash(issue, "danger")
            return redirect(url_for("user.checkout"))

        if fulfillment_type == "pickup":
            pickup_location = store.display_name
            pickup_code = generate_pickup_code()
        else:
            shipping_address = request.form.get("address", current_user.address or "").strip()
            if not shipping_address:
                flash("Please enter a shipping address, or choose store pickup instead.", "danger")
                return redirect(url_for("user.checkout"))
            # Location helps rank the nearest dispatch shop — require GPS,
            # district, or a resolvable address point.
            clat, clng, loc_source, district, _ = _customer_point_from_request()
            has_location = bool(
                (clat is not None and clng is not None)
                or district
                or loc_source in ("gps", "district", "address")
            )
            if not has_location:
                flash(
                    "Share your location or pick your city so we can dispatch from the nearest shop.",
                    "danger",
                )
                return redirect(url_for("user.checkout"))
            # Save address on profile for future deliveries.
            if shipping_address and shipping_address != (current_user.address or ""):
                current_user.address = shipping_address

        order = Order(
            user_id=current_user.id,
            subtotal=totals["subtotal"],
            delivery_charge=totals["delivery_charge"],
            total=totals["total"],
            status="pending",
            fulfillment_type=fulfillment_type,
            pickup_location=pickup_location,
            store_id=store.id,
            pickup_code=pickup_code,
            shipping_address=shipping_address,
            payment_method=payment_method,
            card_last4=card_last4,
            coupon_code=totals["coupon"].code if totals["coupon"] else None,
            coupon_discount=totals["coupon_discount"],
            points_redeemed=totals["redeem_points"],
            points_discount=totals["points_discount"],
            # Points are earned on the product spend only (not the delivery
            # fee) — 1 point per ₹1, matching the assistant bot's advertised
            # rate and User.POINTS_PER_CURRENCY.
            points_earned=int(max(0.0, totals["total"] - totals["delivery_charge"])),
        )
        db.session.add(order)
        db.session.flush()
        for c in items:
            oi = OrderItem(
                order_id=order.id,
                medicine_id=c.medicine_id,
                quantity=c.quantity,
                price=c.medicine.price,
            )
            db.session.add(oi)
            # Dispatch / pickup always draws from the assigned branch shelf.
            # Conditional update so two checkouts cannot both take the last units.
            taken = StoreStock.query.filter(
                StoreStock.store_id == store.id,
                StoreStock.medicine_id == c.medicine_id,
                StoreStock.stock >= c.quantity,
            ).update(
                {StoreStock.stock: StoreStock.stock - c.quantity},
                synchronize_session="fetch",
            )
            if not taken:
                flash(f"Not enough shelf stock at {store.name} for {c.medicine.name}.", "danger")
                db.session.rollback()
                return redirect(url_for("user.checkout"))
        for c in items:
            db.session.delete(c)

        if totals["coupon"]:
            totals["coupon"].used_count += 1
        current_user.loyalty_points -= totals["redeem_points"]
        current_user.loyalty_points += order.points_earned

        db.session.commit()
        session.pop("coupon_code", None)

        notif_msg = "Your order has been received and is pending confirmation."
        if fulfillment_type == "pickup" and pickup_code:
            notif_msg += f" Show pickup code {pickup_code} at {store.name} to collect it."
        elif fulfillment_type == "delivery":
            notif_msg += f" Dispatching from {store.name}."
        if order.points_earned:
            notif_msg += f" You earned {order.points_earned} loyalty points!"
        notif = Notification(
            user_id=current_user.id,
            title=f"Order #{order.id} placed",
            message=notif_msg,
        )
        db.session.add(notif)

        notify_store_staff(
            store.id,
            (
                f"New pickup order #{order.id}"
                if fulfillment_type == "pickup"
                else f"New delivery to pack #{order.id}"
            ),
            (
                f"{current_user.name} ordered for pickup at {store.name}. "
                f"Total {order.total:.2f}. Confirm and verify their code when they arrive."
                if fulfillment_type == "pickup"
                else (
                    f"{current_user.name} ordered home delivery packed from {store.name}. "
                    f"Ship to: {shipping_address}. Total {order.total:.2f}."
                )
            ),
        )

        db.session.commit()
        flash(f"Order #{order.id} placed successfully!", "success")
        return redirect(url_for("user.order_details", order_id=order.id))

    totals = _compute_cart_totals(items, coupon_code=coupon_code)
    clat, clng, loc_source, district, district_choices = _customer_point_from_request()
    coverage = _store_coverage(items, stores, customer_lat=clat, customer_lng=clng)
    active_district = district or (current_user.preferred_district or "")
    location_notice, _local_count = _apply_district_groups(coverage, active_district)
    preferred_store_id = session.get("preferred_store_id")
    # Prefer the shop the customer browsed when no district grouping is active.
    if preferred_store_id and not active_district:
        pref_cov = next(
            (c for c in coverage if c["store"].id == preferred_store_id and c["all_covered"]),
            None,
        )
        if pref_cov:
            coverage = [pref_cov] + [c for c in coverage if c["store"].id != preferred_store_id]
    return render_template(
        "user/checkout.html",
        items=items,
        totals=totals,
        stores=stores,
        coverage=coverage,
        loc_source=loc_source,
        nearby_district=active_district,
        district_choices=district_choices,
        customer_lat=clat if loc_source == "gps" else None,
        customer_lng=clng if loc_source == "gps" else None,
        preferred_store_id=preferred_store_id,
        location_notice=location_notice,
    )


@bp.route("/nearby-stores")
def nearby_stores():
    """JSON: re-rank pickup shops by GPS / district without refreshing checkout."""
    from app.geo import resolve_customer_point

    items = current_user.cart_items
    stores = Store.query.filter_by(is_active=True).order_by(Store.name).all()
    lat = request.args.get("lat")
    lng = request.args.get("lng")
    district = (request.args.get("nearby_district") or "").strip() or None
    address = current_user.address
    if district:
        clat, clng, source = resolve_customer_point(None, None, district, None)
    else:
        clat, clng, source = resolve_customer_point(lat, lng, None, address)
    coverage = _store_coverage(items, stores, customer_lat=clat, customer_lng=clng)
    notice, local_count = _apply_district_groups(coverage, district)

    if notice:
        status = notice
    elif source == "gps":
        status = "Using your GPS — shops sorted nearest first"
    elif source == "address":
        status = "Sorted using your saved address"
    else:
        status = "Share location or pick a city so we recommend the closest shop"

    payload = []
    for cov in coverage:
        payload.append({
            "id": cov["store"].id,
            "name": cov["store"].name,
            "address": cov["store"].address,
            "district": cov["store"].district or "",
            "same_district": bool(cov.get("same_district")),
            "tracked": cov["tracked"],
            "all_covered": cov["all_covered"],
            "distance_km": cov["distance_km"],
            "distance_label": cov["distance_label"] or "",
            "lines": [
                {
                    "name": line["medicine"].name,
                    "have": line["have"],
                    "needed": line["needed"],
                    "rack": line["rack"] or "",
                    "covered": line["covered"],
                }
                for line in cov["lines"]
            ],
        })

    return jsonify({
        "ok": True,
        "source": source,
        "status": status,
        "notice": notice or "",
        "local_count": local_count,
        "district": district or "",
        "lat": clat,
        "lng": clng,
        "stores": payload,
    })


@bp.route("/upload-prescription", methods=["GET", "POST"])
def upload_prescription():
    if request.method == "POST":
        file = request.files.get("prescription")
        note = request.form.get("note", "")
        if not file or file.filename == "":
            flash("Please select a file to upload.", "danger")
            return redirect(url_for("user.upload_prescription"))
        path = save_upload(file, "prescriptions")
        if not path:
            flash("Invalid file type.", "danger")
            return redirect(url_for("user.upload_prescription"))
        pres = Prescription(
            user_id=current_user.id,
            file_path=path,
            note=note,
            status="pending",
        )
        db.session.add(pres)
        db.session.commit()

        _run_ai_analysis(pres)

        if pres.ai_status == "processed":
            label_msg = {
                "likely_genuine": "Our AI verification found this looks like a genuine prescription.",
                "needs_review": "Our AI verification flagged this for closer pharmacist review.",
                "low_confidence": "Our AI verification could not confirm authenticity — a pharmacist will check manually.",
            }.get(pres.authenticity_label, "")
            match_msg = f" Found {len(pres.matches)} possible medicine match(es)." if pres.matches else ""
            flash(f"Prescription uploaded! {label_msg}{match_msg}", "success")
        else:
            flash("Prescription uploaded. It will be reviewed shortly.", "success")
        return redirect(url_for("user.prescription_details", prescription_id=pres.id))

    prescriptions = (
        Prescription.query.filter_by(user_id=current_user.id)
        .order_by(Prescription.created_at.desc())
        .all()
    )
    return render_template(
        "user/upload_prescription.html",
        prescriptions=prescriptions,
        status_badge=status_badge,
    )


def _run_ai_analysis(prescription):
    """Run the OCR/matching pipeline for a prescription and persist results.
    Safe no-op-on-failure: prescription always ends up with a usable status."""
    abs_path = os.path.join(current_app.static_folder, prescription.file_path)
    medicines = Medicine.query.all()
    result = analyze_prescription_file(
        abs_path,
        medicines,
        current_app.config.get("TESSERACT_READY", False),
        current_app.config.get("HTR_READY", False),
        current_app.config.get("GEMINI_READY", False),
    )
    # Clear any matches from a previous analysis pass (e.g. re-analyze)
    # before inserting fresh ones, so they don't just pile up.
    for old_match in list(prescription.matches):
        db.session.delete(old_match)
    prescription.ai_status = result["status"]
    prescription.ocr_text = result["ocr_text"]
    prescription.ai_summary = result["summary"]
    prescription.ai_confidence = result["confidence"]
    prescription.authenticity_score = result.get("authenticity_score")
    prescription.authenticity_label = result.get("authenticity_label")
    prescription.authenticity_reasons = "|".join(result.get("authenticity_reasons") or [])
    for m in result["matches"]:
        db.session.add(PrescriptionMatch(
            prescription_id=prescription.id,
            medicine_id=m["medicine"].id,
            matched_text=m["matched_text"],
            dosage_hint=m["dosage_hint"],
            confidence=m["confidence"],
        ))
    db.session.commit()


@bp.route("/prescriptions/<int:prescription_id>")
def prescription_details(prescription_id):
    pres = Prescription.query.get_or_404(prescription_id)
    if pres.user_id != current_user.id:
        abort(403)
    return render_template(
        "user/prescription_details.html", prescription=pres, status_badge=status_badge
    )


@bp.route("/prescriptions/<int:prescription_id>/reanalyze", methods=["POST"])
def reanalyze_prescription(prescription_id):
    """Re-run the AI OCR/matching pipeline on an already-uploaded file —
    handy after the AI configuration changes (e.g. a new engine becoming
    available) without needing to re-upload the image."""
    pres = Prescription.query.get_or_404(prescription_id)
    if pres.user_id != current_user.id:
        abort(403)
    _run_ai_analysis(pres)
    flash("AI analysis re-run with the latest engine.", "success")
    return redirect(url_for("user.prescription_details", prescription_id=pres.id))


@bp.route("/prescriptions/<int:prescription_id>/add-matches-to-cart", methods=["POST"])
def add_matches_to_cart(prescription_id):
    pres = Prescription.query.get_or_404(prescription_id)
    if pres.user_id != current_user.id:
        abort(403)
    added = 0
    skipped_stock = 0
    for match in pres.matches:
        if not match.medicine_id or match.confidence < 0.7:
            continue
        medicine = match.medicine
        if not medicine or medicine.is_expired or medicine.stock <= 0:
            skipped_stock += 1
            continue
        item = CartItem.query.filter_by(user_id=current_user.id, medicine_id=match.medicine_id).first()
        already_in_cart = item.quantity if item else 0
        if already_in_cart >= medicine.stock:
            skipped_stock += 1
            continue
        if item:
            item.quantity += 1
        else:
            db.session.add(CartItem(user_id=current_user.id, medicine_id=match.medicine_id, quantity=1))
        added += 1
    db.session.commit()
    if added:
        msg = f"Added {added} matched medicine(s) to your cart."
        if skipped_stock:
            msg += f" ({skipped_stock} skipped — out of stock.)"
        flash(msg, "success")
    else:
        flash("No high-confidence, in-stock matches were available to add.", "info")
    return redirect(url_for("user.cart"))


@bp.route("/orders")
def my_orders():
    page = request.args.get("page", 1, type=int)
    query = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc())
    pagination = paginate(query, page, 10)
    return render_template(
        "user/my_orders.html", orders=pagination.items, pagination=pagination, status_badge=status_badge
    )


@bp.route("/orders/<int:order_id>")
def order_details(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        abort(403)
    return render_template("user/order_details.html", order=order, status_badge=status_badge)


@bp.route("/orders/<int:order_id>/cancel", methods=["POST"])
def cancel_order(order_id):
    """Customers can self-cancel while an order is still 'pending' (i.e.
    the pharmacist hasn't started processing it yet). Once confirmed/shipped
    they must contact support instead — matches the assistant bot's advice."""
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        abort(403)
    if order.status != "pending":
        flash("This order is already being processed and can no longer be self-cancelled. Please contact support.", "danger")
        return redirect(url_for("user.order_details", order_id=order.id))

    reverse_order_effects(order)
    order.status = "cancelled"
    db.session.commit()
    notif = Notification(
        user_id=current_user.id,
        title=f"Order #{order.id} cancelled",
        message="You cancelled this order. Any stock, coupon use, and loyalty points were reversed.",
    )
    db.session.add(notif)
    if order.fulfillment_type == "pickup" and order.store_id:
        notify_store_staff(
            order.store_id,
            f"Pickup order #{order.id} cancelled",
            f"{current_user.name} cancelled order #{order.id}. Do not prepare this order.",
        )
    db.session.commit()
    flash(f"Order #{order.id} has been cancelled.", "info")
    return redirect(url_for("user.my_orders"))


@bp.route("/notifications")
def notifications():
    notes = (
        Notification.query.filter_by(user_id=current_user.id)
        .order_by(Notification.created_at.desc())
        .all()
    )
    for n in notes:
        n.is_read = True
    db.session.commit()
    return render_template("user/notifications.html", notifications=notes)


@bp.route("/profile", methods=["GET", "POST"])
def profile():
    if request.method == "POST":
        current_user.name = request.form.get("name", current_user.name)
        current_user.phone = request.form.get("phone", current_user.phone)
        current_user.address = request.form.get("address", current_user.address)
        if hasattr(current_user, "preferred_district"):
            current_user.preferred_district = (
                request.form.get("preferred_district", "").strip() or None
            )
        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("user.profile"))
    orders_count = Order.query.filter_by(user_id=current_user.id).count()
    return render_template("user/profile.html", orders_count=orders_count)
