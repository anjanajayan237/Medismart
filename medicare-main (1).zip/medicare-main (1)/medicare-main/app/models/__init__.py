from app.extensions import db
from flask_login import UserMixin
from datetime import datetime


class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(30), nullable=True)
    address = db.Column(db.Text, nullable=True)
    # Preferred city/district for nearby store pickup ranking when GPS is off.
    preferred_district = db.Column(db.String(80), nullable=True)
    role = db.Column(db.String(20), default="user", nullable=False)  # user | admin | store
    # Set when role == "store" — staff only see this branch's orders / stock.
    store_id = db.Column(db.Integer, db.ForeignKey("stores.id"), nullable=True)
    is_active_user = db.Column(db.Boolean, default=True, nullable=False)
    avatar = db.Column(db.String(255), nullable=True)
    loyalty_points = db.Column(db.Integer, default=0, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    orders = db.relationship("Order", backref="user", lazy=True)
    prescriptions = db.relationship("Prescription", backref="user", lazy=True)
    cart_items = db.relationship("CartItem", backref="user", lazy=True)
    notifications = db.relationship("Notification", backref="user", lazy=True)
    reviews = db.relationship("Review", backref="user", lazy=True)
    store = db.relationship("Store", foreign_keys=[store_id])

    # 100 loyalty points = ₹1 of redemption value
    POINTS_PER_CURRENCY = 100

    @property
    def loyalty_value(self):
        return round(self.loyalty_points / self.POINTS_PER_CURRENCY, 2)

    def set_password(self, raw):
        from app.extensions import bcrypt
        self.password_hash = bcrypt.generate_password_hash(raw).decode("utf-8")

    def check_password(self, raw):
        from app.extensions import bcrypt
        return bcrypt.check_password_hash(self.password_hash, raw)

    @property
    def is_admin(self):
        return self.role == "admin"

    @property
    def is_store_staff(self):
        # role alone is enough — missing store_id is a repair case, not a customer.
        return self.role == "store"

    def get_id(self):
        return str(self.id)

    @property
    def is_active(self):
        return self.is_active_user


class Category(db.Model):
    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    medicines = db.relationship("Medicine", backref="category", lazy=True)


class Store(db.Model):
    """A physical pharmacy branch. Backs the "Store Pickup" fulfillment
    option — used for per-branch stock/rack lookups and pickup-code
    verification. Replaces the old hardcoded PICKUP_LOCATIONS list so admins
    can add/edit/retire branches without touching code."""
    __tablename__ = "stores"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    address = db.Column(db.String(255), nullable=False)
    district = db.Column(db.String(80), nullable=True)
    phone = db.Column(db.String(30), nullable=True)
    # WGS84 coordinates for nearby / takeaway ranking (optional).
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    stocks = db.relationship(
        "StoreStock", backref="store", lazy=True, cascade="all, delete-orphan"
    )

    @property
    def display_name(self):
        return f"{self.name} — {self.address}"

    def stock_row_for(self, medicine_id):
        return next((s for s in self.stocks if s.medicine_id == medicine_id), None)


class StoreStock(db.Model):
    """Per-branch shelf stock + rack location.

    Inventory policy:
      - Home Delivery and Store Pickup both draw from the assigned branch's
        StoreStock (dispatch / takeaway shop).
      - Medicine.stock remains a warehouse reference / legacy delivery pool.
    """
    __tablename__ = "store_stocks"
    __table_args__ = (db.UniqueConstraint("store_id", "medicine_id", name="uq_store_medicine"),)

    id = db.Column(db.Integer, primary_key=True)
    store_id = db.Column(db.Integer, db.ForeignKey("stores.id"), nullable=False)
    medicine_id = db.Column(db.Integer, db.ForeignKey("medicines.id"), nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=0)
    # Free-text shelf address, e.g. "Aisle 3 / Rack B / Shelf 2".
    rack_location = db.Column(db.String(60), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    medicine = db.relationship(
        "Medicine", backref=db.backref("store_stocks", cascade="all, delete-orphan")
    )


class Medicine(db.Model):
    __tablename__ = "medicines"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False, index=True)
    brand = db.Column(db.String(120), nullable=True)
    description = db.Column(db.Text, nullable=True)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=True)
    price = db.Column(db.Float, nullable=False, default=0.0)
    stock = db.Column(db.Integer, nullable=False, default=0)
    unit = db.Column(db.String(30), default="pack")
    image = db.Column(db.String(255), nullable=True)
    requires_prescription = db.Column(db.Boolean, default=False)
    expiry_date = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    cart_items = db.relationship("CartItem", backref="medicine", lazy=True)
    order_items = db.relationship("OrderItem", backref="medicine", lazy=True)
    reviews = db.relationship("Review", backref="medicine", lazy=True, cascade="all, delete-orphan")
    prescription_matches = db.relationship("PrescriptionMatch", backref="medicine", lazy=True)

    @property
    def is_low_stock(self):
        return self.stock <= 10

    @property
    def is_expiring_soon(self):
        if not self.expiry_date:
            return False
        from datetime import datetime, timedelta
        delta = self.expiry_date - datetime.utcnow().date()
        return timedelta(days=0) <= delta <= timedelta(days=30)

    @property
    def is_expired(self):
        if not self.expiry_date:
            return False
        return self.expiry_date < datetime.utcnow().date()

    @property
    def avg_rating(self):
        if not self.reviews:
            return 0.0
        return round(sum(r.rating for r in self.reviews) / len(self.reviews), 1)

    @property
    def review_count(self):
        return len(self.reviews)


class CartItem(db.Model):
    __tablename__ = "cart_items"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    medicine_id = db.Column(db.Integer, db.ForeignKey("medicines.id"), nullable=False)
    quantity = db.Column(db.Integer, default=1, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Order(db.Model):
    __tablename__ = "orders"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    subtotal = db.Column(db.Float, nullable=False, default=0.0)
    delivery_charge = db.Column(db.Float, nullable=False, default=0.0)
    total = db.Column(db.Float, nullable=False, default=0.0)
    status = db.Column(db.String(30), default="pending", nullable=False)
    # pending | confirmed | shipped | delivered | cancelled
    shipping_address = db.Column(db.Text, nullable=True)
    payment_method = db.Column(db.String(40), default="COD")
    # Only the last 4 digits are retained for receipts; full PAN/CVV are never stored.
    card_last4 = db.Column(db.String(4), nullable=True)
    fulfillment_type = db.Column(db.String(20), default="delivery", nullable=False)
    # delivery | pickup
    pickup_location = db.Column(db.String(255), nullable=True)
    store_id = db.Column(db.Integer, db.ForeignKey("stores.id"), nullable=True)
    # 6-digit code the customer must show in-store to collect a pickup
    # order — the pharmacist verifies it before releasing the medicines.
    pickup_code = db.Column(db.String(10), nullable=True)
    picked_up_at = db.Column(db.DateTime, nullable=True)
    coupon_code = db.Column(db.String(40), nullable=True)
    coupon_discount = db.Column(db.Float, nullable=False, default=0.0)
    points_redeemed = db.Column(db.Integer, nullable=False, default=0)
    points_discount = db.Column(db.Float, nullable=False, default=0.0)
    points_earned = db.Column(db.Integer, nullable=False, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    items = db.relationship("OrderItem", backref="order", lazy=True, cascade="all, delete-orphan")
    store = db.relationship("Store", foreign_keys=[store_id])


class OrderItem(db.Model):
    __tablename__ = "order_items"

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey("orders.id"), nullable=False)
    medicine_id = db.Column(db.Integer, db.ForeignKey("medicines.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)


class Prescription(db.Model):
    __tablename__ = "prescriptions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    note = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(30), default="pending", nullable=False)
    # pending | approved | rejected | needs_info
    # Pharmacist's own note explaining a rejection or an info/re-upload
    # request (e.g. "line 2 illegible, please re-upload a clearer photo").
    # Shown back to the patient — this is how a real pharmacy handles an
    # unclear prescription; see review_prescription() in app/admin/routes.py.
    admin_note = db.Column(db.Text, nullable=True)

    # ---- AI / OCR analysis ----
    ocr_text = db.Column(db.Text, nullable=True)
    ai_status = db.Column(db.String(20), default="pending", nullable=False)
    # pending | processed | unavailable | failed
    ai_summary = db.Column(db.Text, nullable=True)
    ai_confidence = db.Column(db.Float, nullable=True)

    # ---- AI genuineness / authenticity verification ----
    authenticity_score = db.Column(db.Float, nullable=True)  # 0..1
    authenticity_label = db.Column(db.String(30), nullable=True)
    # likely_genuine | needs_review | low_confidence
    authenticity_reasons = db.Column(db.Text, nullable=True)  # "|" separated signal list

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    matches = db.relationship(
        "PrescriptionMatch", backref="prescription", lazy=True,
        cascade="all, delete-orphan", order_by="desc(PrescriptionMatch.confidence)",
    )

    @property
    def authenticity_pct(self):
        if self.authenticity_score is None:
            return None
        return round(self.authenticity_score * 100)

    @property
    def authenticity_reasons_list(self):
        if not self.authenticity_reasons:
            return []
        return self.authenticity_reasons.split("|")


class Notification(db.Model):
    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title = db.Column(db.String(180), nullable=False)
    message = db.Column(db.Text, nullable=True)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PrescriptionMatch(db.Model):
    """A medicine the AI reader detected inside a prescription upload."""
    __tablename__ = "prescription_matches"

    id = db.Column(db.Integer, primary_key=True)
    prescription_id = db.Column(db.Integer, db.ForeignKey("prescriptions.id"), nullable=False)
    medicine_id = db.Column(db.Integer, db.ForeignKey("medicines.id"), nullable=True)
    matched_text = db.Column(db.String(255), nullable=False)
    dosage_hint = db.Column(db.String(120), nullable=True)
    confidence = db.Column(db.Float, nullable=False, default=0.0)  # 0..1
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def confidence_pct(self):
        return round(self.confidence * 100)


class Coupon(db.Model):
    __tablename__ = "coupons"

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(40), unique=True, nullable=False, index=True)
    description = db.Column(db.String(255), nullable=True)
    discount_type = db.Column(db.String(20), default="percent", nullable=False)  # percent | fixed
    discount_value = db.Column(db.Float, nullable=False, default=0.0)
    min_order_amount = db.Column(db.Float, nullable=False, default=0.0)
    max_uses = db.Column(db.Integer, nullable=True)  # None = unlimited
    used_count = db.Column(db.Integer, nullable=False, default=0)
    active = db.Column(db.Boolean, default=True, nullable=False)
    expires_at = db.Column(db.Date, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def is_valid_for(self, subtotal):
        if not self.active:
            return False, "This coupon is no longer active."
        if self.expires_at and self.expires_at < datetime.utcnow().date():
            return False, "This coupon has expired."
        if self.max_uses is not None and self.used_count >= self.max_uses:
            return False, "This coupon has reached its usage limit."
        if subtotal < self.min_order_amount:
            return False, f"Minimum order of ₹{self.min_order_amount:.2f} required for this coupon."
        return True, ""

    def compute_discount(self, subtotal):
        if self.discount_type == "percent":
            return round(subtotal * (self.discount_value / 100.0), 2)
        return round(min(self.discount_value, subtotal), 2)


class Review(db.Model):
    __tablename__ = "reviews"
    __table_args__ = (db.UniqueConstraint("medicine_id", "user_id", name="uq_review_medicine_user"),)

    id = db.Column(db.Integer, primary_key=True)
    medicine_id = db.Column(db.Integer, db.ForeignKey("medicines.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1..5
    comment = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
