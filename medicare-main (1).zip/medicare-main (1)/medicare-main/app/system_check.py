"""System / dependency health checks for MediSmart.

Used by the admin System Check page so a fresh PC can see what is missing
(Python packages, Tesseract binary, Gemini key, optional HTR) and trigger
installs with one click.
"""
from __future__ import annotations

import importlib.util
import os
import platform
import shutil
import subprocess
import sys
from typing import Any


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


# Core pip packages from requirements.txt (name → import module)
CORE_PIP_PACKAGES = [
    ("Flask", "flask"),
    ("Flask-SQLAlchemy", "flask_sqlalchemy"),
    ("Flask-Login", "flask_login"),
    ("Flask-Bcrypt", "flask_bcrypt"),
    ("Werkzeug", "werkzeug"),
    ("python-dotenv", "dotenv"),
    ("Pillow", "PIL"),
    ("pytesseract", "pytesseract"),
    ("google-genai", "google.genai"),
]

OPTIONAL_HTR_PACKAGES = [
    ("torch", "torch"),
    ("transformers", "transformers"),
]


def _pkg_ok(module_name: str) -> bool:
    try:
        return importlib.util.find_spec(module_name) is not None
    except (ModuleNotFoundError, ValueError):
        return False


def _find_tesseract_binary(app=None) -> str | None:
    home = os.path.expanduser("~")
    candidates = []
    if app is not None:
        candidates.append(app.config.get("TESSERACT_CMD"))
    candidates.extend(
        [
            os.environ.get("TESSERACT_CMD"),
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            os.path.join(home, r"AppData\Local\Programs\Tesseract-OCR\tesseract.exe"),
            os.path.join(home, r"AppData\Local\Tesseract-OCR\tesseract.exe"),
            "/usr/bin/tesseract",
            "/usr/local/bin/tesseract",
            "/opt/homebrew/bin/tesseract",
        ]
    )
    for path in candidates:
        if path and os.path.exists(path):
            return path
    return shutil.which("tesseract")


def _tesseract_version(binary: str | None) -> str | None:
    if not binary:
        return None
    try:
        out = subprocess.run(
            [binary, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        line = (out.stdout or out.stderr or "").strip().splitlines()
        return line[0] if line else "installed"
    except (OSError, subprocess.TimeoutExpired):
        return "installed"


def _read_env_key(name: str) -> str:
    """Read a key from process env, .env, or built-in Gemini default."""
    val = os.environ.get(name, "").strip()
    if val:
        return val
    env_path = os.path.join(PROJECT_ROOT, ".env")
    if os.path.isfile(env_path):
        try:
            with open(env_path, encoding="utf-8") as fh:
                for raw in fh:
                    line = raw.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    k, v = line.split("=", 1)
                    if k.strip() == name:
                        found = v.strip().strip('"').strip("'")
                        if found:
                            return found
        except OSError:
            pass
    if name == "GEMINI_API_KEY":
        try:
            from app.config import _resolve_gemini_api_key
            return _resolve_gemini_api_key()
        except Exception:
            return ""
    return ""


def collect_status(app=None) -> dict[str, Any]:
    """Return a structured status dict for the System Check UI."""
    core = []
    for label, mod in CORE_PIP_PACKAGES:
        ok = _pkg_ok(mod)
        core.append({"id": mod, "name": label, "ok": ok, "detail": "Installed" if ok else "Missing"})

    optional = []
    for label, mod in OPTIONAL_HTR_PACKAGES:
        ok = _pkg_ok(mod)
        optional.append(
            {
                "id": mod,
                "name": label,
                "ok": ok,
                "detail": "Installed (offline HTR)" if ok else "Not installed (optional)",
            }
        )

    tess_bin = _find_tesseract_binary(app)
    tess_ok = bool(tess_bin)
    tess_ver = _tesseract_version(tess_bin) if tess_ok else None

    # Prefer live app.config when available (set at startup)
    if app is not None:
        tess_ready = bool(app.config.get("TESSERACT_READY"))
        gemini_ready = bool(app.config.get("GEMINI_READY"))
        htr_ready = bool(app.config.get("HTR_READY"))
        if tess_ready and not tess_ok:
            tess_ok = True
    else:
        tess_ready = tess_ok
        gemini_ready = bool(_read_env_key("GEMINI_API_KEY") and _pkg_ok("google.genai"))
        htr_ready = all(_pkg_ok(m) for _, m in OPTIONAL_HTR_PACKAGES) and _pkg_ok("PIL")

    gemini_key = _read_env_key("GEMINI_API_KEY")
    gemini_set = bool(gemini_key)

    core_all_ok = all(p["ok"] for p in core)
    # App can run with Gemini alone for handwriting; Tesseract is still recommended
    ai_ok = tess_ok or gemini_ready
    overall_ok = core_all_ok and ai_ok

    checks = [
        {
            "id": "python",
            "title": "Python runtime",
            "ok": True,
            "required": True,
            "detail": f"{platform.python_version()} ({sys.executable})",
            "hint": "Install Python 3.10–3.12 from python.org if missing.",
            "action": None,
        },
        {
            "id": "pip_core",
            "title": "Python packages (requirements.txt)",
            "ok": core_all_ok,
            "required": True,
            "detail": f"{sum(1 for p in core if p['ok'])}/{len(core)} packages OK",
            "packages": core,
            "hint": "Click Install to run: pip install -r requirements.txt",
            "action": "pip_core" if not core_all_ok else None,
        },
        {
            "id": "tesseract",
            "title": "Tesseract OCR (system binary)",
            "ok": tess_ok,
            "required": True,
            "detail": (tess_ver or tess_bin or "Not found on this PC"),
            "hint": (
                "Not a pip package — install the Windows program. "
                "Use the Install button (winget) or download from UB-Mannheim."
            ),
            "action": "tesseract" if not tess_ok else None,
            "download_url": "https://github.com/UB-Mannheim/tesseract/wiki",
        },
        {
            "id": "gemini",
            "title": "Google Gemini API key",
            "ok": gemini_set and gemini_ready,
            "required": False,
            "detail": (
                "API key ready (from .env or built-in default)"
                if gemini_ready
                else ("Key set but google-genai package missing" if gemini_set else "Not configured")
            ),
            "hint": "Uses built-in project key when .env is missing. Optional override via System Check or .env.",
            "action": None,
        },
        {
            "id": "htr",
            "title": "Optional offline HTR (Torch / TrOCR)",
            "ok": htr_ready,
            "required": False,
            "detail": "Ready" if htr_ready else "Skipped (large ~1–2 GB download)",
            "packages": optional,
            "hint": "Only needed for fully offline handwriting without Gemini.",
            "action": "htr" if not htr_ready else None,
        },
        {
            "id": "database",
            "title": "Database file",
            "ok": True,
            "required": True,
            "detail": _db_detail(app),
            "hint": "Created automatically on first run / install.bat.",
            "action": None,
        },
    ]

    missing_required = [c for c in checks if c["required"] and not c["ok"]]

    return {
        "overall_ok": overall_ok,
        "checks": checks,
        "missing_required": missing_required,
        "platform": platform.platform(),
        "project_root": PROJECT_ROOT,
        "tesseract_path": tess_bin,
        "gemini_key_set": gemini_set,
    }


def _db_detail(app) -> str:
    if app is None:
        default = os.path.join(PROJECT_ROOT, "app", "medismart.db")
        return default if os.path.isfile(default) else "Will be created on first run"
    uri = app.config.get("SQLALCHEMY_DATABASE_URI", "")
    if uri.startswith("sqlite:///"):
        path = uri.replace("sqlite:///", "", 1)
        exists = os.path.isfile(path)
        return f"{path} ({'exists' if exists else 'missing — will create on start'})"
    return uri or "configured"


def _run_cmd(cmd: list[str], cwd: str | None = None, timeout: int = 900) -> dict[str, Any]:
    try:
        proc = subprocess.run(
            cmd,
            cwd=cwd or PROJECT_ROOT,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            shell=False,
        )
        out = (proc.stdout or "")[-4000:]
        err = (proc.stderr or "")[-4000:]
        return {
            "ok": proc.returncode == 0,
            "returncode": proc.returncode,
            "stdout": out,
            "stderr": err,
            "cmd": " ".join(cmd),
        }
    except FileNotFoundError as exc:
        return {"ok": False, "returncode": -1, "stdout": "", "stderr": str(exc), "cmd": " ".join(cmd)}
    except subprocess.TimeoutExpired:
        return {
            "ok": False,
            "returncode": -1,
            "stdout": "",
            "stderr": "Timed out — try running the .bat installer manually.",
            "cmd": " ".join(cmd),
        }


def install_pip_core() -> dict[str, Any]:
    req = os.path.join(PROJECT_ROOT, "requirements.txt")
    return _run_cmd([sys.executable, "-m", "pip", "install", "-r", req], timeout=900)


def install_pip_htr() -> dict[str, Any]:
    req = os.path.join(PROJECT_ROOT, "requirements-htr-optional.txt")
    return _run_cmd([sys.executable, "-m", "pip", "install", "-r", req], timeout=1800)


def install_tesseract() -> dict[str, Any]:
    """Try winget (Windows), then brew/apt hints. Also launches install_tesseract.bat."""
    system = platform.system().lower()
    results: list[dict[str, Any]] = []

    if system == "windows":
        # Prefer winget — silent-ish install of UB-Mannheim Tesseract
        winget = shutil.which("winget")
        if winget:
            r = _run_cmd(
                [
                    winget,
                    "install",
                    "--id",
                    "UB-Mannheim.TesseractOCR",
                    "-e",
                    "--accept-source-agreements",
                    "--accept-package-agreements",
                ],
                timeout=900,
            )
            results.append(r)
            if r["ok"] or _find_tesseract_binary():
                return {
                    "ok": True,
                    "message": "Tesseract installed via winget. Restart the server (run.bat) so MediSmart picks it up.",
                    "details": results,
                }

        bat = os.path.join(PROJECT_ROOT, "install_tesseract.bat")
        if os.path.isfile(bat):
            try:
                # Open a visible installer window the user can watch
                subprocess.Popen(
                    ["cmd.exe", "/c", "start", "MediSmart Tesseract Installer", bat],
                    cwd=PROJECT_ROOT,
                    shell=False,
                )
                return {
                    "ok": True,
                    "message": (
                        "Opened install_tesseract.bat in a new window. "
                        "Finish the installer, then restart MediSmart (run.bat)."
                    ),
                    "details": results,
                    "manual_url": "https://github.com/UB-Mannheim/tesseract/wiki",
                }
            except OSError as exc:
                results.append({"ok": False, "stderr": str(exc)})

        return {
            "ok": False,
            "message": (
                "Could not auto-install Tesseract. Download the Windows installer from "
                "https://github.com/UB-Mannheim/tesseract/wiki , then restart the app."
            ),
            "details": results,
            "manual_url": "https://github.com/UB-Mannheim/tesseract/wiki",
        }

    if system == "darwin":
        brew = shutil.which("brew")
        if brew:
            r = _run_cmd([brew, "install", "tesseract"], timeout=900)
            return {
                "ok": r["ok"] or bool(_find_tesseract_binary()),
                "message": "brew install tesseract finished" if r["ok"] else r.get("stderr", "brew failed"),
                "details": [r],
            }
        return {
            "ok": False,
            "message": "Install Homebrew, then run: brew install tesseract",
            "details": [],
        }

    # Linux
    if shutil.which("apt-get"):
        r = _run_cmd(["sudo", "apt-get", "install", "-y", "tesseract-ocr"], timeout=900)
        return {
            "ok": r["ok"] or bool(_find_tesseract_binary()),
            "message": "apt install finished" if r["ok"] else "apt failed — run: sudo apt install tesseract-ocr",
            "details": [r],
        }
    return {
        "ok": False,
        "message": "Install tesseract-ocr with your package manager, then restart MediSmart.",
        "details": [],
    }


def save_gemini_key(api_key: str) -> dict[str, Any]:
    """Write / update GEMINI_API_KEY in the project .env file."""
    api_key = (api_key or "").strip()
    if not api_key:
        return {"ok": False, "message": "Paste a non-empty API key."}

    env_path = os.path.join(PROJECT_ROOT, ".env")
    example = os.path.join(PROJECT_ROOT, ".env.example")
    if not os.path.isfile(env_path) and os.path.isfile(example):
        shutil.copy(example, env_path)

    lines: list[str] = []
    if os.path.isfile(env_path):
        with open(env_path, encoding="utf-8") as fh:
            lines = fh.readlines()

    found = False
    new_lines: list[str] = []
    for line in lines:
        if line.strip().startswith("GEMINI_API_KEY="):
            new_lines.append(f"GEMINI_API_KEY={api_key}\n")
            found = True
        else:
            new_lines.append(line)
    if not found:
        if new_lines and not new_lines[-1].endswith("\n"):
            new_lines[-1] += "\n"
        new_lines.append(f"GEMINI_API_KEY={api_key}\n")

    with open(env_path, "w", encoding="utf-8") as fh:
        fh.writelines(new_lines)

    os.environ["GEMINI_API_KEY"] = api_key
    return {
        "ok": True,
        "message": "Gemini key saved to .env. Restart the server (run.bat) so AI picks it up.",
    }


def reconfigure_engines(app) -> None:
    """Re-probe Tesseract / Gemini / HTR after an install (no full restart)."""
    from app.ocr import configure_tesseract
    from app.htr import configure_htr
    from app.gemini_ocr import configure_gemini

    configure_tesseract(app)
    configure_htr(app)
    configure_gemini(app)
