import os
from datetime import datetime, timedelta
from flask import Flask
from sqlalchemy import text
from app.config import Config
from app.extensions import db, login_manager, bcrypt
from app.models import User, Category, Medicine, Notification, Coupon, Store
from app.auth.loaders import *  # noqa: F401,F403  registers user_loader


def create_app(config_class=Config):
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    app.config.from_object(config_class)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    bcrypt.init_app(app)

    app.jinja_env.globals["enumerate"] = enumerate

    from app.utils import format_inr
    app.jinja_env.filters["inr"] = format_inr

    from app.public import bp as public_bp
    from app.auth import bp as auth_bp
    from app.user import bp as user_bp
    from app.admin import bp as admin_bp
    from app.store import bp as store_bp
    from app.errors import bp as errors_bp

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(store_bp)
    app.register_blueprint(errors_bp)

    with app.app_context():
        db.create_all()
        _migrate_schema()
        _seed_if_empty()
        _replace_placeholder_accounts()
        _seed_coupons_if_empty()
        _seed_stores_if_empty()
        _ensure_common_medicines()
        _ensure_extra_stores()
        _ensure_store_stocks()
        _ensure_store_staff()

    from app.ocr import configure_tesseract
    configure_tesseract(app)

    from app.htr import configure_htr
    configure_htr(app)

    from app.gemini_ocr import configure_gemini
    configure_gemini(app)

    return app


def _migrate_schema():
    """Lightweight auto-migration for existing SQLite databases: adds any
    columns introduced after the DB file was first created, without wiping
    existing data. Safe to run on every startup (no-op once columns exist)."""
    additions = {
        "users": [
            ("loyalty_points", "INTEGER NOT NULL DEFAULT 0"),
            ("preferred_district", "VARCHAR(80)"),
            ("store_id", "INTEGER"),
        ],
        "stores": [
            ("latitude", "FLOAT"),
            ("longitude", "FLOAT"),
        ],
        "orders": [
            ("subtotal", "FLOAT NOT NULL DEFAULT 0"),
            ("coupon_code", "VARCHAR(40)"),
            ("coupon_discount", "FLOAT NOT NULL DEFAULT 0"),
            ("points_redeemed", "INTEGER NOT NULL DEFAULT 0"),
            ("points_discount", "FLOAT NOT NULL DEFAULT 0"),
            ("points_earned", "INTEGER NOT NULL DEFAULT 0"),
            ("fulfillment_type", "VARCHAR(20) NOT NULL DEFAULT 'delivery'"),
            ("pickup_location", "VARCHAR(255)"),
            ("delivery_charge", "FLOAT NOT NULL DEFAULT 0"),
            ("store_id", "INTEGER"),
            ("pickup_code", "VARCHAR(10)"),
            ("picked_up_at", "DATETIME"),
            ("card_last4", "VARCHAR(4)"),
        ],
        "prescriptions": [
            ("ocr_text", "TEXT"),
            ("ai_status", "VARCHAR(20) NOT NULL DEFAULT 'pending'"),
            ("ai_summary", "TEXT"),
            ("ai_confidence", "FLOAT"),
            ("authenticity_score", "FLOAT"),
            ("authenticity_label", "VARCHAR(30)"),
            ("authenticity_reasons", "TEXT"),
            ("admin_note", "TEXT"),
        ],
    }
    with db.engine.connect() as conn:
        for table, columns in additions.items():
            existing = {row[1] for row in conn.execute(text(f"PRAGMA table_info({table})"))}
            for col_name, col_def in columns:
                if col_name not in existing:
                    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}"))
        conn.commit()
    # Backfill subtotal for pre-existing orders that predate the column.
    with db.engine.connect() as conn:
        conn.execute(text("UPDATE orders SET subtotal = total WHERE subtotal = 0 AND total != 0"))
        conn.commit()


def _seed_if_empty():
    if User.query.filter_by(role="admin").first():
        return

    admin = User(
        name="System Admin",
        email="admin@medismart.com",
        phone="9847001000",
        address="Palayam, Thiruvananthapuram",
        role="admin",
    )
    admin.set_password("admin123")
    db.session.add(admin)

    customer = User(
        name="Anjali Nair",
        email="user@medismart.com",
        phone="9876543210",
        address="Palayam, Thiruvananthapuram",
        role="user",
    )
    customer.set_password("user123")
    db.session.add(customer)

    categories = [
        ("Pain Relief", "Analgesics and anti-inflammatory medicines"),
        ("Antibiotics", "Bacterial infection treatments"),
        ("Vitamins", "Supplements and multivitamins"),
        ("Cardiac", "Heart and blood pressure medicines"),
        ("Diabetes", "Blood sugar management"),
        ("Respiratory", "Cough, cold and respiratory care"),
    ]
    cat_objs = []
    for name, desc in categories:
        c = Category(name=name, description=desc)
        db.session.add(c)
        cat_objs.append(c)

    # Prices are in INR (₹) — realistic Kerala retail-pharmacy pricing.
    samples = [
        ("Paracetamol 500mg", "Relief", "Fast acting pain and fever reliever.", 0, 25.00, 120, "pack", False),
        ("Ibuprofen 400mg", "Relief", "NSAID for pain and inflammation.", 0, 45.00, 80, "pack", False),
        ("Amoxicillin 250mg", "Relief", "Broad-spectrum antibiotic.", 1, 85.00, 40, "pack", True),
        ("Azithromycin 500mg", "Relief", "Macrolide antibiotic.", 1, 120.00, 25, "pack", True),
        ("Vitamin C 1000mg", "Relief", "Immune support chewable tablets.", 2, 180.00, 200, "bottle", False),
        ("Vitamin D3", "Relief", "Bone health supplement.", 2, 220.00, 150, "bottle", False),
        ("Multivitamin Daily", "Relief", "Complete daily multivitamin.", 2, 350.00, 90, "bottle", False),
        ("Atorvastatin 20mg", "Relief", "Cholesterol lowering medication.", 3, 150.00, 60, "pack", True),
        ("Metformin 500mg", "Relief", "Type 2 diabetes management.", 4, 60.00, 110, "pack", True),
        ("Insulin Glargine", "Relief", "Long-acting insulin pen.", 4, 850.00, 30, "pen", True),
        ("Cough Syrup", "Relief", "Relief from dry cough.", 5, 95.00, 75, "bottle", False),
        ("Salbutamol Inhaler", "Relief", "Asthma and bronchospasm relief.", 5, 280.00, 8, "inhaler", True),
    ]
    for name, brand, desc, ci, price, stock, unit, rx in samples:
        db.session.add(Medicine(
            name=name, brand=brand, description=desc, category_id=cat_objs[ci].id,
            price=price, stock=stock, unit=unit, requires_prescription=rx,
            expiry_date=(datetime.utcnow() + timedelta(days=180 + ci * 20)).date(),
        ))

    db.session.add(Notification(
        user_id=2, title="Welcome to MediSmart",
        message="Your account is ready. Start browsing medicines now!",
    ))

    db.session.commit()


def _replace_placeholder_accounts():
    """Replace the old American placeholder profiles if they are still in the database."""
    customer = User.query.filter_by(email="user@medismart.com").first()
    if customer and customer.name == "John Doe":
        customer.name = "Anjali Nair"
        customer.phone = "9876543210"
        customer.address = "Palayam, Thiruvananthapuram"
    admin = User.query.filter_by(email="admin@medismart.com").first()
    if admin and (admin.phone or "").startswith("+1"):
        admin.phone = "9847001000"
        if not admin.address or admin.address == "MediSmart HQ":
            admin.address = "Palayam, Thiruvananthapuram"
    db.session.commit()


def _ensure_common_medicines():
    """Bulk-load the full MediSmart medicine catalog on every startup.
    Skips names that already exist; upgrades placeholder brands when found."""
    from app.data.medicine_catalog import MEDICINE_BULK

    cat_by_name = {c.name: c for c in Category.query.all()}
    wanted_cats = [
        ("Pain Relief", "Analgesics and anti-inflammatory medicines"),
        ("Antibiotics", "Bacterial infection treatments"),
        ("Vitamins", "Supplements and multivitamins"),
        ("Cardiac", "Heart and blood pressure medicines"),
        ("Diabetes", "Blood sugar management"),
        ("Respiratory", "Cough, cold and respiratory care"),
        ("Gastro", "Acidity, ulcer and digestive care"),
        ("Allergy", "Antihistamines and allergy relief"),
        ("Thyroid", "Thyroid hormone therapy"),
        ("Neuro", "Neurology, migraine and mental health"),
        ("Dermatology", "Skin, hair and topical care"),
        ("Womens Health", "Women's health and hormones"),
        ("Eye Care", "Eye and ear care"),
        ("First Aid", "First aid and general care"),
    ]
    for name, desc in wanted_cats:
        if name not in cat_by_name:
            c = Category(name=name, description=desc)
            db.session.add(c)
            db.session.flush()
            cat_by_name[name] = c

    existing = {m.name.lower(): m for m in Medicine.query.all()}
    added = 0
    for name, brand, cat_name, price, stock, unit, rx, desc in MEDICINE_BULK:
        key = name.lower()
        if key in existing:
            med = existing[key]
            if (med.brand or "").strip().lower() in ("", "relief", "brand1", "generic"):
                med.brand = brand
            continue
        cat = cat_by_name.get(cat_name) or next(iter(cat_by_name.values()), None)
        if not cat:
            continue
        db.session.add(Medicine(
            name=name,
            brand=brand,
            description=desc,
            category_id=cat.id,
            price=price,
            stock=stock,
            unit=unit,
            requires_prescription=rx,
            expiry_date=(datetime.utcnow() + timedelta(days=300 + (added % 200))).date(),
        ))
        added += 1

    db.session.commit()


def _seed_coupons_if_empty():
    if Coupon.query.first():
        return
    db.session.add_all([
        Coupon(
            code="WELCOME10", description="10% off for new customers",
            discount_type="percent", discount_value=10, min_order_amount=0,
            max_uses=None, active=True,
        ),
        Coupon(
            code="KERALA50", description="₹50 off orders over ₹300",
            discount_type="fixed", discount_value=50, min_order_amount=300,
            max_uses=None, active=True,
        ),
        Coupon(
            code="MONSOON20", description="20% off orders over ₹500 (also unlocks free delivery)",
            discount_type="percent", discount_value=20, min_order_amount=500,
            max_uses=100, active=True,
        ),
    ])
    db.session.commit()


def _seed_stores_if_empty():
    """Seed the original four pickup branches as real Store rows (used to
    be a hardcoded PICKUP_LOCATIONS list in app/user/routes.py) so admins
    can manage them — add, edit, deactivate — from /admin/stores."""
    if Store.query.first():
        _backfill_store_coords()
        return
    db.session.add_all([
        Store(
            name="MediSmart Pharmacy — MG Road", address="MG Road",
            district="Thiruvananthapuram", phone="+91 471 555 0101",
            latitude=8.4876, longitude=76.9525,
        ),
        Store(
            name="MediSmart Pharmacy — Marine Drive", address="Marine Drive",
            district="Kochi", phone="+91 484 555 0102",
            latitude=9.9682, longitude=76.2805,
        ),
        Store(
            name="MediSmart Pharmacy — Mavoor Road", address="Mavoor Road",
            district="Kozhikode", phone="+91 495 555 0103",
            latitude=11.2588, longitude=75.7804,
        ),
        Store(
            name="MediSmart Pharmacy — Round South", address="Round South",
            district="Thrissur", phone="+91 487 555 0104",
            latitude=10.5242, longitude=76.2144,
        ),
        Store(
            name="MediSmart Pharmacy — Palayam", address="Palayam",
            district="Thiruvananthapuram", phone="+91 471 555 0105",
            latitude=8.5060, longitude=76.9558,
        ),
        Store(
            name="MediSmart Pharmacy — Edappally", address="Edappally Junction",
            district="Kochi", phone="+91 484 555 0106",
            latitude=10.0261, longitude=76.3125,
        ),
    ])
    db.session.commit()


def _backfill_store_coords():
    """Fill missing lat/lng on existing stores from district centres."""
    from app.geo import district_coords

    changed = False
    for store in Store.query.all():
        if store.latitude is not None and store.longitude is not None:
            continue
        coords = district_coords(store.district)
        if coords:
            store.latitude, store.longitude = coords
            changed = True
    if changed:
        db.session.commit()


def _ensure_extra_stores():
    """Add district branches that may be missing on older databases
    (safe to re-run — skips names that already exist)."""
    extras = [
        # Kottayam
        ("MediSmart Pharmacy — Kottayam Town", "TB Road, Near Collectorate", "Kottayam",
         "+91 481 555 0201", 9.5916, 76.5222),
        ("MediSmart Pharmacy — Kumarakom Road", "Kumarakom Road, CMS College Junction", "Kottayam",
         "+91 481 555 0202", 9.5955, 76.5210),
        ("MediSmart Pharmacy — Changanassery", "MC Road, Changanassery", "Kottayam",
         "+91 481 555 0203", 9.4461, 76.5409),
        ("MediSmart Pharmacy — Pala", "Stadium Junction, Pala", "Kottayam",
         "+91 482 555 0204", 9.7136, 76.6834),
        # Keep other newer branches available on older DBs too
        ("MediSmart Pharmacy — Palayam", "Palayam", "Thiruvananthapuram",
         "+91 471 555 0105", 8.5060, 76.9558),
        ("MediSmart Pharmacy — Edappally", "Edappally Junction", "Kochi",
         "+91 484 555 0106", 10.0261, 76.3125),
    ]
    existing = {s.name.lower() for s in Store.query.all()}
    added = 0
    for name, address, district, phone, lat, lng in extras:
        if name.lower() in existing:
            continue
        db.session.add(Store(
            name=name,
            address=address,
            district=district,
            phone=phone,
            latitude=lat,
            longitude=lng,
            is_active=True,
        ))
        added += 1
    if added:
        db.session.commit()


def _ensure_store_stocks():
    """Give every active shop a starter shelf inventory so Store Pickup /
    nearby takeaway can show real 'In stock' coverage.

    - Never overwrites an existing StoreStock row (manual edits kept).
    - Adds missing medicines onto shops that are empty or only partially stocked.
    - Assigns simple rack labels (Aisle / Rack / Shelf).
    """
    from app.models import StoreStock

    medicines = Medicine.query.filter(Medicine.stock > 0).all()
    if not medicines:
        return

    stores = Store.query.filter_by(is_active=True).all()
    added = 0
    for idx, store in enumerate(stores):
        existing_ids = {
            r.medicine_id for r in StoreStock.query.filter_by(store_id=store.id).all()
        }
        for mi, med in enumerate(medicines):
            if med.id in existing_ids:
                continue
            # Each branch gets roughly 20–40% of global stock (min 2, max 80)
            share = max(2, min(80, int(med.stock * (0.20 + (idx % 3) * 0.05))))
            if med.requires_prescription:
                share = max(2, share // 2)
            aisle = (mi % 6) + 1
            rack = chr(ord("A") + (mi % 4))
            shelf = (mi % 3) + 1
            db.session.add(StoreStock(
                store_id=store.id,
                medicine_id=med.id,
                stock=share,
                rack_location=f"Aisle {aisle} / Rack {rack} / Shelf {shelf}",
            ))
            added += 1
    if added:
        db.session.commit()


def _ensure_store_staff():
    """One shop-staff login per active branch so pharmacists can see
    their pickup orders, verify codes, and edit shelf stock."""
    stores = Store.query.filter_by(is_active=True).all()
    added = 0
    for store in stores:
        email = f"shop{store.id}@medismart.com"
        existing = User.query.filter_by(email=email).first()
        if existing:
            if existing.role != "store" or existing.store_id != store.id:
                existing.role = "store"
                existing.store_id = store.id
                added += 1
            continue
        staff = User(
            name=f"{store.name} Staff",
            email=email,
            phone=store.phone,
            address=store.address,
            role="store",
            store_id=store.id,
        )
        staff.set_password("shop123")
        db.session.add(staff)
        added += 1
    if added:
        db.session.commit()


app = create_app()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
