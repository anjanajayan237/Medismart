import os
from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, abort,
    current_app, jsonify, send_file,
)
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app.extensions import db
from app.models import (
    User, Medicine, Category, CartItem, Order, OrderItem, Prescription, Notification,
    Coupon, Review, Store, StoreStock,
)
from app.utils import save_upload, paginate, status_badge, reverse_order_effects
from app.backup import create_backup_zip, restore_backup_zip
from app.validation import (
    validate_medicine_name, validate_medicine_brand, validate_medicine_unit,
    validate_medicine_description,
)
from datetime import datetime, timedelta

bp = Blueprint("admin", __name__, url_prefix="/admin")


@bp.before_request
@login_required
def require_admin():
    if not current_user.is_admin:
        abort(403)


@bp.route("/dashboard")
def dashboard():
    from app.system_check import collect_status

    total_users = User.query.count()
    total_medicines = Medicine.query.count()
    pending_orders = Order.query.filter_by(status="pending").count()
    low_stock = Medicine.query.filter(Medicine.stock <= 10).all()
    all_meds = Medicine.query.all()
    expiring = [m for m in all_meds if m.is_expiring_soon]
    expired = [m for m in all_meds if m.is_expired]
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(6).all()
    system_status = collect_status(current_app)
    latest_prescriptions = (
        Prescription.query.order_by(Prescription.created_at.desc()).limit(5).all()
    )
    revenue = db.session.query(db.func.coalesce(db.func.sum(Order.total), 0.0)).filter(
        Order.status.in_(["confirmed", "shipped", "delivered"])
    ).scalar() or 0.0
    return render_template(
        "admin/dashboard.html",
        total_users=total_users,
        total_medicines=total_medicines,
        pending_orders=pending_orders,
        revenue=revenue,
        low_stock=low_stock,
        expiring=expiring,
        expired=expired,
        recent_orders=recent_orders,
        latest_prescriptions=latest_prescriptions,
        status_badge=status_badge,
        system_status=system_status,
    )


@bp.route("/medicines")
def medicines():
    q = request.args.get("q", "").strip()
    page = request.args.get("page", 1, type=int)
    query = Medicine.query
    if q:
        query = query.filter(Medicine.name.ilike(f"%{q}%"))
    query = query.order_by(Medicine.created_at.desc())
    pagination = paginate(query, page, 10)
    return render_template(
        "admin/medicines.html", medicines=pagination.items, pagination=pagination, q=q
    )


@bp.route("/medicines/add", methods=["GET", "POST"])
def add_medicine():
    categories = Category.query.order_by(Category.name).all()
    if request.method == "POST":
        name, name_err = validate_medicine_name(request.form.get("name", ""))
        brand, brand_err = validate_medicine_brand(request.form.get("brand", ""))
        description, desc_err = validate_medicine_description(request.form.get("description", ""))
        unit, unit_err = validate_medicine_unit(request.form.get("unit", "pack"))
        errors = [e for e in (name_err, brand_err, desc_err, unit_err) if e]
        try:
            price = max(0.0, float(request.form.get("price", 0) or 0))
        except (TypeError, ValueError):
            errors.append("Price must be a valid number.")
            price = 0.0
        try:
            stock = max(0, int(request.form.get("stock", 0) or 0))
        except (TypeError, ValueError):
            errors.append("Stock must be a whole number.")
            stock = 0
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template(
                "admin/add_medicine.html", categories=categories, form=request.form
            )
        image_path = None
        file = request.files.get("image")
        if file and file.filename:
            image_path = save_upload(file, "medicines")
        med = Medicine(
            name=name,
            brand=brand,
            description=description,
            category_id=request.form.get("category", type=int),
            price=price,
            stock=stock,
            unit=unit,
            image=image_path,
            requires_prescription=bool(request.form.get("requires_prescription")),
            expiry_date=_parse_date(request.form.get("expiry_date")),
        )
        db.session.add(med)
        db.session.flush()
        # Seed zero/starter shelf rows so new SKUs appear in shop inventory
        # without waiting for app restart.
        share = max(0, min(40, stock // 3)) if stock else 0
        for store in Store.query.filter_by(is_active=True).all():
            db.session.add(StoreStock(
                store_id=store.id,
                medicine_id=med.id,
                stock=share,
                rack_location="Aisle 1 / Rack A / Shelf 1" if share else None,
            ))
        db.session.commit()
        flash("Medicine added.", "success")
        return redirect(url_for("admin.medicines"))
    return render_template("admin/add_medicine.html", categories=categories, form={})


@bp.route("/medicines/<int:medicine_id>/edit", methods=["GET", "POST"])
def edit_medicine(medicine_id):
    medicine = Medicine.query.get_or_404(medicine_id)
    categories = Category.query.order_by(Category.name).all()
    if request.method == "POST":
        name, name_err = validate_medicine_name(request.form.get("name", medicine.name))
        brand, brand_err = validate_medicine_brand(request.form.get("brand", ""))
        description, desc_err = validate_medicine_description(request.form.get("description", ""))
        unit, unit_err = validate_medicine_unit(request.form.get("unit", medicine.unit))
        errors = [e for e in (name_err, brand_err, desc_err, unit_err) if e]
        try:
            price = max(0.0, float(request.form.get("price", medicine.price) or 0))
        except (TypeError, ValueError):
            errors.append("Price must be a valid number.")
            price = medicine.price
        try:
            stock = max(0, int(request.form.get("stock", medicine.stock) or 0))
        except (TypeError, ValueError):
            errors.append("Stock must be a whole number.")
            stock = medicine.stock
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template(
                "admin/edit_medicine.html", medicine=medicine, categories=categories
            )
        medicine.name = name
        medicine.brand = brand
        medicine.description = description
        medicine.category_id = request.form.get("category", type=int)
        medicine.price = price
        medicine.stock = stock
        medicine.unit = unit
        medicine.requires_prescription = bool(request.form.get("requires_prescription"))
        medicine.expiry_date = _parse_date(request.form.get("expiry_date"))
        file = request.files.get("image")
        if file and file.filename:
            medicine.image = save_upload(file, "medicines")
        db.session.commit()
        flash("Medicine updated.", "success")
        return redirect(url_for("admin.medicines"))
    return render_template("admin/edit_medicine.html", medicine=medicine, categories=categories)


@bp.route("/medicines/<int:medicine_id>/delete", methods=["POST"])
def delete_medicine(medicine_id):
    medicine = Medicine.query.get_or_404(medicine_id)
    has_orders = OrderItem.query.filter_by(medicine_id=medicine_id).first() is not None
    if has_orders:
        flash(
            "This medicine has existing order history and cannot be deleted. "
            "Set its stock to 0 or edit it to hide it from customers instead.",
            "danger",
        )
        return redirect(url_for("admin.medicines"))
    # Safe to remove: drop any lingering (uncommitted) cart references first,
    # since those carry no historical value.
    CartItem.query.filter_by(medicine_id=medicine_id).delete()
    db.session.delete(medicine)
    db.session.commit()
    flash("Medicine deleted.", "info")
    return redirect(url_for("admin.medicines"))


@bp.route("/inventory")
def inventory():
    q = request.args.get("q", "").strip()
    page = request.args.get("page", 1, type=int)
    query = Medicine.query
    if q:
        query = query.filter(Medicine.name.ilike(f"%{q}%"))
    query = query.order_by(Medicine.stock.asc())
    pagination = paginate(query, page, 12)
    return render_template(
        "admin/inventory.html", medicines=pagination.items, pagination=pagination, q=q
    )


@bp.route("/expiry-tracker")
def expiry_tracker():
    """Dedicated Expiry Tracking module: surfaces already-expired stock and
    stock expiring within 30 days, sorted soonest-first, so nothing gets
    sold or forgotten past its expiry date."""
    today = datetime.utcnow().date()
    all_meds = Medicine.query.filter(Medicine.expiry_date.isnot(None)).order_by(
        Medicine.expiry_date.asc()
    ).all()
    expired = [m for m in all_meds if m.expiry_date < today]
    expiring_soon = [m for m in all_meds if today <= m.expiry_date <= today + timedelta(days=30)]
    healthy_count = Medicine.query.count() - len(expired) - len(expiring_soon)
    return render_template(
        "admin/expiry.html",
        expired=expired,
        expiring_soon=expiring_soon,
        healthy_count=max(healthy_count, 0),
        today=today,
    )


@bp.route("/inventory-3d")
def inventory_3d():
    """Interactive 3D warehouse view of live stock. The table inventory page is unchanged."""
    return render_template("admin/inventory_3d.html")


@bp.route("/inventory-3d/data")
def inventory_3d_data():
    """JSON feed consumed by the Three.js scene on the 3D Inventory page."""
    medicines = Medicine.query.order_by(Medicine.category_id, Medicine.name).all()
    items = []
    for m in medicines:
        if m.is_expired:
            status = "expired"
        elif m.stock <= 0:
            status = "out"
        elif m.is_low_stock:
            status = "low"
        else:
            status = "healthy"
        stores_info = [
            {
                "store": s.store.name,
                "stock": s.stock,
                "rack": s.rack_location,
            }
            for s in m.store_stocks if s.store
        ]
        items.append({
            "id": m.id,
            "name": m.name,
            "brand": m.brand or "Generic",
            "category": m.category.name if m.category else "Uncategorized",
            "stock": m.stock,
            "price": m.price,
            "unit": m.unit,
            "status": status,
            "expiry_date": m.expiry_date.isoformat() if m.expiry_date else None,
            "stores": stores_info,
        })
    return jsonify(items=items)


@bp.route("/expiry-3d")
def expiry_3d():
    """3D Expiry Timeline — visualizes every batch's expiry date along a
    3D timeline track (external/bonus module; the classic Expiry Tracker
    page above is unchanged and still fully available)."""
    return render_template("admin/expiry_3d.html")


@bp.route("/expiry-3d/data")
def expiry_3d_data():
    """JSON feed consumed by the Three.js scene on the 3D Expiry Timeline page."""
    today = datetime.utcnow().date()
    medicines = Medicine.query.filter(Medicine.expiry_date.isnot(None)).order_by(
        Medicine.expiry_date.asc()
    ).all()
    items = []
    for m in medicines:
        days_left = (m.expiry_date - today).days
        if days_left < 0:
            status = "expired"
        elif days_left <= 30:
            status = "expiring_soon"
        else:
            status = "healthy"
        items.append({
            "id": m.id,
            "name": m.name,
            "brand": m.brand or "Generic",
            "stock": m.stock,
            "expiry_date": m.expiry_date.isoformat(),
            "days_left": days_left,
            "status": status,
        })
    return jsonify(items=items, today=today.isoformat())


@bp.route("/expiry-tracker/<int:medicine_id>/clear-stock", methods=["POST"])
def clear_expired_stock(medicine_id):
    """Zero out stock for an expired medicine so it can no longer be sold,
    without deleting its record (keeps order history intact)."""
    medicine = Medicine.query.get_or_404(medicine_id)
    medicine.stock = 0
    db.session.commit()
    flash(f"Stock cleared for '{medicine.name}' — it is now hidden from customers.", "success")
    return redirect(url_for("admin.expiry_tracker"))


@bp.route("/stores", methods=["GET", "POST"])
def stores():
    """Shop/branch management — replaces the old hardcoded pickup-location
    list. Each store can also carry its own rack-tracked stock (see
    store_inventory below), which powers the Store Pickup smart search."""
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        address = request.form.get("address", "").strip()
        if not name or not address:
            flash("Store name and address are required.", "danger")
            return redirect(url_for("admin.stores"))
        store = Store(
            name=name,
            address=address,
            district=request.form.get("district", "").strip() or None,
            phone=request.form.get("phone", "").strip() or None,
            is_active=True,
        )
        try:
            lat = request.form.get("latitude", type=float)
            lng = request.form.get("longitude", type=float)
            if lat is not None and lng is not None:
                store.latitude = lat
                store.longitude = lng
            else:
                from app.geo import district_coords
                coords = district_coords(store.district)
                if coords:
                    store.latitude, store.longitude = coords
        except (TypeError, ValueError):
            pass
        db.session.add(store)
        db.session.flush()
        # Auto-create shop-staff login for the new branch.
        staff_email = f"shop{store.id}@medismart.com"
        if not User.query.filter_by(email=staff_email).first():
            staff = User(
                name=f"{store.name} Staff",
                email=staff_email,
                phone=store.phone,
                address=store.address,
                role="store",
                store_id=store.id,
            )
            staff.set_password("shop123")
            db.session.add(staff)
        db.session.commit()
        # Seed shelf stock immediately so pickup works without restart.
        from app import _ensure_store_stocks
        _ensure_store_stocks()
        flash(f"Store '{store.name}' added.", "success")
        return redirect(url_for("admin.stores"))
    all_stores = Store.query.order_by(Store.id).all()
    return render_template("admin/stores.html", stores=all_stores)


@bp.route("/stores/<int:store_id>/edit", methods=["POST"])
def edit_store(store_id):
    store = Store.query.get_or_404(store_id)
    store.name = request.form.get("name", store.name).strip()
    store.address = request.form.get("address", store.address).strip()
    store.district = request.form.get("district", "").strip() or None
    store.phone = request.form.get("phone", "").strip() or None
    db.session.commit()
    flash("Store updated.", "success")
    return redirect(url_for("admin.stores"))


@bp.route("/stores/<int:store_id>/toggle", methods=["POST"])
def toggle_store(store_id):
    store = Store.query.get_or_404(store_id)
    store.is_active = not store.is_active
    db.session.commit()
    if not store.is_active:
        open_pickups = Order.query.filter(
            Order.store_id == store_id,
            Order.fulfillment_type == "pickup",
            Order.status.in_(["pending", "confirmed", "shipped"]),
        ).count()
        msg = f"Store '{store.name}' is now inactive (hidden from customers)."
        if open_pickups:
            msg += f" Staff can still finish {open_pickups} open pickup(s) from Shop Desk."
        flash(msg, "warning")
    else:
        flash(f"Store '{store.name}' is now active.", "success")
    return redirect(url_for("admin.stores"))


@bp.route("/stores/<int:store_id>/delete", methods=["POST"])
def delete_store(store_id):
    store = Store.query.get_or_404(store_id)
    has_orders = Order.query.filter_by(store_id=store_id).first() is not None
    if has_orders:
        flash(
            "This store has pickup order history and cannot be deleted. Deactivate it instead.",
            "danger",
        )
        return redirect(url_for("admin.stores"))
    # Remove / demote staff so they are not stuck with a dead store_id.
    for staff in User.query.filter_by(role="store", store_id=store_id).all():
        db.session.delete(staff)
    db.session.delete(store)
    db.session.commit()
    flash("Store and its shop login deleted.", "info")
    return redirect(url_for("admin.stores"))


@bp.route("/stores/<int:store_id>/inventory", methods=["GET", "POST"])
def store_inventory(store_id):
    """Per-branch rack location + stock assignment for every medicine —
    the "3D rack setup" data source: which rack a medicine sits on at this
    particular store, and how many units are on that shelf right now."""
    store = Store.query.get_or_404(store_id)
    if request.method == "POST":
        medicine_ids = request.form.getlist("medicine_id")
        for mid in medicine_ids:
            mid = int(mid)
            stock_val = max(0, int(request.form.get(f"stock_{mid}", 0) or 0))
            rack_val = request.form.get(f"rack_{mid}", "").strip() or None
            row = StoreStock.query.filter_by(store_id=store.id, medicine_id=mid).first()
            if stock_val == 0 and not rack_val:
                if row:
                    db.session.delete(row)
                continue
            if row:
                row.stock = stock_val
                row.rack_location = rack_val
            else:
                db.session.add(StoreStock(
                    store_id=store.id, medicine_id=mid, stock=stock_val, rack_location=rack_val,
                ))
        db.session.commit()
        flash(f"Rack/stock assignments saved for '{store.name}'.", "success")
        return redirect(url_for("admin.store_inventory", store_id=store.id))

    q = request.args.get("q", "").strip()
    query = Medicine.query
    if q:
        query = query.filter(Medicine.name.ilike(f"%{q}%"))
    medicines = query.order_by(Medicine.name).all()
    existing = {s.medicine_id: s for s in store.stocks}
    tracked = StoreStock.query.filter_by(store_id=store.id).count()
    units = db.session.query(db.func.coalesce(db.func.sum(StoreStock.stock), 0)).filter_by(
        store_id=store.id
    ).scalar() or 0
    return render_template(
        "admin/store_inventory.html",
        store=store,
        medicines=medicines,
        existing=existing,
        q=q,
        tracked_count=tracked,
        total_units=units,
    )


@bp.route("/stores/stock-all", methods=["POST"])
def stock_all_stores():
    """One-click: fill empty shop shelves from the global catalog (skips
    stores that already have inventory so manual edits are preserved)."""
    from app import _ensure_store_stocks
    # Force-fill stores that have zero rows; for stores with some rows, leave alone
    before = {
        s.id: StoreStock.query.filter_by(store_id=s.id).count()
        for s in Store.query.all()
    }
    _ensure_store_stocks()
    after = {
        s.id: StoreStock.query.filter_by(store_id=s.id).count()
        for s in Store.query.all()
    }
    filled = sum(1 for sid, n in after.items() if before.get(sid, 0) == 0 and n > 0)
    flash(
        f"Shelf stock assigned for {filled} empty shop(s). Stores that already had inventory were left unchanged.",
        "success",
    )
    return redirect(url_for("admin.stores"))


@bp.route("/prescriptions")
def prescriptions():
    page = request.args.get("page", 1, type=int)
    query = Prescription.query.order_by(Prescription.created_at.desc())
    pagination = paginate(query, page, 10)
    return render_template(
        "admin/prescriptions.html",
        prescriptions=pagination.items,
        pagination=pagination,
        status_badge=status_badge,
    )


@bp.route("/prescriptions/<int:prescription_id>/<action>", methods=["POST"])
def review_prescription(prescription_id, action):
    """Pharmacist verification step. Design decision (see chat): MediSmart is
    a pharmacy, not a clinic — a separate in-app "Doctor" module would mean
    the platform itself is practicing medicine, which is a different
    regulatory product (telemedicine) and out of scope here. The logically
    correct owner of prescription review is the pharmacist — i.e. this admin
    role — same as every real online pharmacy (1mg, PharmEasy, NetMeds...).

    If the handwriting/photo is unclear the pharmacist does NOT rewrite or
    guess the prescription (unsafe); they either reject with a reason, or
    use the new 'needs_info' action to ask the patient to re-upload a
    clearer photo or get a fresh legible copy from their doctor.
    """
    pres = Prescription.query.get_or_404(prescription_id)
    note = (request.form.get("note") or "").strip()
    pres.admin_note = note or None
    if action == "approve":
        pres.status = "approved"
        msg = "Your prescription has been approved by our pharmacist."
        if note:
            msg += f" Note: {note}"
    elif action == "reject":
        pres.status = "rejected"
        msg = "Your prescription was rejected."
        msg += f" Reason: {note}" if note else " Please contact support for details."
    elif action == "needs_info":
        pres.status = "needs_info"
        msg = note or "Our pharmacist couldn't fully read your prescription."
        msg += " Please re-upload a clearer photo, or ask your doctor for a fresh legible copy."
    else:
        abort(400)
    db.session.commit()
    notif = Notification(user_id=pres.user_id, title=f"Prescription #{pres.id} update", message=msg)
    db.session.add(notif)
    db.session.commit()
    flash("Prescription updated.", "success")
    return redirect(url_for("admin.prescriptions"))


@bp.route("/orders")
def orders():
    page = request.args.get("page", 1, type=int)
    store_id = request.args.get("store_id", type=int)
    query = Order.query.order_by(Order.created_at.desc())
    if store_id:
        query = query.filter_by(store_id=store_id)
    pagination = paginate(query, page, 10)
    stores = Store.query.order_by(Store.name).all()
    return render_template(
        "admin/orders.html",
        orders=pagination.items,
        pagination=pagination,
        status_badge=status_badge,
        stores=stores,
        filter_store_id=store_id,
    )


@bp.route("/orders/<int:order_id>/assign-store", methods=["POST"])
def assign_order_store(order_id):
    """Admin can change which branch packs/dispatches a pending order."""
    order = Order.query.get_or_404(order_id)
    if order.status not in ("pending", "confirmed"):
        flash("Only pending/confirmed orders can change dispatch shop.", "danger")
        return redirect(url_for("admin.orders"))
    new_store_id = request.form.get("store_id", type=int)
    store = Store.query.get(new_store_id) if new_store_id else None
    if not store or not store.is_active:
        flash("Select an active shop.", "danger")
        return redirect(url_for("admin.orders"))
    # Ensure shelf can cover the order before switching.
    for item in order.items:
        row = store.stock_row_for(item.medicine_id)
        have = row.stock if row else 0
        # When moving away from old store, old stock stays reserved until cancel —
        # for simplicity require new store to have enough on shelf now.
        if not row or have < item.quantity:
            flash(
                f"{store.name} does not have enough stock for {item.medicine.name if item.medicine else 'an item'}.",
                "danger",
            )
            return redirect(url_for("admin.orders"))

    old_store_id = order.store_id
    if old_store_id and old_store_id != store.id:
        # Move reserved shelf units: restock old, draw new.
        for item in order.items:
            if not item.medicine:
                continue
            old_row = next(
                (s for s in item.medicine.store_stocks if s.store_id == old_store_id), None
            )
            if old_row:
                old_row.stock += item.quantity
            new_row = store.stock_row_for(item.medicine_id)
            new_row.stock -= item.quantity
    elif not old_store_id:
        for item in order.items:
            row = store.stock_row_for(item.medicine_id)
            row.stock -= item.quantity

    order.store_id = store.id
    if order.fulfillment_type == "pickup":
        order.pickup_location = store.display_name
    from app.utils import notify_store_staff
    notify_store_staff(
        store.id,
        f"Order #{order.id} assigned to your shop",
        f"Admin assigned this {'pickup' if order.fulfillment_type == 'pickup' else 'delivery'} order to {store.name}.",
    )
    db.session.commit()
    flash(f"Order #{order.id} assigned to {store.name}.", "success")
    return redirect(url_for("admin.orders"))


@bp.route("/orders/<int:order_id>/status", methods=["POST"])
def update_order_status(order_id):
    order = Order.query.get_or_404(order_id)
    new_status = request.form.get("status")
    allowed = {"pending", "confirmed", "shipped", "delivered", "cancelled"}
    if new_status in allowed and new_status != order.status:
        if new_status == "cancelled":
            # Do not restock / cancel completed sales — that invents inventory.
            if order.status in ("shipped", "delivered"):
                flash(
                    "Cannot cancel a shipped or delivered order (stock was already fulfilled). "
                    "Use a separate refund process if needed.",
                    "danger",
                )
                return redirect(url_for("admin.orders"))
            reverse_order_effects(order)
            if order.fulfillment_type == "pickup" and order.store_id:
                from app.utils import notify_store_staff
                notify_store_staff(
                    order.store_id,
                    f"Pickup order #{order.id} cancelled",
                    f"Admin cancelled order #{order.id}. Do not prepare / release this order.",
                )
        if new_status == "delivered" and order.fulfillment_type == "pickup" and order.pickup_code:
            # Pickup orders should be released via "Verify Pickup Code"
            # below, not the generic status dropdown, so a code is always
            # checked before medicines leave the branch.
            flash(
                "This is a Store Pickup order with a pickup code — please use "
                "'Verify Pickup Code' to release it instead of the status dropdown.",
                "danger",
            )
            return redirect(url_for("admin.orders"))
        order.status = new_status
        db.session.commit()
        notif = Notification(
            user_id=order.user_id,
            title=f"Order #{order.id} status updated",
            message=f"Your order is now: {new_status.title()}.",
        )
        db.session.add(notif)
        db.session.commit()
        flash("Order status updated.", "success")
    return redirect(url_for("admin.orders"))


@bp.route("/orders/<int:order_id>/verify-pickup", methods=["POST"])
def verify_pickup(order_id):
    """Pharmacist-facing pickup-code check: staff asks the customer for
    their code and types it in here. Only on an exact match does the order
    flip to 'delivered' — this is the "secret code" hand-off control for
    Store Pickup orders, so a stranger can't collect someone else's order."""
    order = Order.query.get_or_404(order_id)
    if order.fulfillment_type != "pickup":
        flash("This order is not a Store Pickup order.", "danger")
        return redirect(url_for("admin.orders"))
    if order.status == "delivered":
        flash("This order has already been picked up.", "info")
        return redirect(url_for("admin.orders"))
    if order.status == "cancelled":
        flash("This order was cancelled and cannot be picked up.", "danger")
        return redirect(url_for("admin.orders"))
    entered = (request.form.get("code") or "").strip()
    if entered and order.pickup_code and entered == order.pickup_code:
        order.status = "delivered"
        order.picked_up_at = datetime.utcnow()
        db.session.commit()
        notif = Notification(
            user_id=order.user_id,
            title=f"Order #{order.id} picked up",
            message="Your order has been collected from the store. Thank you!",
        )
        db.session.add(notif)
        db.session.commit()
        flash(f"Order #{order.id} verified and marked as picked up.", "success")
    else:
        flash("Incorrect pickup code — order was not released.", "danger")
    return redirect(url_for("admin.orders"))


@bp.route("/users")
def users():
    page = request.args.get("page", 1, type=int)
    query = User.query.order_by(User.created_at.desc())
    pagination = paginate(query, page, 10)
    return render_template("admin/users.html", users=pagination.items, pagination=pagination)


@bp.route("/users/<int:user_id>/toggle", methods=["POST"])
def toggle_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot disable your own account.", "danger")
        return redirect(url_for("admin.users"))
    user.is_active_user = not user.is_active_user
    db.session.commit()
    flash("User status updated.", "success")
    return redirect(url_for("admin.users"))


@bp.route("/categories", methods=["GET", "POST"])
def categories():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        desc = request.form.get("description", "").strip()
        if name and not Category.query.filter_by(name=name).first():
            db.session.add(Category(name=name, description=desc))
            db.session.commit()
            flash("Category added.", "success")
        else:
            flash("Category already exists or invalid.", "danger")
        return redirect(url_for("admin.categories"))
    cats = Category.query.order_by(Category.name).all()
    return render_template("admin/categories.html", categories=cats)


@bp.route("/categories/<int:category_id>/delete", methods=["POST"])
def delete_category(category_id):
    cat = Category.query.get_or_404(category_id)
    db.session.delete(cat)
    db.session.commit()
    flash("Category deleted.", "info")
    return redirect(url_for("admin.categories"))


@bp.route("/coupons", methods=["GET", "POST"])
def coupons():
    if request.method == "POST":
        code = request.form.get("code", "").strip().upper()
        if not code:
            flash("Coupon code is required.", "danger")
            return redirect(url_for("admin.coupons"))
        if Coupon.query.filter_by(code=code).first():
            flash("A coupon with that code already exists.", "danger")
            return redirect(url_for("admin.coupons"))
        coupon = Coupon(
            code=code,
            description=request.form.get("description", "").strip(),
            discount_type=request.form.get("discount_type", "percent"),
            discount_value=float(request.form.get("discount_value", 0) or 0),
            min_order_amount=float(request.form.get("min_order_amount", 0) or 0),
            max_uses=request.form.get("max_uses", type=int),
            expires_at=_parse_date(request.form.get("expires_at")),
            active=True,
        )
        db.session.add(coupon)
        db.session.commit()
        flash(f"Coupon '{coupon.code}' created.", "success")
        return redirect(url_for("admin.coupons"))
    all_coupons = Coupon.query.order_by(Coupon.created_at.desc()).all()
    return render_template("admin/coupons.html", coupons=all_coupons)


@bp.route("/coupons/<int:coupon_id>/toggle", methods=["POST"])
def toggle_coupon(coupon_id):
    coupon = Coupon.query.get_or_404(coupon_id)
    coupon.active = not coupon.active
    db.session.commit()
    flash("Coupon status updated.", "success")
    return redirect(url_for("admin.coupons"))


@bp.route("/coupons/<int:coupon_id>/delete", methods=["POST"])
def delete_coupon(coupon_id):
    coupon = Coupon.query.get_or_404(coupon_id)
    db.session.delete(coupon)
    db.session.commit()
    flash("Coupon deleted.", "info")
    return redirect(url_for("admin.coupons"))


@bp.route("/reviews")
def reviews():
    page = request.args.get("page", 1, type=int)
    query = Review.query.order_by(Review.created_at.desc())
    pagination = paginate(query, page, 15)
    return render_template("admin/reviews.html", reviews=pagination.items, pagination=pagination)


@bp.route("/reviews/<int:review_id>/delete", methods=["POST"])
def delete_review(review_id):
    review = Review.query.get_or_404(review_id)
    db.session.delete(review)
    db.session.commit()
    flash("Review deleted.", "info")
    return redirect(url_for("admin.reviews"))


@bp.route("/reports")
def reports():
    total_orders = Order.query.count()
    total_revenue = db.session.query(db.func.coalesce(db.func.sum(Order.total), 0.0)).filter(
        Order.status.in_(["confirmed", "shipped", "delivered"])
    ).scalar() or 0.0
    total_users = User.query.count()
    total_medicines = Medicine.query.count()
    by_status = {}
    for s in ["pending", "confirmed", "shipped", "delivered", "cancelled"]:
        by_status[s] = Order.query.filter_by(status=s).count()
    top_meds = (
        db.session.query(Medicine.name, db.func.sum(OrderItem.quantity).label("sold"))
        .join(OrderItem, OrderItem.medicine_id == Medicine.id)
        .group_by(Medicine.id)
        .order_by(db.text("sold desc"))
        .limit(5)
        .all()
    )
    total_coupon_savings = db.session.query(
        db.func.coalesce(db.func.sum(Order.coupon_discount), 0.0)
    ).scalar() or 0.0
    active_coupons = Coupon.query.filter_by(active=True).count()
    total_points_issued = db.session.query(
        db.func.coalesce(db.func.sum(User.loyalty_points), 0)
    ).scalar() or 0
    avg_rating = db.session.query(db.func.coalesce(db.func.avg(Review.rating), 0.0)).scalar() or 0.0
    total_reviews = Review.query.count()
    all_meds = Medicine.query.all()
    expired_count = sum(1 for m in all_meds if m.is_expired)
    expiring_count = sum(1 for m in all_meds if m.is_expiring_soon)
    pickup_orders = Order.query.filter_by(fulfillment_type="pickup").count()
    delivery_orders = Order.query.filter_by(fulfillment_type="delivery").count()
    return render_template(
        "admin/reports.html",
        total_orders=total_orders,
        total_revenue=total_revenue,
        total_users=total_users,
        total_medicines=total_medicines,
        by_status=by_status,
        top_meds=top_meds,
        total_coupon_savings=total_coupon_savings,
        active_coupons=active_coupons,
        total_points_issued=total_points_issued,
        avg_rating=round(avg_rating, 1),
        total_reviews=total_reviews,
        expired_count=expired_count,
        expiring_count=expiring_count,
        pickup_orders=pickup_orders,
        delivery_orders=delivery_orders,
    )


@bp.route("/system-check")
def system_check():
    """Show which OCR / pip dependencies are installed on this PC and
    offer one-click install actions (especially Tesseract after moving PCs)."""
    from app.system_check import collect_status

    status = collect_status(current_app)
    return render_template("admin/system_check.html", status=status)


@bp.route("/system-check/install/<action>", methods=["POST"])
def system_check_install(action):
    """Trigger install / config for a missing dependency, then re-probe."""
    from app.system_check import (
        install_pip_core,
        install_pip_htr,
        install_tesseract,
        save_gemini_key,
        reconfigure_engines,
    )

    action = (action or "").strip().lower()
    result = {"ok": False, "message": f"Unknown action: {action}"}

    if action == "pip_core":
        result = install_pip_core()
        if result.get("ok"):
            result["message"] = "Python packages installed. Restart run.bat if imports were missing at startup."
        else:
            err = (result.get("stderr") or result.get("stdout") or "pip failed")[-800:]
            result["message"] = f"pip install failed: {err}"
    elif action == "htr":
        result = install_pip_htr()
        if result.get("ok"):
            result["message"] = "Optional HTR packages installed. Restart the server to load Torch/TrOCR."
        else:
            err = (result.get("stderr") or result.get("stdout") or "pip failed")[-800:]
            result["message"] = f"Optional HTR install failed: {err}"
    elif action == "tesseract":
        result = install_tesseract()
    elif action == "gemini":
        result = save_gemini_key(request.form.get("api_key", ""))
    else:
        flash(result["message"], "danger")
        return redirect(url_for("admin.system_check"))

    reconfigure_engines(current_app)
    flash(result.get("message") or ("Done." if result.get("ok") else "Install failed."), "success" if result.get("ok") else "danger")
    if result.get("manual_url") and not result.get("ok"):
        flash(f"Manual download: {result['manual_url']}", "info")
    return redirect(url_for("admin.system_check"))


@bp.route("/settings", methods=["GET"])
def settings():
    backups_dir = os.path.join(os.path.dirname(current_app.root_path), "backups")
    recent_backups = []
    if os.path.isdir(backups_dir):
        files = [f for f in os.listdir(backups_dir) if f.endswith(".zip")]
        files.sort(reverse=True)
        recent_backups = files[:5]
    return render_template("admin/settings.html", recent_backups=recent_backups)


@bp.route("/settings/backup", methods=["GET"])
def backup_db():
    """Download a single .zip containing the live database + every
    uploaded prescription/medicine image — used to move data to another PC
    install, or just as a safety snapshot before risky changes."""
    zip_path = create_backup_zip(current_app)
    return send_file(zip_path, as_attachment=True, download_name=os.path.basename(zip_path))


@bp.route("/settings/restore", methods=["POST"])
def restore_db():
    """Upload a previously exported .zip to overwrite the current database
    + uploads with it. A safety copy of the current DB is always taken
    first (see app/backup.py), so this can be undone from the backups/
    folder if the wrong file gets uploaded."""
    file = request.files.get("backup_file")
    if not file or file.filename == "":
        flash("Please choose a backup .zip file to restore.", "danger")
        return redirect(url_for("admin.settings"))
    if not file.filename.lower().endswith(".zip"):
        flash("That doesn't look like a MediSmart backup file (expected a .zip).", "danger")
        return redirect(url_for("admin.settings"))

    tmp_path = os.path.join(current_app.config["UPLOAD_FOLDER"], "_restore_upload.zip")
    os.makedirs(os.path.dirname(tmp_path), exist_ok=True)
    file.save(tmp_path)
    try:
        def _dispose():
            db.session.remove()
            db.engine.dispose()
        result = restore_backup_zip(current_app, tmp_path, dispose_engine=_dispose)
    except Exception as exc:  # noqa: BLE001 - surface any restore failure to the admin
        flash(f"Restore failed: {exc}", "danger")
        return redirect(url_for("admin.settings"))
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

    if result["restored_db"]:
        flash(
            f"Restore complete ({result['restored_files']} file(s) restored). "
            "Please restart the server (close and re-run run.bat) so the app "
            "picks up the restored database cleanly.",
            "success",
        )
    else:
        flash("That zip didn't contain a recognizable MediSmart database — nothing was changed.", "danger")
    return redirect(url_for("admin.settings"))


def _parse_date(value):
    if not value:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None
