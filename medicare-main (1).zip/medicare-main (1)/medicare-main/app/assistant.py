"""MediSmart AI Assistant — a lightweight, explainable rule/intent-based
chatbot. Fully offline (no external API key), backed by live data from the
app's own database (orders, medicines, coupons, loyalty points) so answers
are always accurate rather than hallucinated.

Design: a small set of intents are detected via keyword/regex matching
(highest-signal intent wins), then each intent handler pulls real data for
a grounded, specific reply plus optional quick-link buttons for the UI.
"""
import re
import difflib

from app.models import Medicine, Order, Coupon
from app.utils import format_inr

GREETING_RE = re.compile(r"\b(hi|hello|hey|good\s*(morning|afternoon|evening))\b", re.I)
THANKS_RE = re.compile(r"\b(thanks|thank you|thx|appreciate it)\b", re.I)
BYE_RE = re.compile(r"\b(bye|goodbye|see ya|see you|later)\b", re.I)

ORDER_RE = re.compile(r"\border\b|\btrack\w*\b|\bstatus\b|\bshipment\b|\bdelivery status\b", re.I)
ORDER_ID_RE = re.compile(r"#\s*(\d{1,6})|\border\s*(?:no\.?|number|#)?\s*(\d{1,6})", re.I)

PRICE_STOCK_RE = re.compile(
    r"\bprice\b|\bcost\b|\bhow much\b|\bstock\b|\bavailable\b|\bavailability\b|\bin stock\b",
    re.I,
)
PRESCRIPTION_RE = re.compile(r"\bprescription\w*\b|\brx\b|\bupload\b|\bgenuine\b|\bverif\w*\b", re.I)
DELIVERY_RE = re.compile(
    r"\bdeliver\w*\b|\bshipping\b|\bpickup\b|\btake\s*away\b|\bdistrict\w*\b|\bkerala\b", re.I
)
LOYALTY_RE = re.compile(r"\bloyalt\w*\b|\bpoints?\b|\brewards?\b", re.I)
COUPON_RE = re.compile(r"\bcoupon\w*\b|\bdiscount\w*\b|\bpromo\w*\b|\bpromo\s*code\b", re.I)
RETURN_RE = re.compile(r"\breturn\w*\b|\brefund\w*\b|\bcancel\w*\b", re.I)
CONTACT_RE = re.compile(r"\bcontact\w*\b|\bsupport\b|\bhelp\b|\bphone\b|\bcall\b|\bemail\b", re.I)
HOURS_RE = re.compile(r"\bhours?\b|\btiming\w*\b|\bopen\b|\bclose\w*\b", re.I)

WORD_RE = re.compile(r"[a-zA-Z][a-zA-Z0-9\-]{2,}")

QUICK_SUGGESTIONS = [
    "Track my order",
    "Delivery & pickup options",
    "My loyalty points",
    "Active coupons",
    "How does prescription AI work?",
]


def _find_medicine(text):
    """Fuzzy-match a medicine name/brand mentioned in free text against the
    catalog. Fine for the current catalog size; a search index can replace this
    if the catalog grows large."""
    words = WORD_RE.findall(text)
    if not words:
        return None
    candidates = set()
    for n in (1, 2, 3):
        for i in range(len(words) - n + 1):
            candidates.add(" ".join(words[i:i + n]).lower())
    if not candidates:
        return None

    best, best_ratio = None, 0.0
    for med in Medicine.query.all():
        for label in filter(None, [med.name, med.brand]):
            label_lower = label.lower()
            for cand in candidates:
                ratio = difflib.SequenceMatcher(None, cand, label_lower).ratio()
                if ratio > best_ratio and ratio >= 0.6:
                    best_ratio, best = ratio, med
    return best


def _reply(text, links=None):
    return {"reply": text, "links": links or []}


def _handle_order(low, user):
    if not (user and user.is_authenticated):
        return _reply(
            "Please log in first so I can look up your orders.",
            [{"label": "Login", "url": "/auth/login"}],
        )

    m = ORDER_ID_RE.search(low)
    if m:
        order_id = int(m.group(1) or m.group(2))
        order = Order.query.filter_by(id=order_id, user_id=user.id).first()
        if order:
            fulfillment = "Store Pickup" if order.fulfillment_type == "pickup" else "Home Delivery"
            return _reply(
                f"Order #{order.id} is currently **{order.status.title()}** "
                f"({fulfillment}). Total: {format_inr(order.total)}, placed on "
                f"{order.created_at.strftime('%b %d, %Y')}.",
                [{"label": f"View Order #{order.id}", "url": f"/user/orders/{order.id}"}],
            )
        return _reply(
            f"I couldn't find order #{order_id} under your account — double check the number?",
            [{"label": "My Orders", "url": "/user/orders"}],
        )

    recent = Order.query.filter_by(user_id=user.id).order_by(Order.created_at.desc()).first()
    if recent:
        return _reply(
            f"Your most recent order is #{recent.id}, currently **{recent.status.title()}**. "
            f"Ask me about a specific order number (e.g. 'order #{recent.id}') for more detail.",
            [{"label": "My Orders", "url": "/user/orders"}],
        )
    return _reply(
        "You don't have any orders yet — browse our catalog to place your first one!",
        [{"label": "Browse Medicines", "url": "/user/medicines"}],
    )


def _handle_price_stock(low):
    med = _find_medicine(low)
    if not med:
        return _reply(
            "I couldn't match that to a medicine in our catalog — could you check the spelling, "
            "or search for it directly?",
            [{"label": "Search Medicines", "url": "/user/medicines"}],
        )
    if med.is_expired:
        availability = "currently unavailable (expired stock)"
    elif med.stock <= 0:
        availability = "out of stock right now"
    elif med.is_low_stock:
        availability = f"low stock — only {med.stock} {med.unit} left"
    else:
        availability = f"in stock ({med.stock} {med.unit} available)"
    rx = " Prescription upload is required for this medicine." if med.requires_prescription else ""
    return _reply(
        f"**{med.name}** ({med.brand or 'Generic'}) is **{format_inr(med.price)}** per {med.unit}, "
        f"and {availability}.{rx}",
        [{"label": f"View {med.name}", "url": f"/user/medicines/{med.id}"}],
    )


def _handle_prescription():
    return _reply(
        "Upload a clear photo of your prescription and our AI reader will automatically extract "
        "the text, match it against our medicine catalog, and run a genuineness check (looking for "
        "a doctor/clinic name, date, and registration number). A licensed pharmacist still reviews "
        "every upload before approval.",
        [{"label": "Upload Prescription", "url": "/user/upload-prescription"}],
    )


def _handle_delivery():
    return _reply(
        "We deliver across all 14 districts of Kerala, or you can choose free **Store Pickup "
        "(Takeaway)** at checkout from our Thiruvananthapuram, Kochi, Kozhikode, or Thrissur outlets.",
        [{"label": "Start an order", "url": "/user/medicines"}],
    )


def _handle_loyalty(user):
    if user and user.is_authenticated and not user.is_admin:
        return _reply(
            f"You currently have **{user.loyalty_points} points**, worth about "
            f"{format_inr(user.loyalty_value)}. You earn roughly 1 point per ₹1 spent, and can redeem "
            f"100 points = ₹1 discount at checkout.",
            [{"label": "My Profile", "url": "/user/profile"}],
        )
    return _reply(
        "Everyone earns loyalty points on orders (about 1 point per ₹1 spent), redeemable for "
        "discounts at checkout — 100 points = ₹1. Log in to see your balance!",
        [{"label": "Login", "url": "/auth/login"}],
    )


def _handle_coupon():
    active = Coupon.query.filter_by(active=True).all()
    if active:
        codes = ", ".join(f"**{c.code}**" for c in active[:5])
        return _reply(
            f"Active coupon codes right now: {codes}. Apply one in your cart before checkout!",
            [{"label": "View Cart", "url": "/user/cart"}],
        )
    return _reply("There are no active coupons right now — check back soon!")


def _handle_return():
    return _reply(
        "You can cancel an order before it ships from the admin/support side — just contact us "
        "with your order number. For damaged or incorrect items, reach out within 48 hours of "
        "delivery for a refund or replacement.",
        [{"label": "Contact Us", "url": "/contact"}],
    )


def _handle_contact():
    return _reply(
        "Send a message from the Contact page. It is saved in the admin notification inbox.",
        [{"label": "Contact Page", "url": "/contact"}],
    )


def _handle_hours():
    return _reply(
        "You can place an order any time the site is running. Pickup is handled by the branch "
        "staff after they confirm the order."
    )


def _fallback():
    return _reply(
        "I'm not totally sure about that one, but I can help with order tracking, medicine "
        "prices/stock, prescriptions, delivery & pickup, loyalty points, and coupons — try asking "
        "about one of those, or use a quick suggestion below.",
        [
            {"label": "Browse Medicines", "url": "/user/medicines"},
            {"label": "My Orders", "url": "/user/orders"},
            {"label": "Upload Prescription", "url": "/user/upload-prescription"},
        ],
    )


def get_response(message, user=None):
    """Main entry point. `user` should be flask_login's `current_user`
    (works fine as AnonymousUserMixin too)."""
    text = (message or "").strip()
    if not text:
        return _reply("Could you type a message so I can help? 🙂")

    low = text.lower()

    if GREETING_RE.search(low) and len(low) <= 40:
        name = f", {user.name.split(' ')[0]}" if user and user.is_authenticated else ""
        return _reply(
            f"Hi{name}! I'm the MediSmart AI Assistant. I can help with order tracking, medicine "
            f"prices/stock, prescriptions, delivery & pickup, loyalty points, and coupons. What do "
            f"you need?"
        )
    if BYE_RE.search(low) and len(low) <= 25:
        return _reply("Take care! Come back anytime you need help. 👋")
    if THANKS_RE.search(low):
        return _reply("You're welcome! Anything else I can help with?")

    if ORDER_RE.search(low):
        return _handle_order(low, user)
    if PRESCRIPTION_RE.search(low):
        return _handle_prescription()
    if LOYALTY_RE.search(low):
        return _handle_loyalty(user)
    if DELIVERY_RE.search(low):
        return _handle_delivery()
    if COUPON_RE.search(low):
        return _handle_coupon()
    if RETURN_RE.search(low):
        return _handle_return()
    if HOURS_RE.search(low):
        return _handle_hours()
    if CONTACT_RE.search(low):
        return _handle_contact()
    if PRICE_STOCK_RE.search(low):
        return _handle_price_stock(low)

    # Last resort: maybe they just typed a medicine name with no keyword.
    med = _find_medicine(low)
    if med:
        return _handle_price_stock(low)

    return _fallback()
