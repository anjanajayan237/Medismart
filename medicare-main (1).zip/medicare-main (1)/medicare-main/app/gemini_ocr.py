"""Cloud fallback for messy/handwritten prescriptions, using Google's
Gemini API (free tier — no credit card, generous daily limits).

Why this exists: local OCR/HTR (app/ocr.py, app/htr.py) — and every free
pretrained handwriting model we evaluated — genuinely cannot read messy
doctor cursive reliably (see project notes). A general-purpose multimodal
model does far better here because it brings real-world medical vocabulary
knowledge to bear on ambiguous strokes, instead of guessing from a fixed
character set the way a small OCR model does.

Scope is deliberately narrow, per product decision: extract ONLY medicine
names / dosage / frequency. We do NOT ask it to transcribe the patient
name, doctor name, or other personal details — both to keep the prompt
focused (better accuracy on the part that matters) and to minimise what
personal data gets sent off-device.

Fully optional:
    - If GEMINI_API_KEY isn't set, or the `google-genai` package isn't
      installed, or any network/quota/parsing error occurs, every function
      degrades to "unavailable" / empty result and never raises. The app
      works exactly as before (Tesseract + local HTR only).
"""
import json
import os
import re

try:
    from google import genai
    from google.genai import types
    GENAI_AVAILABLE = True
except ImportError:  # pragma: no cover - optional dependency
    GENAI_AVAILABLE = False


MODEL_NAME = os.environ.get("GEMINI_MODEL", "gemini-3.5-flash")

_MIME_BY_EXT = {
    "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
    "gif": "image/gif", "bmp": "image/bmp", "tiff": "image/tiff",
}

PROMPT = """You are helping a pharmacist read a photo related to medicines.
The image may be a full doctor's prescription OR a cropped photo of one \
handwritten / printed medicine name. Handwriting may be messy or cursive.

Focus ONLY on medicines/drugs — ignore and do not transcribe the patient \
name, doctor name, hospital name, or registration numbers.

For every medicine, drug, IV fluid, or supplement you can identify (even \
partially), extract:
  - name: your best reading of the medicine/drug name (correct obvious \
    handwriting distortions using real-world medical knowledge, e.g. if it \
    looks close to a real drug name like Metformin / Paracetamol / \
    Amoxicillin, prefer the real drug name spelling)
  - dosage: strength/quantity if visible (e.g. "500mg", "5%"), else null
  - frequency: timing/route/instructions if visible (e.g. "twice a day", \
    "IV stat", "2 sachets"), else null
  - raw_text: the literal handwritten fragment you read this from

Also return:
  - is_prescription: true if this looks like a prescription sheet OR a \
    cropped medicine-name snippet meant for pharmacy reading; false only \
    if the image clearly has nothing medical
  - notes: one short sentence on legibility

Respond with ONLY valid JSON, no markdown fences, in this exact shape:
{"medicines": [{"name": "", "dosage": null, "frequency": null, "raw_text": ""}], \
"is_prescription": true, "notes": ""}
If you find no medicines, return an empty "medicines" list.
"""


def configure_gemini(app):
    """Cheap availability check (no network call) run at app startup.
    Sets app.config['GEMINI_READY'] so routes can check without re-probing."""
    api_key = (app.config.get("GEMINI_API_KEY") or os.environ.get("GEMINI_API_KEY") or "").strip()
    if api_key and not (os.environ.get("GEMINI_API_KEY") or "").strip():
        os.environ["GEMINI_API_KEY"] = api_key
    app.config["GEMINI_API_KEY"] = api_key
    app.config["GEMINI_READY"] = bool(GENAI_AVAILABLE and api_key)


def is_available():
    return GENAI_AVAILABLE and bool((os.environ.get("GEMINI_API_KEY") or "").strip())


def _strip_code_fences(text):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def extract_medicines(file_path, api_key=None):
    """Send the prescription image to Gemini and ask it to extract only the
    medicine-related information. Never raises.

    Returns None on any failure (missing key/deps, network/quota error,
    unparsable response) so callers can cleanly fall back to local OCR/HTR.
    On success returns:
        {"medicines": [{"name", "dosage", "frequency", "raw_text"}, ...],
         "is_prescription": bool, "notes": str}
    """
    key = (api_key or os.environ.get("GEMINI_API_KEY") or "").strip()
    if not key:
        try:
            from app.config import _resolve_gemini_api_key
            key = _resolve_gemini_api_key()
        except Exception:
            key = ""
    if not GENAI_AVAILABLE or not key:
        return None

    ext = file_path.rsplit(".", 1)[-1].lower() if "." in file_path else ""
    mime_type = _MIME_BY_EXT.get(ext)
    if not mime_type:
        return None  # e.g. PDFs — not handled here

    try:
        with open(file_path, "rb") as f:
            image_bytes = f.read()
    except Exception:
        return None

    try:
        client = genai.Client(api_key=key)
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=[
                types.Part.from_bytes(data=image_bytes, mime_type=mime_type),
                PROMPT,
            ],
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                temperature=0.1,
            ),
        )
        raw = (response.text or "").strip()
    except Exception:
        return None

    try:
        data = json.loads(_strip_code_fences(raw))
    except Exception:
        return None

    medicines = data.get("medicines")
    if not isinstance(medicines, list):
        return None

    cleaned = []
    for m in medicines:
        if not isinstance(m, dict):
            continue
        name = (m.get("name") or "").strip()
        if not name:
            continue
        cleaned.append({
            "name": name,
            "dosage": (m.get("dosage") or None),
            "frequency": (m.get("frequency") or None),
            "raw_text": (m.get("raw_text") or name).strip(),
        })

    return {
        "medicines": cleaned,
        "is_prescription": bool(data.get("is_prescription", True)),
        "notes": (data.get("notes") or "").strip(),
    }
