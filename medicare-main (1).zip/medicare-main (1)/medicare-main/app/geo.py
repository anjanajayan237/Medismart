"""Location helpers for nearby store pickup / takeaway ranking."""
from __future__ import annotations

import math
from typing import Optional


# Approximate city-centre coordinates for Kerala districts / major towns.
# Used when a store has no lat/lng yet, or when the customer picks a city
# instead of sharing GPS.
DISTRICT_COORDS = {
    "thiruvananthapuram": (8.5241, 76.9366),
    "trivandrum": (8.5241, 76.9366),
    "kollam": (8.8932, 76.6141),
    "pathanamthitta": (9.2648, 76.7870),
    "alappuzha": (9.4981, 76.3388),
    "alleppey": (9.4981, 76.3388),
    "kottayam": (9.5916, 76.5222),
    "idukki": (9.9189, 77.1025),
    "ernakulam": (9.9816, 76.2999),
    "kochi": (9.9312, 76.2673),
    "cochin": (9.9312, 76.2673),
    "thrissur": (10.5276, 76.2144),
    "palakkad": (10.7867, 76.6548),
    "malappuram": (11.0732, 76.0740),
    "kozhikode": (11.2588, 75.7804),
    "calicut": (11.2588, 75.7804),
    "wayanad": (11.6854, 76.1320),
    "kannur": (11.8745, 75.3704),
    "kasaragod": (12.4996, 74.9869),
}


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two WGS84 points, in kilometres."""
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlmb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


# Names that mean the same place for "is there a shop in this district?"
_DISTRICT_CANON = {
    "trivandrum": "thiruvananthapuram",
    "cochin": "kochi",
    "ernakulam": "kochi",
    "calicut": "kozhikode",
    "alleppey": "alappuzha",
}


def canonical_district(name: Optional[str]) -> str:
    key = (name or "").strip().lower()
    return _DISTRICT_CANON.get(key, key)


def districts_match(a: Optional[str], b: Optional[str]) -> bool:
    left, right = canonical_district(a), canonical_district(b)
    return bool(left) and left == right


def district_coords(name: Optional[str]):
    if not name:
        return None
    raw = name.strip().lower()
    if raw in DISTRICT_COORDS:
        return DISTRICT_COORDS[raw]
    return DISTRICT_COORDS.get(canonical_district(name))


def store_coords(store):
    """Return (lat, lng) for a store from explicit coords or district lookup."""
    lat = getattr(store, "latitude", None)
    lng = getattr(store, "longitude", None)
    if lat is not None and lng is not None:
        try:
            return float(lat), float(lng)
        except (TypeError, ValueError):
            pass
    return district_coords(getattr(store, "district", None))


def format_distance(km: Optional[float]) -> str:
    if km is None:
        return ""
    if km < 1:
        return f"{int(km * 1000)} m"
    if km < 10:
        return f"{km:.1f} km"
    return f"{km:.0f} km"


def resolve_customer_point(lat=None, lng=None, district=None, address=None):
    """Pick the best available customer reference point for ranking shops."""
    try:
        if lat is not None and lng is not None and str(lat) != "" and str(lng) != "":
            return float(lat), float(lng), "gps"
    except (TypeError, ValueError):
        pass
    for candidate in (district,):
        coords = district_coords(candidate)
        if coords:
            return coords[0], coords[1], "district"
    # Fall back: scan address text for a known district/city name
    blob = (address or "").lower()
    for name, coords in DISTRICT_COORDS.items():
        if name in blob:
            return coords[0], coords[1], "address"
    return None, None, None
