# Installing MediSmart on another PC

Everything below is Windows-friendly one-click `.bat` files — no manual
commands needed. Total setup time on a fresh PC is usually under a minute
(the installer skips the big optional AI packages by default — see the
bottom of this file if you want those too).

## First-time install on a new PC

1. Copy the whole project folder to the new PC (USB drive / zip / GitHub
   clone — anything works). **Do not copy the `.venv` folder** — it's
   machine-specific and the installer rebuilds it in seconds anyway.
2. Make sure [Python 3.10–3.12](https://www.python.org/downloads/) is
   installed, with **"Add python.exe to PATH"** ticked during setup.
3. Double-click **`install.bat`**. It will:
   - create a virtual environment (`.venv`)
   - install dependencies (fast — core packages only)
   - create a `.env` file from `.env.example`
   - create + seed the database (`app/medismart.db`)
4. Double-click **`run.bat`** — it starts the server and opens your browser
   to `http://127.0.0.1:5000` automatically.

Default logins after a fresh install:
- Admin: `admin@medismart.com` / `admin123`
- Customer: `user@medismart.com` / `user123`

## Moving your existing data to the new PC

If you already have medicines, orders, users, etc. on your old PC and want
them on the new one instead of the starter data:

**On the old PC:**
1. Double-click **`export_db.bat`**. It creates a single `.zip` file in the
   `backups\` folder containing the database + every uploaded
   prescription/medicine image.
2. Copy that `.zip` to the new PC (USB drive, cloud storage, email, etc.)

**On the new PC** (after running `install.bat` once):
1. Double-click **`import_db.bat`**.
2. Either drag the `.zip` file onto `import_db.bat`, or type its full path
   when prompted.
3. It restores the database + images (keeping a safety copy of whatever
   was there before, in `backups\pre_restore_<timestamp>.db`).
4. Run `run.bat` as normal.

You can also do both of these steps from inside the app itself, without
touching any `.bat` files: log in as admin → **Settings** → **Backup &
Restore Database** → *Download Backup* / *Restore*.

## Optional: fully offline handwriting recognition

By default, messy/handwritten prescriptions are read using the free
Google Gemini API (recommended — just paste a free key from
<https://aistudio.google.com/apikey> into `.env`). If you'd rather have a
slower, less accurate, but **fully offline** fallback that needs no
internet or API key at all, install the extra ~1-2 GB of packages:

```
.venv\Scripts\pip install -r requirements-htr-optional.txt
```

Nothing else changes — the app auto-detects whichever engines are
available (Gemini > local HTR > Tesseract) every time it starts.

## Troubleshooting

- **"Python was not found"** — install Python and make sure "Add to PATH"
  was checked, then re-run `install.bat`.
- **Prescription AI / OCR not working after moving PCs** — Tesseract is a
  **Windows program**, not a pip package. Run **`install_tesseract.bat`**,
  or start the app → login as admin → **System Check** → **Install Tesseract**.
  You can also paste a free Gemini API key there for handwritten Rx reading.
- **Port 5000 already in use** — another program (or a previous MediSmart
  window) is using it. Close the other "MediSmart Server" window, or edit
  the port number in `run.py`.
- **Restore says "Please restart the server"** — close the minimized
  "MediSmart Server" window and run `run.bat` again so the app picks up
  the freshly restored database.
