

@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found - run install.bat first.
    pause
    exit /b 1
)

echo Starting MediSmart server in a new window...
start "MediSmart Server (close this window to stop)" /min ".venv\Scripts\python.exe" run.py

echo Waiting for the server to come up...
timeout /t 3 /nobreak >nul

start "" http://127.0.0.1:5000/

echo.
echo MediSmart is running at http://127.0.0.1:5000
echo A minimized window titled "MediSmart Server" is running it -
echo close that window whenever you want to stop the app.
echo.
timeout /t 4 >nul
