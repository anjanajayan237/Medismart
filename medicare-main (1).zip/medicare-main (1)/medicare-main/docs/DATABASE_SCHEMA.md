# MediSmart — Database Schema Dictionary

**DBMS:** SQLite (file: `app/medismart.db`)  
**ORM:** Flask-SQLAlchemy  
**Naming:** snake_case table names matching models in `app/models/__init__.py`

---

## 1. Table list

| # | Table | Purpose |
|---|-------|---------|
| 1 | `users` | Customers and admins |
| 2 | `categories` | Medicine categories |
| 3 | `medicines` | Product catalog + global stock |
| 4 | `stores` | Pharmacy branches |
| 5 | `store_stocks` | Per-branch stock + rack location |
| 6 | `cart_items` | Active shopping cart lines |
| 7 | `orders` | Placed orders (header) |
| 8 | `order_items` | Order line items |
| 9 | `prescriptions` | Uploaded Rx + AI fields |
| 10 | `prescription_matches` | AI-detected medicines |
| 11 | `notifications` | In-app user alerts |
| 12 | `coupons` | Discount codes |
| 13 | `reviews` | Medicine ratings |

---

## 2. Table definitions

### 2.1 `users`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | User ID |
| name | VARCHAR(120) | N | | | Full name |
| email | VARCHAR(150) | N | UK, IDX | | Login email |
| password_hash | VARCHAR(255) | N | | | Bcrypt hash |
| phone | VARCHAR(30) | Y | | | Phone |
| address | TEXT | Y | | | Default address |
| role | VARCHAR(20) | N | | `user` | `user` or `admin` |
| is_active_user | BOOLEAN | N | | true | Account enabled |
| avatar | VARCHAR(255) | Y | | | Avatar path |
| loyalty_points | INTEGER | N | | 0 | Loyalty balance |
| created_at | DATETIME | N | | utcnow | Registered at |

**Notes:** 100 loyalty points = ₹1 redemption value.

---

### 2.2 `categories`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Category ID |
| name | VARCHAR(120) | N | UK | | Category name |
| description | TEXT | Y | | | Description |
| created_at | DATETIME | Y | | utcnow | Created |

---

### 2.3 `medicines`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Medicine ID |
| name | VARCHAR(160) | N | IDX | | Display name |
| brand | VARCHAR(120) | Y | | | Brand |
| description | TEXT | Y | | | Details |
| category_id | INTEGER | Y | FK → categories.id | | Category |
| price | FLOAT | N | | 0 | Price in INR |
| stock | INTEGER | N | | 0 | Global stock (delivery pool) |
| unit | VARCHAR(30) | Y | | pack | Unit label |
| image | VARCHAR(255) | Y | | | Image path |
| requires_prescription | BOOLEAN | Y | | false | Rx required? |
| expiry_date | DATE | Y | | | Expiry |
| created_at | DATETIME | Y | | utcnow | Created |

**Derived (in code, not columns):** `is_low_stock` (≤10), `is_expiring_soon` (≤30 days), `is_expired`, `avg_rating`.

---

### 2.4 `stores`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Store ID |
| name | VARCHAR(150) | N | | | Branch name |
| address | VARCHAR(255) | N | | | Street / landmark |
| district | VARCHAR(80) | Y | | | District (Kerala) |
| phone | VARCHAR(30) | Y | | | Contact |
| is_active | BOOLEAN | N | | true | Shown at checkout if true |
| created_at | DATETIME | Y | | utcnow | Created |

---

### 2.5 `store_stocks`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Row ID |
| store_id | INTEGER | N | FK → stores.id | | Branch |
| medicine_id | INTEGER | N | FK → medicines.id | | Medicine |
| stock | INTEGER | N | | 0 | Units on shelf |
| rack_location | VARCHAR(60) | Y | | | e.g. Aisle 3 / Rack B |
| updated_at | DATETIME | Y | | utcnow | Last update |

**Constraint:** `UNIQUE(store_id, medicine_id)` — one row per medicine per store.

---

### 2.6 `cart_items`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Cart line ID |
| user_id | INTEGER | N | FK → users.id | | Owner |
| medicine_id | INTEGER | N | FK → medicines.id | | Medicine |
| quantity | INTEGER | N | | 1 | Qty |
| created_at | DATETIME | Y | | utcnow | Added at |

---

### 2.7 `orders`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Order number |
| user_id | INTEGER | N | FK → users.id | | Customer |
| subtotal | FLOAT | N | | 0 | Before delivery/discounts |
| delivery_charge | FLOAT | N | | 0 | Delivery fee INR |
| total | FLOAT | N | | 0 | Payable total |
| status | VARCHAR(30) | N | | pending | pending / confirmed / shipped / delivered / cancelled |
| shipping_address | TEXT | Y | | | For delivery |
| payment_method | VARCHAR(40) | Y | | COD | COD or Card |
| card_last4 | VARCHAR(4) | Y | | | Demo card last 4 digits |
| fulfillment_type | VARCHAR(20) | N | | delivery | delivery or pickup |
| pickup_location | VARCHAR(255) | Y | | | Display string of store |
| store_id | INTEGER | Y | FK → stores.id | | Pickup branch |
| pickup_code | VARCHAR(10) | Y | | | 6-digit secret |
| picked_up_at | DATETIME | Y | | | When verified |
| coupon_code | VARCHAR(40) | Y | | | Applied coupon |
| coupon_discount | FLOAT | N | | 0 | Coupon ₹ off |
| points_redeemed | INTEGER | N | | 0 | Points used |
| points_discount | FLOAT | N | | 0 | Points ₹ off |
| points_earned | INTEGER | N | | 0 | Points gained |
| created_at | DATETIME | Y | | utcnow | Placed at |

---

### 2.8 `order_items`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Line ID |
| order_id | INTEGER | N | FK → orders.id | | Parent order |
| medicine_id | INTEGER | N | FK → medicines.id | | Medicine |
| quantity | INTEGER | N | | | Qty ordered |
| price | FLOAT | N | | | Unit price snapshot |

---

### 2.9 `prescriptions`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Rx ID |
| user_id | INTEGER | N | FK → users.id | | Uploader |
| file_path | VARCHAR(255) | N | | | Image path under static/ |
| note | TEXT | Y | | | Patient note |
| status | VARCHAR(30) | N | | pending | pending / approved / rejected / needs_info |
| admin_note | TEXT | Y | | | Pharmacist message |
| ocr_text | TEXT | Y | | | Raw OCR text |
| ai_status | VARCHAR(20) | N | | pending | pending / processed / unavailable / failed |
| ai_summary | TEXT | Y | | | AI summary |
| ai_confidence | FLOAT | Y | | | Overall confidence |
| authenticity_score | FLOAT | Y | | | 0..1 genuineness |
| authenticity_label | VARCHAR(30) | Y | | | likely_genuine / needs_review / low_confidence |
| authenticity_reasons | TEXT | Y | | | Pipe-separated reasons |
| created_at | DATETIME | Y | | utcnow | Uploaded at |

---

### 2.10 `prescription_matches`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | Match ID |
| prescription_id | INTEGER | N | FK → prescriptions.id | | Parent Rx |
| medicine_id | INTEGER | Y | FK → medicines.id | | Catalog match (nullable) |
| matched_text | VARCHAR(255) | N | | | Text found on Rx |
| dosage_hint | VARCHAR(120) | Y | | | Dosage if detected |
| confidence | FLOAT | N | | 0 | 0..1 |
| created_at | DATETIME | Y | | utcnow | Created |

---

### 2.11 `notifications`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | ID |
| user_id | INTEGER | N | FK → users.id | | Recipient |
| title | VARCHAR(180) | N | | | Title |
| message | TEXT | Y | | | Body |
| is_read | BOOLEAN | N | | false | Read flag |
| created_at | DATETIME | Y | | utcnow | Created |

---

### 2.12 `coupons`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | ID |
| code | VARCHAR(40) | N | UK, IDX | | Coupon code |
| description | VARCHAR(255) | Y | | | Description |
| discount_type | VARCHAR(20) | N | | percent | percent or fixed |
| discount_value | FLOAT | N | | 0 | % or ₹ amount |
| min_order_amount | FLOAT | N | | 0 | Min subtotal |
| max_uses | INTEGER | Y | | | Null = unlimited |
| used_count | INTEGER | N | | 0 | Times used |
| active | BOOLEAN | N | | true | Enabled |
| expires_at | DATE | Y | | | Expiry date |
| created_at | DATETIME | Y | | utcnow | Created |

---

### 2.13 `reviews`

| Column | Type | Null | Key | Default | Description |
|--------|------|------|-----|---------|-------------|
| id | INTEGER | N | PK | auto | ID |
| medicine_id | INTEGER | N | FK → medicines.id | | Medicine |
| user_id | INTEGER | N | FK → users.id | | Reviewer |
| rating | INTEGER | N | | | 1–5 stars |
| comment | TEXT | Y | | | Text |
| created_at | DATETIME | Y | | utcnow | Created |

**Constraint:** `UNIQUE(medicine_id, user_id)` — one review per user per medicine.

---

## 3. Foreign key map

```
users.id            ← orders.user_id
users.id            ← prescriptions.user_id
users.id            ← cart_items.user_id
users.id            ← notifications.user_id
users.id            ← reviews.user_id

categories.id       ← medicines.category_id

medicines.id        ← cart_items.medicine_id
medicines.id        ← order_items.medicine_id
medicines.id        ← reviews.medicine_id
medicines.id        ← prescription_matches.medicine_id
medicines.id        ← store_stocks.medicine_id

stores.id           ← store_stocks.store_id
stores.id           ← orders.store_id

orders.id           ← order_items.order_id
prescriptions.id    ← prescription_matches.prescription_id
```

---

## 4. Normalization notes (for viva)

- **1NF:** Atomic columns; no repeating groups.  
- **2NF:** Non-key attributes depend on full primary key (composite uniqueness handled via `store_stocks`, `reviews`).  
- **3NF:** No transitive dependency of non-key on non-key; category name lives in `categories`, not duplicated on every medicine.  
- **Order line price** is stored on `order_items.price` (snapshot) so historical orders stay correct if catalog price changes later.

---

## 5. Sample seed data (on fresh install)

- 1 admin + 1 demo user  
- 6 categories (Pain Relief, Antibiotics, Vitamins, Cardiac, Diabetes, Respiratory)  
- 12 sample medicines (INR prices)  
- 4 Kerala store branches (TVM, Kochi, Kozhikode, Thrissur)  
- Coupons: `WELCOME10`, `KERALA50`, `MONSOON20`
