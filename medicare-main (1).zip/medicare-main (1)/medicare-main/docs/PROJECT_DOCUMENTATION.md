# MediSmart — Complete Project Documentation

**Title:** MediSmart — Smart Pharmacy Management & Online Medicine Ordering System with AI Prescription Reader  

**Type:** College / academic project documentation  
**Database:** SQLite (development) / optional PostgreSQL via `DATABASE_URL`  
**Backend:** Python Flask + Flask-SQLAlchemy  
**Frontend:** Jinja2 templates, Bootstrap 5, Three.js (3D inventory)  

---

## 1. Introduction

### 1.1 Purpose
MediSmart is a web-based online pharmacy system designed for the Kerala retail-pharmacy context. Customers can browse medicines (priced in **INR ₹**), upload prescriptions for AI-assisted reading, place home-delivery or store-pickup orders, and earn loyalty points. Administrators (pharmacists) manage inventory, stores/racks, prescriptions, orders, coupons, and reports.

### 1.2 Objectives
- Digitize medicine catalog, cart, and checkout with delivery charges (free above ₹500).
- Provide AI prescription upload & pharmacist review workflow.
- Support multi-branch **stores**, per-store **rack locations**, and pickup **verification codes**.
- Visualize inventory / expiry in classic tables and **3D** views.
- Allow backup/restore of database for submission demos and portability.

### 1.3 Actors
| Actor | Description |
|-------|-------------|
| **Customer (User)** | Registers, browses, uploads Rx, orders, tracks pickup/delivery |
| **Admin / Pharmacist** | Manages medicines, stock, stores, reviews prescriptions, verifies pickup |
| **System (AI Engine)** | OCR/HTR/Gemini analysis of uploaded prescriptions |
| **Guest** | Views public home / about / contact (limited) |

---

## 2. System Architecture (High Level)

```mermaid
flowchart TB
  subgraph Client["Client Layer"]
    B[Web Browser]
  end

  subgraph App["Application Layer — Flask"]
    Pub[Public Routes]
    Auth[Auth Module]
    Usr[User Module]
    Adm[Admin Module]
    AI[OCR / Gemini / HTR]
  end

  subgraph Data["Data Layer"]
    DB[(SQLite medismart.db)]
    UP[Uploaded Files<br/>static/uploads]
  end

  subgraph Ext["External Optional"]
    GEM[Google Gemini API]
  end

  B --> Pub & Auth & Usr & Adm
  Usr --> AI
  AI -.-> GEM
  Pub & Auth & Usr & Adm --> DB
  Usr & Adm --> UP
```

---

## 3. Entity–Relationship (ER) Diagram

```mermaid
erDiagram
  users ||--o{ orders : places
  users ||--o{ prescriptions : uploads
  users ||--o{ cart_items : has
  users ||--o{ notifications : receives
  users ||--o{ reviews : writes

  categories ||--o{ medicines : groups
  medicines ||--o{ cart_items : "in cart"
  medicines ||--o{ order_items : "ordered as"
  medicines ||--o{ reviews : "rated in"
  medicines ||--o{ prescription_matches : matched
  medicines ||--o{ store_stocks : stocked_at

  stores ||--o{ store_stocks : holds
  stores ||--o{ orders : "pickup at"

  orders ||--|{ order_items : contains
  prescriptions ||--o{ prescription_matches : detects

  users {
    int id PK
    string name
    string email UK
    string password_hash
    string phone
    text address
    string role
    bool is_active_user
    int loyalty_points
    datetime created_at
  }

  categories {
    int id PK
    string name UK
    text description
  }

  medicines {
    int id PK
    string name
    string brand
    int category_id FK
    float price
    int stock
    string unit
    bool requires_prescription
    date expiry_date
  }

  stores {
    int id PK
    string name
    string address
    string district
    string phone
    bool is_active
  }

  store_stocks {
    int id PK
    int store_id FK
    int medicine_id FK
    int stock
    string rack_location
  }

  orders {
    int id PK
    int user_id FK
    int store_id FK
    float subtotal
    float delivery_charge
    float total
    string status
    string fulfillment_type
    string pickup_code
    string payment_method
    string card_last4
  }

  order_items {
    int id PK
    int order_id FK
    int medicine_id FK
    int quantity
    float price
  }

  prescriptions {
    int id PK
    int user_id FK
    string file_path
    string status
    text ocr_text
    float authenticity_score
    text admin_note
  }

  prescription_matches {
    int id PK
    int prescription_id FK
    int medicine_id FK
    string matched_text
    float confidence
  }

  cart_items {
    int id PK
    int user_id FK
    int medicine_id FK
    int quantity
  }

  coupons {
    int id PK
    string code UK
    string discount_type
    float discount_value
    bool active
  }

  reviews {
    int id PK
    int medicine_id FK
    int user_id FK
    int rating
  }

  notifications {
    int id PK
    int user_id FK
    string title
    bool is_read
  }
```

### 3.1 Relationship summary

| Relationship | Type | Meaning |
|--------------|------|---------|
| User → Orders | 1 : N | One user places many orders |
| Order → OrderItems | 1 : N | One order has many line items |
| Medicine → OrderItems | 1 : N | Same medicine can appear in many orders |
| Category → Medicines | 1 : N | Category groups medicines |
| User → Prescriptions | 1 : N | User uploads many Rx images |
| Prescription → Matches | 1 : N | AI finds multiple medicines |
| Store ↔ Medicine | M : N via StoreStock | Branch stock + rack |
| Store → Orders | 1 : N | Pickup orders linked to a branch |
| User ↔ Medicine | M : N via Reviews / Cart | Ratings and cart |

---

## 4. Use Case Diagram

```mermaid
flowchart LR
  subgraph Actors
    C((Customer))
    A((Admin / Pharmacist))
    G((Guest))
    S((AI System))
  end

  subgraph CustomerUC["Customer Use Cases"]
    UC1[Register / Login]
    UC2[Browse & Search Medicines]
    UC3[Manage Cart]
    UC4[Upload Prescription]
    UC5[Checkout Delivery / Pickup]
    UC6[View Orders & Pickup Code]
    UC7[Cancel Pending Order]
    UC8[Write Review]
    UC9[View Notifications]
  end

  subgraph AdminUC["Admin Use Cases"]
    UA1[Manage Medicines & Categories]
    UA2[Track Inventory & Expiry]
    UA3[View 3D Inventory / Expiry]
    UA4[Review Prescriptions]
    UA5[Update Order Status]
    UA6[Verify Pickup Code]
    UA7[Manage Stores & Rack Stock]
    UA8[Manage Coupons]
    UA9[View Reports]
    UA10[Backup / Restore DB]
  end

  subgraph SystemUC["System Use Cases"]
    US1[OCR / AI Analyze Prescription]
    US2[Calculate Delivery Charge]
    US3[Apply Coupon & Loyalty Points]
  end

  G --> UC2
  C --> UC1 & UC2 & UC3 & UC4 & UC5 & UC6 & UC7 & UC8 & UC9
  A --> UA1 & UA2 & UA3 & UA4 & UA5 & UA6 & UA7 & UA8 & UA9 & UA10
  C -.-> UC4
  UC4 --> US1
  S --> US1
  UC5 --> US2 & US3
```

### 4.1 Major use cases (brief)

| ID | Use Case | Actor | Description |
|----|----------|-------|-------------|
| UC4 | Upload Prescription | Customer | Upload image; AI extracts medicine names; pharmacist approves/rejects/needs_info |
| UC5 | Checkout | Customer | Choose delivery or store pickup; COD or demo card; pay delivery rules |
| UC6 | Pickup Code | Customer | See 6-digit code; show at store |
| UA4 | Review Prescription | Admin | Approve / reject / request clearer photo with note |
| UA6 | Verify Pickup | Admin | Enter customer code → mark delivered |
| UA7 | Store Rack Setup | Admin | Assign stock + rack location per branch |

---

## 5. Data Flow Diagrams (DFD)

### 5.1 Context Diagram (DFD Level 0)

```mermaid
flowchart TB
  C([Customer])
  A([Admin / Pharmacist])
  AI([Gemini / OCR Engine])

  MS[MediSmart System]

  C -->|Register, browse, cart, Rx upload, place order| MS
  MS -->|Order status, pickup code, notifications| C
  A -->|Manage stock, review Rx, verify pickup| MS
  MS -->|Alerts, reports, pending Rx/orders| A
  MS -->|Prescription image for analysis| AI
  AI -->|Matched medicines + confidence| MS
```

### 5.2 DFD Level 1 — Major processes

```mermaid
flowchart TB
  C([Customer])
  A([Admin])
  AI([AI Engine])

  P1[1.0 Authenticate User]
  P2[2.0 Browse Catalog]
  P3[3.0 Manage Cart]
  P4[4.0 Process Prescription]
  P5[5.0 Place Order]
  P6[6.0 Admin Inventory & Stores]
  P7[7.0 Admin Order & Pickup]
  P8[8.0 Notify User]

  D1[(D1 Users)]
  D2[(D2 Medicines / Categories)]
  D3[(D3 Cart)]
  D4[(D4 Prescriptions / Matches)]
  D5[(D5 Orders / Items)]
  D6[(D6 Stores / StoreStock)]
  D7[(D7 Notifications)]
  D8[(D8 Coupons)]

  C --> P1 --> D1
  C --> P2 --> D2
  C --> P3 --> D3
  P3 --> D2
  C --> P4
  P4 --> AI
  AI --> P4
  P4 --> D4
  A --> P4
  C --> P5
  P5 --> D3 & D2 & D5 & D6 & D8
  P5 --> P8 --> D7
  A --> P6 --> D2 & D6
  A --> P7 --> D5 & D6
  P7 --> P8
```

### 5.3 DFD Level 2 — Process 5.0 Place Order (detail)

```mermaid
flowchart LR
  C([Customer])

  P51[5.1 Validate Cart<br/>stock / expiry / Rx]
  P52[5.2 Compute Totals<br/>coupon / points / delivery]
  P53[5.3 Choose Fulfillment]
  P54[5.4 Process Payment<br/>COD or demo Card]
  P55[5.5 Persist Order<br/>decrement stock]
  P56[5.6 Generate Pickup Code<br/>if pickup]

  D3[(Cart)]
  D2[(Medicines)]
  D4[(Prescriptions)]
  D5[(Orders)]
  D6[(Stores / Stock)]
  D1[(Users loyalty)]

  C --> P51
  P51 --> D3 & D2 & D4
  P51 --> P52 --> D1
  P52 --> P53
  P53 -->|delivery| P54
  P53 -->|pickup + store| P54
  P54 --> P55 --> D5 & D2 & D6 & D1
  P55 --> P56
  P56 --> D5
```

---

## 6. Module Structure

| Module | Path | Responsibility |
|--------|------|----------------|
| Public | `app/public/` | Home, about, contact |
| Auth | `app/auth/` | Login, register, logout (validated inputs) |
| User | `app/user/` | Cart, checkout, Rx upload, orders, profile |
| Admin | `app/admin/` | Medicines, inventory, stores, Rx review, reports, backup |
| AI | `app/ocr.py`, `gemini_ocr.py`, `htr.py` | Prescription text extraction & matching |
| Models | `app/models/` | SQLAlchemy ORM entities |
| Backup | `app/backup.py` | Zip export/import of DB + uploads |

---

## 7. Important Business Rules (for viva)

1. **Currency:** All amounts displayed in Indian Rupees (₹).  
2. **Delivery:** Flat delivery charge if home delivery and subtotal &lt; ₹500; free if ≥ ₹500 or store pickup.  
3. **Rx medicines:** Cannot checkout Rx items without an **approved** prescription.  
4. **Stock:** Cart quantity cannot exceed available stock; order decrements global stock (and store stock for pickup).  
5. **Pickup:** 6-digit `pickup_code`; admin must verify before marking delivered.  
6. **Card payment:** Demo only — only last 4 digits stored (`card_last4`).  
7. **Loyalty:** ~1 point per ₹1 product spend; 100 points = ₹1 redemption.  
8. **Cancellation:** Pending orders can be cancelled; stock + points + coupon usage reversed.

---

## 8. Order Status Lifecycle

```mermaid
stateDiagram-v2
  [*] --> pending
  pending --> confirmed : Admin confirms
  confirmed --> shipped : Admin ships
  shipped --> delivered : Delivered / pickup verified
  pending --> cancelled : User or Admin cancel
  confirmed --> cancelled : Admin cancel
  delivered --> [*]
  cancelled --> [*]
```

**Pickup shortcut:** Admin enters correct pickup code → status becomes `delivered` + `picked_up_at` set.

---

## 9. Prescription Workflow

```mermaid
sequenceDiagram
  actor U as Customer
  participant App as MediSmart
  participant AI as OCR/Gemini
  actor P as Pharmacist

  U->>App: Upload prescription image
  App->>AI: Analyze image
  AI-->>App: OCR text + medicine matches
  App-->>U: Show AI results (pending review)
  P->>App: Approve / Reject / Needs info + note
  App-->>U: Notification
  Note over U,App: Only approved Rx unlocks Rx medicines at checkout
```

---

## 10. Technology Stack

| Layer | Technology |
|-------|------------|
| Language | Python 3.10+ |
| Framework | Flask 3 |
| ORM | Flask-SQLAlchemy |
| Auth | Flask-Login, Flask-Bcrypt |
| DB | SQLite (`app/medismart.db`) |
| UI | Bootstrap 5, Bootstrap Icons, custom CSS |
| 3D | Three.js (inventory & expiry timeline) |
| AI | Google Gemini (preferred), Tesseract, optional TrOCR |
| Deploy | `install.bat` / `run.bat` or Docker |

---

## 11. How to Show This to Faculty

1. Open **GitHub → `docs/PROJECT_DOCUMENTATION.md`** (diagrams render).  
2. Or export diagrams from [mermaid.live](https://mermaid.live) into your report Word/PPT.  
3. Live demo: Admin → Stores / Inventory 3D / Prescriptions / Orders.  
4. Show SQLite tables using DB Browser for SQLite on `app/medismart.db` (after running the app once).

For column-level detail, see [DATABASE_SCHEMA.md](./DATABASE_SCHEMA.md).  
For copy-paste diagrams only, see [DIAGRAMS.md](./DIAGRAMS.md).
