# MediSmart — Project Documentation Index

**Project:** MediSmart — Smart Online Pharmacy & AI Prescription System  
**Domain:** Kerala-based e-pharmacy (amounts in INR)  
**Audience:** College project review / viva / submission to faculty  

This folder contains design documentation for demonstrating database structure, diagrams, and system flow.

| Document | Contents |
|----------|----------|
| [**MediSmart_Mini_Project.pptx**](./MediSmart_Mini_Project.pptx) | **Ready PowerPoint** — open and edit names on title slide |
| [**MINI_PROJECT_SLIDES.md**](./MINI_PROJECT_SLIDES.md) | Same content in Markdown (source for the PPT) |
| [PROJECT_DOCUMENTATION.md](./PROJECT_DOCUMENTATION.md) | Full technical documentation |
| [DATABASE_SCHEMA.md](./DATABASE_SCHEMA.md) | Detailed table-by-table schema |
| [DIAGRAMS.md](./DIAGRAMS.md) | Mermaid source + PNG previews |
| [diagrams/](./diagrams/) | **Ready PNG images** for Word / PowerPoint |

### PNG files (insert into Word / PPT)

| File | Diagram |
|------|---------|
| `diagrams/01_er_diagram.png` | Entity–Relationship diagram |
| `diagrams/02_use_case.png` | Use case diagram |
| `diagrams/03_dfd_level0_context.png` | DFD Level 0 (context) |
| `diagrams/04_dfd_level1.png` | DFD Level 1 |
| `diagrams/05_architecture.png` | System architecture |
| `diagrams/06_checkout_activity.png` | Checkout activity flow |
| `diagrams/07_pickup_sequence.png` | Store pickup sequence |
| `diagrams/08_order_lifecycle.png` | Order status lifecycle |
| `diagrams/09_prescription_sequence.png` | Prescription AI + review flow |
| `diagrams/10_dfd_level2_checkout.png` | DFD Level 2 (checkout) |
| `diagrams/11_class_diagram.png` | Class / ORM model diagram |

### How to view diagrams

1. **PNG (easiest for sir):** open `docs/diagrams/*.png` and paste into Word/PPT.  
2. **GitHub:** open any `.md` file — Mermaid diagrams render automatically.  
3. **VS Code / Cursor:** open the file and use Markdown preview.

### Starter accounts (after install)

| Role | Email | Password |
|------|-------|----------|
| Admin / Pharmacist | `admin@medismart.com` | `admin123` |
| Customer | `user@medismart.com` | `user123` |

See also: [`../INSTALL.md`](../INSTALL.md) for setup on another PC.
