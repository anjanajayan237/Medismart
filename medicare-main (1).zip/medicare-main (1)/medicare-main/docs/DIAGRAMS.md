# MediSmart — Diagrams Pack (for Report / PPT)

**Ready-made PNG files** are in [`diagrams/`](./diagrams/) — insert those directly into Word/PowerPoint.

You can also copy any Mermaid block below into [https://mermaid.live](https://mermaid.live) to re-export.

---

## 1. ER Diagram

![ER Diagram](./diagrams/01_er_diagram.png)

```mermaid
erDiagram
  users ||--o{ orders : places
  users ||--o{ prescriptions : uploads
  users ||--o{ cart_items : has
  users ||--o{ notifications : receives
  users ||--o{ reviews : writes
  categories ||--o{ medicines : groups
  medicines ||--o{ cart_items : in_cart
  medicines ||--o{ order_items : ordered
  medicines ||--o{ reviews : rated
  medicines ||--o{ prescription_matches : matched
  medicines ||--o{ store_stocks : stocked
  stores ||--o{ store_stocks : holds
  stores ||--o{ orders : pickup_branch
  orders ||--|{ order_items : contains
  prescriptions ||--o{ prescription_matches : detects
```

---

## 2. Use Case Diagram

![Use Case Diagram](./diagrams/02_use_case.png)

```mermaid
flowchart TB
  C((Customer))
  A((Admin))
  G((Guest))

  subgraph System["MediSmart"]
    direction TB
    U1[Register / Login]
    U2[Browse Medicines]
    U3[Manage Cart]
    U4[Upload Prescription]
    U5[Checkout Order]
    U6[Track Order / Pickup Code]
    U7[Cancel Order]
    U8[Write Review]
    A1[CRUD Medicines]
    A2[Inventory and Expiry]
    A3[3D Inventory Views]
    A4[Review Prescriptions]
    A5[Manage Orders]
    A6[Verify Pickup Code]
    A7[Manage Stores and Racks]
    A8[Coupons and Reports]
    A9[Backup Database]
  end

  G --- U2
  C --- U1 & U2 & U3 & U4 & U5 & U6 & U7 & U8
  A --- A1 & A2 & A3 & A4 & A5 & A6 & A7 & A8 & A9
```

---

## 3. DFD Level 0 — Context

![DFD Level 0](./diagrams/03_dfd_level0_context.png)

```mermaid
flowchart LR
  C([Customer])
  A([Admin])
  AI([AI / OCR])
  SYS[[MediSmart System]]

  C -- orders, Rx, queries --> SYS
  SYS -- status, codes, alerts --> C
  A -- manage, verify --> SYS
  SYS -- reports, queues --> A
  SYS -- image --> AI
  AI -- matches --> SYS
```

---

## 4. DFD Level 1

![DFD Level 1](./diagrams/04_dfd_level1.png)

```mermaid
flowchart TB
  C([Customer])
  A([Admin])

  P1[1 Auth]
  P2[2 Catalog]
  P3[3 Cart]
  P4[4 Prescription + AI]
  P5[5 Order Processing]
  P6[6 Inventory and Stores]
  P7[7 Order Admin / Pickup]
  P8[8 Notifications]

  D1[(Users)]
  D2[(Medicines)]
  D3[(Cart)]
  D4[(Prescriptions)]
  D5[(Orders)]
  D6[(Stores)]
  D7[(Notifications)]

  C --> P1 & P2 & P3 & P4 & P5
  A --> P4 & P6 & P7
  P1 --- D1
  P2 --- D2
  P3 --- D3 & D2
  P4 --- D4 & D2
  P5 --- D5 & D2 & D3 & D6
  P6 --- D2 & D6
  P7 --- D5
  P5 --> P8
  P7 --> P8
  P8 --- D7
```

---

## 5. System Architecture

![Architecture](./diagrams/05_architecture.png)

```mermaid
flowchart TB
  Browser[Browser UI] --> Flask[Flask App]
  Flask --> Auth[Auth]
  Flask --> User[User Module]
  Flask --> Admin[Admin Module]
  Flask --> AI[AI Prescription Reader]
  Auth & User & Admin --> ORM[SQLAlchemy]
  ORM --> SQLite[(SQLite DB)]
  User & Admin --> Files[Upload Folder]
  AI --> Gemini[Gemini API optional]
  AI --> Tess[Tesseract]
```

---

## 6. Activity — Checkout Flow

![Checkout Activity](./diagrams/06_checkout_activity.png)

```mermaid
flowchart TD
  Start([Start Checkout]) --> V{Cart valid?}
  V -- No --> Fix[Fix stock / Rx issues]
  Fix --> Start
  V -- Yes --> F{Fulfillment}
  F -- Delivery --> Addr[Enter address]
  F -- Pickup --> Store[Select store with stock]
  Addr --> Pay
  Store --> Pay{Payment}
  Pay -- COD --> Place
  Pay -- Card demo --> Card[Enter fake card] --> Place[Create order]
  Place --> DecStock[Decrement stock]
  DecStock --> Code{Pickup?}
  Code -- Yes --> Gen[Generate 6-digit code]
  Code -- No --> Done
  Gen --> Done([Show order details])
```

---

## 7. Sequence — Store Pickup Collection

![Pickup Sequence](./diagrams/07_pickup_sequence.png)

```mermaid
sequenceDiagram
  actor Customer
  participant App
  actor Pharmacist

  Customer->>App: Place pickup order
  App-->>Customer: Show pickup_code
  Customer->>Pharmacist: Visit store + show code
  Pharmacist->>App: Enter code Verify Pickup
  alt Code correct
    App-->>Pharmacist: Order marked delivered
    App-->>Customer: Notification picked up
  else Code wrong
    App-->>Pharmacist: Reject — not released
  end
```

---

## 8. Class-style Module Map (logical)

![Class Diagram](./diagrams/11_class_diagram.png)

```mermaid
classDiagram
  class User {
    +id
    +email
    +role
    +loyalty_points
  }
  class Medicine {
    +name
    +price
    +stock
    +requires_prescription
  }
  class Order {
    +total
    +status
    +fulfillment_type
    +pickup_code
  }
  class Store {
    +name
    +address
    +is_active
  }
  class StoreStock {
    +stock
    +rack_location
  }
  class Prescription {
    +status
    +ocr_text
    +authenticity_score
  }
  User "1" --> "*" Order
  User "1" --> "*" Prescription
  Order "*" --> "1" Store : optional
  Store "1" --> "*" StoreStock
  Medicine "1" --> "*" StoreStock
  Order "1" --> "*" OrderItem
  Medicine "1" --> "*" OrderItem
```

---

## Suggested slide order for presentation

1. Title + objectives  
2. Architecture diagram (#5)  
3. Use case diagram (#2)  
4. ER diagram (#1)  
5. DFD Level 0 (#3) + Level 1 (#4)  
6. Checkout activity (#6)  
7. Pickup sequence (#7)  
8. Live demo of Admin Stores + 3D Inventory  

Full narrative text: [PROJECT_DOCUMENTATION.md](./PROJECT_DOCUMENTATION.md)  
Column dictionary: [DATABASE_SCHEMA.md](./DATABASE_SCHEMA.md)
