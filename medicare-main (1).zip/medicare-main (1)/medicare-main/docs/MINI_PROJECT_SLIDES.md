# MediSmart — Mini Project Slide Contents

**Document purpose:** Fill every section required in *MINI PROJECT SLIDE CONTENTS* for college submission / viva / PPT.  
**Project:** MediSmart — Smart Online Pharmacy & AI Prescription System (Kerala / INR)  
**Suggested use:** Copy each numbered section into one PowerPoint slide (or 2 slides if content is long).  
**Diagram PNGs:** `docs/diagrams/*.png`

---

## SLIDE 1 — Title Slide

**Title:** MediSmart: Smart Online Pharmacy Management System with AI-Based Prescription Reader  

**Subtitle:** A Web Application for Medicine Ordering, Inventory Control & Pharmacist Verification  

**Domain:** E-Pharmacy / Healthcare IT  

**Submitted by:**  
- [Student Name 1]  
- [Student Name 2]  
- [Student Name 3]  
- [Student Name 4]  

**Guided by:** [Guide / Faculty Name]  

**Department / College:** [Your College Name]  
**Year:** 2025–2026  

---

## SLIDE 2 — Introduction (bullets)

- MediSmart is a **web-based online pharmacy** built for a **Kerala retail pharmacy** context (prices in **INR ₹**).
- Customers can **browse medicines**, manage a **cart**, apply **coupons / loyalty points**, and place **home delivery** or **store pickup** orders.
- Users can **upload prescription images**; an **AI engine** (Gemini / OCR / HTR) reads medicine names and suggests catalog matches.
- A **pharmacist/admin** reviews unclear prescriptions (**approve / reject / needs info**) — same real-world pharmacy practice.
- Admin manages **medicines, stock, expiry, multi-branch stores, rack locations, orders, coupons, reports**, and **DB backup**.
- Extra demo features: **3D Inventory** and **3D Expiry Timeline** (Three.js) for client attraction.
- Built with **Flask + SQLite + Bootstrap**, with Windows installer (`install.bat`) and optional Docker.

---

## SLIDE 3 — Abstract (bullets)

- **Problem:** Manual pharmacy ordering and messy handwritten prescriptions cause delays, stock errors, and verification difficulty.
- **Solution:** MediSmart digitizes catalog, cart, checkout, inventory, multi-store pickup, and AI-assisted prescription reading with pharmacist confirmation.
- **Method:** Flask MVC web app; SQLite database; AI cascade (Gemini → TrOCR → Tesseract); business rules for delivery charge, Rx gating, pickup codes, and stock.
- **Key results:** End-to-end order flow, prescription review workflow, store/rack smart search, demo card payment, backup/restore, and college-ready design documentation.
- **Conclusion:** A practical mini-project prototype suitable for academic demo and future real-pharmacy extension.

---

## SLIDE 4 — Problem Definition (one sentence)

**There is no unified, low-cost web system that combines online medicine ordering (INR delivery/pickup), multi-branch stock with rack locations, and AI-assisted reading of messy handwritten prescriptions with mandatory pharmacist verification for a Kerala pharmacy setting.**

---

## SLIDE 5 — Literature Survey (table)

| TITLE & YEAR | AUTHOR & PUBLICATION | ALGORITHM USED | FEATURE EXTRACTED / METHODOLOGY | PERFORMANCE METRIC | RESULT / FINDINGS |
|---|---|---|---|---|---|
| Handwritten Medical Prescription Recognition (2021) | Various / IEEE & journal surveys on HTR for Rx | CNN / CRNN / Transformer OCR | Character & word recognition from Rx images | Character Error Rate (CER), Word Accuracy | Local OCR alone struggles on cursive doctor handwriting; needs domain dictionaries |
| Document Understanding with Vision-Language Models (2023–2025) | Google / multimodal LLM papers (Gemini family) | Multimodal LLM (vision + text) | Medicine name extraction from scanned documents | Extraction F1 / human review agreement | VLMs outperform classic OCR on messy layouts when guided by structured prompts |
| Online Pharmacy Adoption & UX Studies (2019–2023) | Healthcare informatics / e-commerce papers | Survey & system design analysis | Trust, Rx verification, delivery SLA | User satisfaction, conversion | Users expect pharmacist verification and clear delivery/pickup options |
| Inventory Visualization in Retail Systems (2020) | HCI / visualization workshops | 3D scene graphs / WebGL | Stock status color mapping | Usability / demo engagement | Interactive 3D views improve stakeholder understanding vs tables alone |
| Fuzzy String Matching for Drug Name Normalization (2018–2022) | Biomedical NLP papers | Edit distance / SequenceMatcher / phonetic | Map OCR text → drug catalog names | Match precision/recall | Fuzzy matching recovers near-miss spellings after OCR noise |
| Commercial e-Pharmacies (1mg, PharmEasy, NetMeds) — product analysis | Industry platforms (related work) | Rule engines + human pharmacist review | Rx upload, COD/online pay, delivery | Operational KPI (SLA, return rate) | Pharmacist review remains mandatory; AI assists but does not replace verification |

> **Note for viva:** MediSmart uses **Gemini (preferred) + Tesseract + optional TrOCR**, then **fuzzy match** to `medicines`, with **admin pharmacist actions** — combining literature findings (VLM accuracy + mandatory human review).

---

## SLIDE 6 — Design Diagrams

Insert these PNGs from `docs/diagrams/`:

| Required diagram | File to insert |
|------------------|----------------|
| **DFD** | `03_dfd_level0_context.png`, `04_dfd_level1.png`, `10_dfd_level2_checkout.png` |
| **Use case diagram** | `02_use_case.png` |
| **Class diagram** | `11_class_diagram.png` |
| **State diagram** | `08_order_lifecycle.png` |
| **Activity diagram** | `06_checkout_activity.png` |
| **Sequence diagram** | `07_pickup_sequence.png`, `09_prescription_sequence.png` |
| *(Bonus)* ER diagram | `01_er_diagram.png` |
| *(Bonus)* Architecture | `05_architecture.png` |

### DFD (brief labels for slide notes)
- **Level 0:** Customer, Admin, AI ↔ MediSmart System  
- **Level 1:** Auth, Catalog, Cart, Prescription+AI, Order, Inventory/Stores, Admin Order/Pickup, Notifications + data stores  
- **Level 2 (checkout):** Validate cart → totals → fulfillment → payment → persist → pickup code  

### Use cases (actors)
- **Customer:** register, browse, cart, upload Rx, checkout, track/pickup code, cancel, review  
- **Admin:** medicines, inventory/expiry, 3D views, Rx review, orders, verify pickup, stores/racks, coupons/reports, backup  

---

## SLIDE 7 — Module Description

| Module | Description |
|--------|-------------|
| **Public Module** | Landing/home, about, contact; guest medicine browsing |
| **Auth Module** | Register, login, logout; input validation (strip special characters); role-based redirect (user/admin) |
| **User Module** | Dashboard, medicines, cart, coupons, loyalty redeem, checkout (delivery/pickup), orders, cancel, notifications, profile, reviews |
| **Prescription / AI Module** | Upload Rx image; Gemini/OCR/HTR analysis; store matches & authenticity score; re-analyze; add matches to cart |
| **Admin Module** | Medicines CRUD, categories, inventory, expiry tracker, prescriptions review, orders, users, coupons, reviews, reports, settings |
| **Store & Rack Module** | Multi-branch stores; per-store stock + rack location; smart search at checkout & medicine details; pickup code verify |
| **3D Visualization Module** | Three.js 3D inventory bars & expiry timeline (bonus/external feature) |
| **Backup Module** | Export/import DB + uploads (`.zip`) via admin UI or `export_db.bat` / `import_db.bat` |
| **Assistant Module** | In-app chatbot answers FAQs (delivery rules, points, etc.) |

---

## SLIDE 8 — Software & Hardware Requirements

### Software requirements
| Item | Specification |
|------|----------------|
| OS | Windows 10/11 (also Linux/macOS) |
| Language | Python 3.10 – 3.12 |
| Framework | Flask 3, Flask-SQLAlchemy, Flask-Login, Flask-Bcrypt |
| Database | SQLite (default); optional PostgreSQL via `DATABASE_URL` |
| Frontend | HTML5, Jinja2, Bootstrap 5, Bootstrap Icons, JavaScript |
| 3D | Three.js |
| AI (optional) | Google Gemini API key; Tesseract OCR; optional Torch/TrOCR |
| Tools | Git, VS Code/Cursor, DB Browser for SQLite (optional) |
| Deploy helpers | `install.bat`, `run.bat`, Docker (optional) |

### Hardware requirements (minimum for demo)
| Item | Specification |
|------|----------------|
| Processor | Dual-core 2.0 GHz or higher |
| RAM | 4 GB minimum (8 GB recommended if using local TrOCR) |
| Storage | ~1 GB free (more if installing optional Torch/HTR) |
| Display | 1366×768 or higher |
| Network | Internet for Gemini AI & package install (offline mode works with reduced AI) |

---

## SLIDE 9 — Algorithm

### Algorithm 1: AI Prescription Analysis
```
INPUT: prescription_image, medicine_catalog
OUTPUT: ocr_text, matches[], authenticity_score

1. Preprocess image (load / normalize)
2. IF Gemini API key available THEN
      extract_medicines_via_Gemini(image) → candidates
   ELSE IF local HTR (TrOCR) available THEN
      recognize_handwriting(image) → text
   ELSE
      run_Tesseract_OCR(image) → text
3. Merge candidate medicine strings
4. FOR each candidate:
      fuzzy_match against medicine_catalog
      IF confidence ≥ threshold THEN add to matches[]
5. Compute authenticity_score / label from signals
6. Save Prescription + PrescriptionMatch rows
7. RETURN results for pharmacist review
```

### Algorithm 2: Checkout & Stock Update
```
INPUT: user_cart, fulfillment_type, payment_method, store_id (optional)
OUTPUT: order_id [, pickup_code]

1. Validate cart (stock, expiry, approved Rx if needed)
2. Compute subtotal, coupon discount, points discount
3. IF fulfillment = delivery AND subtotal < 500 THEN delivery_charge = 40 ELSE 0
4. IF payment = Card THEN accept demo card; store card_last4 only
5. Create Order + OrderItems
6. Decrement Medicine.stock for each item
7. IF pickup THEN
      decrement StoreStock for store_id
      generate 6-digit pickup_code
8. Update loyalty points; clear cart
9. Notify user
10. RETURN order details
```

### Algorithm 3: Pickup Verification
```
INPUT: order_id, entered_code
1. IF order.fulfillment ≠ pickup THEN reject
2. IF entered_code == order.pickup_code THEN
      status ← delivered; picked_up_at ← now; notify user
   ELSE reject (do not release)
```

---

## SLIDE 10 — Architecture

![Architecture](./diagrams/05_architecture.png)

**Layers (short):**
1. **Presentation:** Browser UI (Bootstrap + JS validation + Three.js pages)  
2. **Application:** Flask blueprints — Public / Auth / User / Admin / AI helpers  
3. **Data:** SQLAlchemy models → SQLite file `medismart.db` + `static/uploads`  
4. **External:** Optional Gemini API for handwriting; Tesseract locally  

**Client–Server:** Browser ↔ HTTP ↔ Flask server (port 5000) ↔ Database/Files  

---

## SLIDE 11 — Analysis on Results

| Area | Observation / Result |
|------|----------------------|
| Functional completeness | Core flows work: auth, catalog, cart, checkout, Rx upload, admin review, pickup verify, stores/racks |
| AI prescription reading | Gemini (when keyed) reads messy handwriting better than Tesseract alone; fuzzy match links to catalog |
| Business rules | Delivery free ≥ ₹500; pickup free; Rx medicines blocked without approved prescription |
| Stock integrity | Oversell prevented; cancel restores global + store stock and loyalty/coupon effects |
| Security (demo level) | Passwords hashed (bcrypt); only card last-4 stored; input validation strips unsafe special chars |
| Usability | Animated form validation; pickup code clearly shown; admin verify UI |
| Documentation | ER, DFD, use-case, activity, sequence, state, class diagrams + PNG pack for faculty |
| Performance (demo) | SQLite adequate for college dataset; page render tests passed for major routes |

**Limitations (honest for viva):** Not a real payment gateway; AI accuracy depends on image quality/API; SQLite not for large multi-tenant production without migration.

---

## SLIDE 12 — Comparison with Existing (by analysis)

| Feature | Traditional Pharmacy Counter | 1mg / PharmEasy (commercial) | **MediSmart (this project)** |
|---------|------------------------------|------------------------------|------------------------------|
| Online catalog & cart | No | Yes | **Yes** |
| INR + Kerala delivery rules | Counter only | Yes (proprietary) | **Yes (configurable ₹40 / free ≥₹500)** |
| Handwritten Rx AI assist | Manual reading | Proprietary AI + pharmacist | **Gemini/OCR + pharmacist review** |
| Pharmacist approve/reject/needs_info | Verbal | Yes | **Yes** |
| Multi-branch rack / smart pickup stock | Manual ledgers | Enterprise WMS | **Yes (Store + StoreStock + rack)** |
| Pickup secret code | Token / call | App OTP / code | **Yes (6-digit verify)** |
| Loyalty + coupons | Rare / paper | Yes | **Yes** |
| 3D inventory demo | No | Rare | **Yes (bonus)** |
| Cost / academic openness | — | Closed / paid | **Open college prototype + docs** |
| Real payment gateway | Cash/UPI counter | Yes | **Demo card only (college scope)** |
| Source code for study | No | No | **Yes** |

**Analysis:** MediSmart is not a commercial replacement for PharmEasy, but as a **mini project** it covers the academic requirement of full SDLC artifacts plus distinctive features (rack-aware pickup, AI Rx + needs_info workflow, 3D views, portable backup/installer) that typical student pharmacy projects omit.

---

## SLIDE 13 — Conclusion

- MediSmart successfully implements an **end-to-end online pharmacy prototype** with ordering, inventory, stores, and AI-assisted prescriptions.
- The system enforces **practical pharmacy rules** (Rx approval, delivery charges, pickup verification, stock safety).
- Design documentation (**DFD, use case, class, state, activity, sequence, ER**) supports academic evaluation.
- The project demonstrates that a **Flask + SQLite** stack is sufficient for a complete mini-project demo with clear upgrade paths.

---

## SLIDE 14 — Future Scope

- Integrate a **real payment gateway** (Razorpay / UPI).  
- Replace SQLite with **PostgreSQL** and deploy on cloud (Render/AWS).  
- Add **SMS/WhatsApp** pickup-code notifications.  
- Train/fine-tune a **domain OCR model** on Malayalam + English Rx samples.  
- Mobile app (Flutter) consuming the same APIs.  
- Role split: dedicated **pharmacist vs super-admin**.  
- Analytics dashboard: expiry risk prediction, demand forecasting.  
- DigiLocker / e-prescription API integration (India).

---

## SLIDE 15 — References (IEEE format)

[1] A. Dosovitskiy *et al.*, “An Image is Worth 16×16 Words: Transformers for Image Recognition at Scale,” in *Proc. ICLR*, 2021.  

[2] Google DeepMind / Google AI, “Gemini Models — Multimodal Understanding,” technical documentation, 2024–2025. [Online]. Available: https://ai.google.dev/  

[3] R. Smith, “An Overview of the Tesseract OCR Engine,” in *Proc. ICDAR*, 2007.  

[4] Li *et al.*, “TrOCR: Transformer-based Optical Character Recognition with Pre-trained Models,” *arXiv:2109.10282*, 2021.  

[5] G. A. Miller *et al.*, related work on biomedical named entity / drug name normalization surveys, *Briefings in Bioinformatics*, various years.  

[6] Flask Software Foundation, “Flask Documentation,” 2024. [Online]. Available: https://flask.palletsprojects.com/  

[7] SQLAlchemy Authors, “SQLAlchemy Documentation,” 2024. [Online]. Available: https://docs.sqlalchemy.org/  

[8] Bootstrap Team, “Bootstrap 5 Documentation,” 2024. [Online]. Available: https://getbootstrap.com/  

[9] mrdoob *et al.*, “Three.js — JavaScript 3D Library,” 2024. [Online]. Available: https://threejs.org/  

[10] Ministry of Health / CDSCO related guidelines on online sale of medicines (India) — policy context for pharmacist verification requirement.  

[11] Industry references: 1mg, PharmEasy, NetMeds — online pharmacy workflow observation for comparative analysis, 2024–2025.  

[12] MediSmart Project Source, “anandhx/medicare,” GitHub repository, 2026. [Online]. Available: https://github.com/anandhx/medicare  

> Replace [12] author names with your team names if required by your department format.

---

## SLIDE 16 — Thank You

**Thank You**  

**Questions Welcome**  

**MediSmart — Smart Pharmacy & AI Prescription System**  

Demo: `http://127.0.0.1:5000`  
Admin: `admin@medismart.com` / `admin123`  
User: `user@medismart.com` / `user123`  

---

## Appendix — Quick PPT build checklist

1. Create 16 slides matching headings above.  
2. Paste **bullet text** from Slides 2–3, 7–8, 11–14.  
3. Insert **PNG diagrams** on Slide 6 (and architecture on Slide 10).  
4. Paste **Literature table** (Slide 5) — landscape slide recommended.  
5. Paste **IEEE references** (Slide 15).  
6. Fill Title slide with your real names/college.  

Related docs: `PROJECT_DOCUMENTATION.md`, `DATABASE_SCHEMA.md`, `DIAGRAMS.md`.
