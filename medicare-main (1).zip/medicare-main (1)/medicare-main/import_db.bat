@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found - run install.bat first.
    pause
    exit /b 1
)

echo ============================================
echo   MediSmart - Import Database
echo ============================================
echo.
echo Tip: you can also just drag-and-drop a backup .zip onto this file
echo in Explorer instead of typing its path below.
echo.

set "ZIPFILE=%~1"
if "%ZIPFILE%"=="" (
    set /p ZIPFILE=Full path to the backup .zip file: 
)

if not exist "%ZIPFILE%" (
    echo.
    echo File not found: %ZIPFILE%
    pause
    exit /b 1
)

".venv\Scripts\python.exe" scripts\restore_data.py "%ZIPFILE%"
echo.
pause
