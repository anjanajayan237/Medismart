@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Virtual environment not found - run install.bat first.
    pause
    exit /b 1
)

echo ============================================
echo   MediSmart - Export Database
echo ============================================
echo.
".venv\Scripts\python.exe" scripts\backup_data.py
echo.
echo Copy that .zip to the new PC (USB drive, email, cloud, etc.) and
echo run import_db.bat there once MediSmart is installed.
echo.
pause
