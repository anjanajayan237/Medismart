@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo   MediSmart - Installer
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found on this PC.
    echo Install Python 3.10 - 3.12 from https://www.python.org/downloads/
    echo and tick "Add python.exe to PATH" during setup, then run this again.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/6] Creating virtual environment...
    python -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Could not create the virtual environment.
        pause
        exit /b 1
    )
) else (
    echo [1/6] Virtual environment already exists - skipping.
)

echo [2/6] Upgrading pip...
".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet

echo [3/6] Installing dependencies (fast path - core packages only)...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] pip install failed - check the messages above.
    pause
    exit /b 1
)

if not exist ".env" (
    echo [4/6] Creating .env from .env.example...
    copy ".env.example" ".env" >nul
) else (
    echo [4/6] .env already exists - skipping.
)

echo [5/6] Initializing database...
".venv\Scripts\python.exe" scripts\init_db.py
if errorlevel 1 (
    echo [ERROR] Database initialization failed - check the messages above.
    pause
    exit /b 1
)

echo [6/6] Checking Tesseract OCR (needed for local prescription reading)...
where tesseract >nul 2>nul
if errorlevel 1 (
    if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" (
        echo       Tesseract found in Program Files.
    ) else (
        echo       Tesseract NOT found.
        echo       After setup, run install_tesseract.bat OR Admin -^> System Check.
        where winget >nul 2>nul
        if not errorlevel 1 (
            echo       Attempting winget install of UB-Mannheim.TesseractOCR...
            winget install --id UB-Mannheim.TesseractOCR -e --accept-source-agreements --accept-package-agreements
        )
    )
) else (
    echo       Tesseract is on PATH - OK.
)

echo.
echo ============================================
echo   Install complete!
echo ============================================
echo.
echo   Start the app:        run.bat
echo   Default admin login:  admin@medismart.com / admin123
echo   Default user login:   user@medismart.com / user123
echo.
echo   Check dependencies:   login as admin -^> System Check
echo   Install Tesseract:    install_tesseract.bat  (if OCR still missing)
echo.
echo   Optional: paste a free Gemini API key into .env for the most
echo   accurate handwritten-prescription reading (see .env.example).
echo.
echo   Moving data from another install? Run: import_db.bat
echo   (Fully offline handwriting fallback? See requirements-htr-optional.txt)
echo.
pause
