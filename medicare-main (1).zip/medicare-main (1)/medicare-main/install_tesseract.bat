@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================
echo   MediSmart - Install Tesseract OCR
echo ============================================
echo.
echo Tesseract is a Windows program (not a pip package).
echo Without it, local prescription OCR cannot run.
echo Gemini AI still works using the built-in API key.
echo.

REM Already installed?
if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" goto :already
if exist "%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe" goto :already
where tesseract >nul 2>nul
if not errorlevel 1 goto :already

REM 1) Try winget
where winget >nul 2>nul
if not errorlevel 1 (
    echo [1/2] Trying winget install: UB-Mannheim.TesseractOCR ...
    winget install --id UB-Mannheim.TesseractOCR -e --accept-source-agreements --accept-package-agreements
    if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" goto :done
    if exist "%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe" goto :done
    where tesseract >nul 2>nul
    if not errorlevel 1 goto :done
    echo       winget did not complete — falling back to direct download.
)

REM 2) Direct download + run installer
set "INSTALLER=%TEMP%\tesseract-ocr-w64-setup-medismart.exe"
set "URL=https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-5.5.0.20241111.exe"

echo [2/2] Downloading Tesseract installer...
echo       %URL%
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { Invoke-WebRequest -Uri '%URL%' -OutFile '%INSTALLER%' -UseBasicParsing; exit 0 } catch { Write-Host $_; exit 1 }"
if errorlevel 1 (
    echo [ERROR] Download failed. Opening the manual download page...
    start "" "https://github.com/UB-Mannheim/tesseract/wiki"
    pause
    exit /b 1
)

echo.
echo Starting installer — accept defaults, then click Finish.
echo.
start /wait "" "%INSTALLER%"

if exist "%ProgramFiles%\Tesseract-OCR\tesseract.exe" goto :done
if exist "%ProgramFiles(x86)%\Tesseract-OCR\tesseract.exe" goto :done
where tesseract >nul 2>nul
if not errorlevel 1 goto :done

echo.
echo [WARN] Installer finished but tesseract.exe was not found.
echo Make sure you completed the setup wizard, then restart MediSmart.
pause
exit /b 1

:already
echo Tesseract is already installed on this PC.
goto :done

:done
echo.
echo ============================================
echo   Tesseract ready
echo ============================================
echo.
echo 1. Close the MediSmart Server window if it is running
echo 2. Double-click run.bat again
echo 3. Admin -^> System Check to verify status
echo.
pause
exit /b 0
