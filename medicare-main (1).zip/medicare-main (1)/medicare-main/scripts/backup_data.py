"""Export the live database + uploaded images into a single .zip.

Usage (from the project root, with the venv active):
    python scripts\\backup_data.py                  # auto-named file in backups\\
    python scripts\\backup_data.py backups\\mine.zip  # explicit output path

Also reachable from the browser: Admin -> Settings -> Download Backup.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app  # noqa: E402
from app.backup import create_backup_zip  # noqa: E402


def main():
    dest = sys.argv[1] if len(sys.argv) > 1 else None
    with app.app_context():
        path = create_backup_zip(app, dest)
    size_kb = os.path.getsize(path) / 1024
    print(f"\nBackup created: {path}  ({size_kb:.1f} KB)")
    print("Copy this .zip to the new PC and run import_db.bat there.")


if __name__ == "__main__":
    main()
