"""One-time DB setup, run by install.bat.

Simply importing `app` already triggers table creation + lightweight
migrations + starter data (see app/__init__.py's create_app) — this
script just does that import and prints a friendly confirmation so
install.bat has something concrete to show for it.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app  # noqa: E402
from app.models import User, Medicine, Store  # noqa: E402

with app.app_context():
    print(f"Database ready: {app.config['SQLALCHEMY_DATABASE_URI']}")
    print(f"  Users:     {User.query.count()}")
    print(f"  Medicines: {Medicine.query.count()}")
    print(f"  Stores:    {Store.query.count()}")
