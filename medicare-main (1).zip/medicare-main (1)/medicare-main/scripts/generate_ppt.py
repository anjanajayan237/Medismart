"""Generate MediSmart college mini-project PowerPoint (.pptx)."""
from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parents[1]
DIAG = ROOT / "docs" / "diagrams"
OUT = ROOT / "docs" / "MediSmart_Mini_Project.pptx"

# Teal medical theme
PRIMARY = RGBColor(13, 148, 136)
DARK = RGBColor(15, 23, 42)
MUTED = RGBColor(71, 85, 105)
WHITE = RGBColor(255, 255, 255)


def set_run(run, size=18, bold=False, color=DARK, font="Calibri"):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    run.font.name = font


def add_title_bar(slide, prs, title):
    shape = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), prs.slide_width, Inches(0.95)
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = PRIMARY
    shape.line.fill.background()
    tf = shape.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.LEFT
    run = p.add_run()
    run.text = "  " + title
    set_run(run, 24, True, WHITE, "Calibri")


def add_footer(slide, prs, page, total=26):
    box = slide.shapes.add_textbox(
        Inches(0.4), prs.slide_height - Inches(0.4), Inches(12), Inches(0.3)
    )
    tf = box.text_frame
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = f"MediSmart Mini Project  |  Page {page}/{total}"
    set_run(run, 10, False, MUTED)


def bullets(slide, items, left=0.5, top=1.2, width=12.3, height=5.5, size=17):
    box = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = box.text_frame
    tf.word_wrap = True
    for i, text in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.level = 0
        p.space_after = Pt(8)
        run = p.add_run()
        run.text = "•  " + text
        set_run(run, size, False, DARK)


def body_text(slide, text, left=0.5, top=1.3, width=12.3, height=4, size=18, bold=False):
    box = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = text
    set_run(run, size, bold, DARK)


def add_picture_fit(slide, path, left, top, max_w, max_h):
    path = Path(path)
    if not path.exists():
        body_text(slide, f"[Missing image: {path.name}]", left, top, max_w, 0.5, 14)
        return
    from PIL import Image
    with Image.open(path) as im:
        w, h = im.size
    aspect = w / float(h) if h else 1.0
    width = max_w
    height = width / aspect
    if height > max_h:
        height = max_h
        width = height * aspect
    # center horizontally in available area
    x = left + (max_w - width) / 2.0
    slide.shapes.add_picture(str(path), Inches(x), Inches(top), width=Inches(width), height=Inches(height))


def add_picture_fit_slide(slide, path, prs):
    add_picture_fit(slide, path, 0.8, 1.1, 11.7, 5.9)


def new_content_slide(prs, title, page, total):
    slide = prs.slides.add_slide(prs.slide_layouts[6])  # blank
    add_title_bar(slide, prs, title)
    add_footer(slide, prs, page, total)
    return slide


def add_table(slide, headers, rows, left=0.3, top=1.15, width=12.7, height=5.2):
    cols = len(headers)
    table_shape = slide.shapes.add_table(len(rows) + 1, cols, Inches(left), Inches(top), Inches(width), Inches(height))
    table = table_shape.table
    for c, h in enumerate(headers):
        cell = table.cell(0, c)
        cell.text = h
        for p in cell.text_frame.paragraphs:
            for r in p.runs:
                set_run(r, 9, True, WHITE)
        cell.fill.solid()
        cell.fill.fore_color.rgb = PRIMARY
    for r_i, row in enumerate(rows):
        for c_i, val in enumerate(row):
            cell = table.cell(r_i + 1, c_i)
            cell.text = val
            for p in cell.text_frame.paragraphs:
                for run in p.runs:
                    set_run(run, 8, False, DARK)


def build():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    total = 26
    page = 0

    def next_page():
        nonlocal page
        page += 1
        return page

    # 1 Title
    p = next_page()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = RGBColor(15, 23, 42)
    bg.line.fill.background()
    accent = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, Inches(2.2), prs.slide_width, Inches(3.1))
    accent.fill.solid()
    accent.fill.fore_color.rgb = PRIMARY
    accent.line.fill.background()

    box = slide.shapes.add_textbox(Inches(0.8), Inches(2.4), Inches(11.5), Inches(2.6))
    tf = box.text_frame
    tf.word_wrap = True
    p0 = tf.paragraphs[0]
    p0.alignment = PP_ALIGN.CENTER
    r = p0.add_run()
    r.text = "MediSmart"
    set_run(r, 44, True, WHITE)

    p1 = tf.add_paragraph()
    p1.alignment = PP_ALIGN.CENTER
    r = p1.add_run()
    r.text = "Smart Online Pharmacy Management System\nwith AI-Based Prescription Reader"
    set_run(r, 22, True, WHITE)

    box2 = slide.shapes.add_textbox(Inches(0.8), Inches(5.5), Inches(11.5), Inches(1.5))
    tf2 = box2.text_frame
    tf2.word_wrap = True
    for line in [
        "Mini Project Presentation  |  E-Pharmacy / Healthcare IT",
        "Submitted by: [Student Name 1], [Student Name 2], [Student Name 3], [Student Name 4]",
        "Guided by: [Faculty Name]  |  [College Name]  |  2025–2026",
    ]:
        para = tf2.paragraphs[0] if line.startswith("Mini") else tf2.add_paragraph()
        para.alignment = PP_ALIGN.CENTER
        run = para.add_run()
        run.text = line
        set_run(run, 14, False, RGBColor(203, 213, 225))

    # 2 Introduction
    s = new_content_slide(prs, "Introduction", next_page(), total)
    bullets(s, [
        "Web-based online pharmacy for Kerala retail context (prices in INR ₹).",
        "Browse medicines, cart, coupons, loyalty points, home delivery or store pickup.",
        "Upload prescription images; AI (Gemini / OCR / HTR) extracts medicine names.",
        "Pharmacist/admin reviews prescriptions: approve / reject / needs info.",
        "Admin manages stock, expiry, multi-branch stores, racks, orders, reports, backup.",
        "Bonus: 3D Inventory and 3D Expiry Timeline (Three.js).",
        "Stack: Flask + SQLite + Bootstrap; install.bat / optional Docker.",
    ])

    # 3 Abstract
    s = new_content_slide(prs, "Abstract", next_page(), total)
    bullets(s, [
        "Problem: Manual ordering and messy handwritten prescriptions cause delays and errors.",
        "Solution: Digitize catalog, checkout, inventory, multi-store pickup, AI Rx + pharmacist confirmation.",
        "Method: Flask MVC; SQLite; AI cascade Gemini → TrOCR → Tesseract; delivery/Rx/pickup rules.",
        "Results: End-to-end orders, Rx review, rack smart search, demo card pay, backup, design docs.",
        "Conclusion: Practical mini-project prototype ready for academic demo and future extension.",
    ])

    # 4 Problem
    s = new_content_slide(prs, "Problem Definition", next_page(), total)
    body_text(
        s,
        "There is no unified, low-cost web system that combines online medicine ordering "
        "(INR delivery/pickup), multi-branch stock with rack locations, and AI-assisted reading "
        "of messy handwritten prescriptions with mandatory pharmacist verification for a "
        "Kerala pharmacy setting.",
        top=2.5,
        height=3,
        size=22,
        bold=True,
    )

    # 5 Literature (table)
    s = new_content_slide(prs, "Literature Survey", next_page(), total)
    headers = ["TITLE & YEAR", "AUTHOR & PUBLICATION", "ALGORITHM", "METHODOLOGY", "METRIC", "RESULT"]
    rows = [
        ["Handwritten Rx Recognition (2021)", "IEEE/journal HTR surveys", "CNN/CRNN/Transformer OCR", "Char/word from Rx images", "CER, Word Acc.", "Local OCR weak on cursive writing"],
        ["Vision-Language Docs (2023–25)", "Google Gemini / VLM papers", "Multimodal LLM", "Medicine extraction from scans", "F1 / review agree", "VLMs beat classic OCR on messy layouts"],
        ["Online Pharmacy UX (2019–23)", "Health informatics papers", "Survey & design analysis", "Trust, Rx verify, delivery", "Satisfaction", "Users expect pharmacist verification"],
        ["Inventory Visualization (2020)", "HCI / viz workshops", "WebGL / 3D graphs", "Stock color mapping", "Usability", "3D improves stakeholder understanding"],
        ["Drug Name Fuzzy Match (2018–22)", "Biomedical NLP", "Edit distance / SequenceMatcher", "OCR text → catalog names", "Precision/Recall", "Recovers near-miss spellings"],
        ["1mg / PharmEasy / NetMeds", "Industry platforms", "Rules + pharmacist review", "Rx upload, pay, delivery", "Operational KPI", "AI assists; human review mandatory"],
    ]
    add_table(s, headers, rows)

    # 6 Design diagrams section title
    s = new_content_slide(prs, "Design Diagrams — Overview", next_page(), total)
    bullets(s, [
        "DFD (Level 0, Level 1, Level 2 checkout)",
        "Use Case Diagram",
        "Class Diagram",
        "State Diagram (Order lifecycle)",
        "Activity Diagram (Checkout)",
        "Sequence Diagrams (Pickup + Prescription)",
        "Bonus: ER Diagram & System Architecture",
    ], size=20)

    # Diagram slides
    diagram_slides = [
        ("DFD Level 0 — Context Diagram", "03_dfd_level0_context.png"),
        ("DFD Level 1", "04_dfd_level1.png"),
        ("DFD Level 2 — Checkout", "10_dfd_level2_checkout.png"),
        ("Use Case Diagram", "02_use_case.png"),
        ("Class Diagram", "11_class_diagram.png"),
        ("State Diagram — Order Lifecycle", "08_order_lifecycle.png"),
        ("Activity Diagram — Checkout", "06_checkout_activity.png"),
        ("Sequence Diagram — Store Pickup", "07_pickup_sequence.png"),
        ("Sequence Diagram — Prescription AI", "09_prescription_sequence.png"),
        ("ER Diagram (Bonus)", "01_er_diagram.png"),
        ("System Architecture", "05_architecture.png"),
    ]
    for title, fname in diagram_slides:
        s = new_content_slide(prs, title, next_page(), total)
        add_picture_fit(s, DIAG / fname, 0.8, 1.1, 11.7, 5.9)

    # Module description
    s = new_content_slide(prs, "Module Description", next_page(), total)
    bullets(s, [
        "Public: Home, about, contact, guest browsing.",
        "Auth: Register/login with validation; role-based access (user/admin).",
        "User: Cart, coupons, loyalty, checkout, orders, reviews, notifications.",
        "AI Prescription: Upload image → Gemini/OCR/HTR → fuzzy match → pharmacist review.",
        "Admin: Medicines, inventory, expiry, orders, coupons, reports, users.",
        "Store & Rack: Branches, per-store stock, rack location, pickup code verify.",
        "3D Module: Three.js inventory & expiry timeline (bonus).",
        "Backup: Export/import DB + uploads as zip.",
    ], size=16)

    # Software & Hardware
    s = new_content_slide(prs, "Software & Hardware Requirements", next_page(), total)
    bullets(s, [
        "Software: Windows 10/11; Python 3.10–3.12; Flask, SQLAlchemy, Flask-Login, Bcrypt.",
        "DB: SQLite (default); Frontend: Bootstrap 5, Jinja2, JS; 3D: Three.js.",
        "AI optional: Gemini API, Tesseract, optional Torch/TrOCR.",
        "Hardware min: Dual-core CPU, 4 GB RAM (8 GB if local HTR), ~1 GB disk.",
        "Network: Internet for install & Gemini; offline demo possible with reduced AI.",
    ])

    # Algorithm
    s = new_content_slide(prs, "Algorithm (Summary)", next_page(), total)
    bullets(s, [
        "AI Rx: Preprocess → Gemini or TrOCR or Tesseract → fuzzy match catalog → save matches → pharmacist review.",
        "Checkout: Validate stock/expiry/Rx → totals (coupon/points/delivery) → payment (COD/demo card) → save order → decrement stock → pickup code if needed.",
        "Pickup verify: Compare entered code with order.pickup_code → delivered + notify, else reject.",
        "Delivery rule: charge ₹40 if delivery and subtotal < ₹500; else free (pickup always free).",
    ], size=16)

    # Analysis
    s = new_content_slide(prs, "Analysis on Results", next_page(), total)
    bullets(s, [
        "Core flows verified: auth, catalog, cart, checkout, Rx upload/review, pickup verify, stores/racks.",
        "Gemini improves messy handwriting vs Tesseract alone; fuzzy match links to catalog.",
        "Business rules enforced: free delivery ≥ ₹500; Rx gated until approved; no oversell.",
        "Cancel restores stock + loyalty/coupon; passwords hashed; only card last-4 stored.",
        "Limitation: demo payment only; AI depends on image/API; SQLite for college scale.",
    ])

    # Comparison
    s = new_content_slide(prs, "Comparison with Existing Systems", next_page(), total)
    headers = ["Feature", "Counter Pharmacy", "1mg / PharmEasy", "MediSmart"]
    rows = [
        ["Online catalog & cart", "No", "Yes", "Yes"],
        ["INR delivery rules", "Counter only", "Yes", "Yes (₹40 / free ≥₹500)"],
        ["Handwritten Rx AI", "Manual", "Proprietary + pharmacist", "Gemini/OCR + pharmacist"],
        ["Multi-branch rack pickup", "Manual ledger", "Enterprise WMS", "Yes (StoreStock + rack)"],
        ["Pickup secret code", "Token/call", "App OTP/code", "Yes (6-digit verify)"],
        ["3D inventory demo", "No", "Rare", "Yes (bonus)"],
        ["Real payment gateway", "Cash/UPI", "Yes", "Demo card (college scope)"],
        ["Open source for study", "No", "No", "Yes"],
    ]
    add_table(s, headers, rows, height=5.0)

    # Conclusion
    s = new_content_slide(prs, "Conclusion", next_page(), total)
    bullets(s, [
        "End-to-end online pharmacy prototype with ordering, inventory, stores, AI prescriptions.",
        "Enforces practical pharmacy rules: Rx approval, delivery charges, pickup verification, stock safety.",
        "Full academic design set: DFD, use case, class, state, activity, sequence, ER.",
        "Flask + SQLite is sufficient for mini-project demo with clear upgrade paths.",
    ])

    # Future scope
    s = new_content_slide(prs, "Future Scope", next_page(), total)
    bullets(s, [
        "Real payment gateway (Razorpay / UPI).",
        "PostgreSQL + cloud deployment.",
        "SMS/WhatsApp pickup-code alerts.",
        "Domain OCR fine-tuned on Malayalam + English Rx samples.",
        "Mobile app (Flutter) on same APIs.",
        "Demand forecasting & DigiLocker / e-prescription integration.",
    ])

    # References
    s = new_content_slide(prs, "References (IEEE Format)", next_page(), total)
    bullets(s, [
        "[1] A. Dosovitskiy et al., “An Image is Worth 16×16 Words…,” ICLR, 2021.",
        "[2] Google AI, “Gemini Models — Multimodal Understanding,” 2024–2025. https://ai.google.dev/",
        "[3] R. Smith, “An Overview of the Tesseract OCR Engine,” ICDAR, 2007.",
        "[4] Li et al., “TrOCR: Transformer-based OCR…,” arXiv:2109.10282, 2021.",
        "[5] Flask Documentation, 2024. https://flask.palletsprojects.com/",
        "[6] SQLAlchemy Documentation, 2024. https://docs.sqlalchemy.org/",
        "[7] Bootstrap 5 Documentation, 2024. https://getbootstrap.com/",
        "[8] Three.js, 2024. https://threejs.org/",
        "[9] Industry: 1mg, PharmEasy, NetMeds — comparative workflow analysis, 2024–25.",
        "[10] MediSmart source: https://github.com/anandhx/medicare",
    ], size=13)

    # Thank you
    p = next_page()
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = PRIMARY
    bg.line.fill.background()
    box = slide.shapes.add_textbox(Inches(1), Inches(2.3), Inches(11), Inches(3))
    tf = box.text_frame
    tf.word_wrap = True
    p0 = tf.paragraphs[0]
    p0.alignment = PP_ALIGN.CENTER
    r = p0.add_run()
    r.text = "Thank You"
    set_run(r, 54, True, WHITE)
    p1 = tf.add_paragraph()
    p1.alignment = PP_ALIGN.CENTER
    r = p1.add_run()
    r.text = "\nQuestions Welcome\n\nDemo: http://127.0.0.1:5000\nAdmin: admin@medismart.com / admin123\nUser: user@medismart.com / user123"
    set_run(r, 18, False, WHITE)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(OUT))
    print(f"Saved {OUT} ({OUT.stat().st_size} bytes) with {len(prs.slides)} slides")


if __name__ == "__main__":
    build()
