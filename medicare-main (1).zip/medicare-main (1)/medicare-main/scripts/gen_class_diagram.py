import os, base64, urllib.request, io
from PIL import Image

src = r"""classDiagram
  class User {
    +int id
    +string name
    +string email
    +string role
    +int loyalty_points
    +set_password()
    +check_password()
  }
  class Medicine {
    +int id
    +string name
    +float price
    +int stock
    +bool requires_prescription
    +date expiry_date
  }
  class Category {
    +int id
    +string name
  }
  class Order {
    +int id
    +float total
    +string status
    +string fulfillment_type
    +string pickup_code
    +string payment_method
  }
  class OrderItem {
    +int id
    +int quantity
    +float price
  }
  class Store {
    +int id
    +string name
    +string address
    +bool is_active
  }
  class StoreStock {
    +int stock
    +string rack_location
  }
  class Prescription {
    +int id
    +string status
    +text ocr_text
    +float authenticity_score
  }
  class PrescriptionMatch {
    +string matched_text
    +float confidence
  }
  class CartItem {
    +int quantity
  }
  class Coupon {
    +string code
    +string discount_type
    +float discount_value
  }
  class Review {
    +int rating
  }
  class Notification {
    +string title
    +bool is_read
  }
  User "1" --> "*" Order : places
  User "1" --> "*" Prescription : uploads
  User "1" --> "*" CartItem : has
  User "1" --> "*" Review : writes
  User "1" --> "*" Notification : receives
  Category "1" --> "*" Medicine : groups
  Medicine "1" --> "*" OrderItem
  Medicine "1" --> "*" CartItem
  Medicine "1" --> "*" StoreStock
  Medicine "1" --> "*" PrescriptionMatch
  Medicine "1" --> "*" Review
  Order "1" --> "*" OrderItem : contains
  Order "*" --> "0..1" Store : pickup
  Store "1" --> "*" StoreStock : holds
  Prescription "1" --> "*" PrescriptionMatch : detects
"""

out = os.path.join("docs", "diagrams", "11_class_diagram.png")
os.makedirs(os.path.dirname(out), exist_ok=True)
enc = base64.urlsafe_b64encode(src.encode("utf-8")).decode("ascii")
url = "https://mermaid.ink/img/" + enc
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 MediSmartDocs/1.0"})
with urllib.request.urlopen(req, timeout=90) as resp:
    raw = resp.read()
img = Image.open(io.BytesIO(raw)).convert("RGBA")
bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
bg.paste(img, mask=img.split()[-1] if img.mode == "RGBA" else None)
bg.convert("RGB").save(out, "PNG", optimize=True)
print("OK", out, os.path.getsize(out))
