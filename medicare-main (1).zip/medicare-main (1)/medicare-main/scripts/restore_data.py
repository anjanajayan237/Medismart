"""Restore a .zip previously created by backup_data.py (or Admin -> Settings
-> Download Backup), overwriting the local database + uploads with it.

Usage (from the project root, with the venv active):
    python scripts\\restore_data.py path\\to\\backup.zip

A safety copy of whatever database was already here is always written to
backups\\pre_restore_<timestamp>.db first, so this is always reversible.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app  # noqa: E402
from app.extensions import db  # noqa: E402
from app.backup import restore_backup_zip  # noqa: E402


def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts\\restore_data.py <path-to-backup.zip>")
        sys.exit(1)
    zip_path = sys.argv[1]
    if not os.path.exists(zip_path):
        print(f"File not found: {zip_path}")
        sys.exit(1)

    with app.app_context():
        def dispose():
            db.session.remove()
            db.engine.dispose()

        result = restore_backup_zip(app, zip_path, dispose_engine=dispose)

    if result["restored_db"]:
        print(f"\nRestore complete — database restored, {result['restored_files']} upload file(s) restored.")
        print("You can now run run.bat to start the app with the restored data.")
    else:
        print("\nThat zip didn't contain a recognizable MediSmart database (db/medismart.db). Nothing was changed.")
        sys.exit(1)


if __name__ == "__main__":
    main()
