# MediSmart

Kerala-based smart pharmacy web app — AI prescription reader, INR checkout, store pickup codes, rack stock, and 3D inventory.

## Quick start

- **Windows:** double-click `install.bat`, then `run.bat`
- **Docs for college submission:** see [`docs/`](./docs/README.md)
- **Install guide:** [`INSTALL.md`](./INSTALL.md)

## Default logins

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@medismart.com | admin123 |
| Customer | user@medismart.com | user123 |

Open: http://127.0.0.1:5000

**Tesseract OCR:** run `install_tesseract.bat` (or Admin → System Check) if local OCR is missing. Gemini AI works out of the box.
